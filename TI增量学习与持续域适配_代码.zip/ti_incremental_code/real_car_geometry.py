"""Authoritative real-car anchor geometry, corrected by the user on 2026-11-11.

Each tuple is (offset along increasing d, transverse offset, height difference).
Range = sqrt((d + along_offset)^2 + transverse_offset^2 + height_difference^2).
Historical outputs using the previous slave2/slave4 coordinates are superseded.
"""
import numpy as np

GEOMETRY_VERSION = "20261111_user_corrected_slave2_slave4"
GEOMETRY = {
    "master": (1.7, 2.5, .7),
    "slave1": (1.7, .7, .7),
    "slave2": (2.7, 3.07, .7),
    "slave4": (.7, 3.07, .7),
}


def range_truth(nominal, anchor):
    a, b, h = GEOMETRY[anchor]
    return np.sqrt((np.asarray(nominal, dtype=float) + a) ** 2 + b ** 2 + h ** 2)
