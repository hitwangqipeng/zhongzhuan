"""Regression-compatible components for continual domain learning/adaptation."""
import numpy as np
import torch
from torch import nn


class DomainReplay:
    """Bounded, domain-balanced uniform priority reservoirs.

    Samples keep the model's meter prediction at arrival, before its update.
    Repeated epochs do not insert duplicate observations: the caller ingests
    only the first pass. Domain labels are memory bookkeeping, never NN input.
    """
    def __init__(self,capacity,seed):
        self.capacity=capacity;self.rng=np.random.default_rng(seed);self.domains={}

    def register(self,domain):
        if domain in self.domains:return
        if len(self.domains)>=self.capacity:raise ValueError('More domains than memory slots')
        self.domains[domain]=dict(ids=np.empty(0,np.int64),pred=np.empty(0,np.float32),keys=np.empty(0))
        quota=self.capacity//len(self.domains)
        for key,value in self.domains.items():self.domains[key]=self._keep(value,quota)

    @staticmethod
    def _keep(value,quota):
        if len(value['ids'])<=quota:return value
        idx=np.argpartition(value['keys'],-quota)[-quota:]
        return {k:v[idx] for k,v in value.items()}

    def add(self,domain,ids,pred):
        self.register(domain);old=self.domains[domain];ids=np.asarray(ids,np.int64);pred=np.asarray(pred,np.float32)
        if len(ids)!=len(pred):raise ValueError('ID/prediction count mismatch')
        if np.intersect1d(old['ids'],ids).size:raise ValueError('Repeated sample ingestion into replay')
        value=dict(ids=np.r_[old['ids'],ids],pred=np.r_[old['pred'],pred],keys=np.r_[old['keys'],self.rng.random(len(ids))])
        self.domains[domain]=self._keep(value,self.capacity//len(self.domains))

    def arrays(self):
        if not self.domains:return np.empty(0,np.int64),np.empty(0,np.float32)
        return np.concatenate([v['ids'] for v in self.domains.values()]),np.concatenate([v['pred'] for v in self.domains.values()])

    def sample(self,n,rng):
        ids,pred=self.arrays()
        if not len(ids):return ids,pred
        pick=rng.choice(len(ids),min(n,len(ids)),replace=False)
        return ids[pick],pred[pick]


def hidden24(model,x):
    return model.layers[:-1]((x-model.input_offset)*model.input_gain)


def coral_loss(source,target):
    if source.ndim!=2 or target.ndim!=2 or source.shape[1]!=target.shape[1] or min(len(source),len(target))<2:
        raise ValueError('CORAL requires two batches, each with at least2 samples')
    s=source-source.mean(0);t=target-target.mean(0)
    cs=s.T@s/(len(s)-1);ct=t.T@t/(len(t)-1)
    return (cs-ct).square().sum()/(4*source.shape[1]**2)


class _Reverse(torch.autograd.Function):
    @staticmethod
    def forward(ctx,x,strength):ctx.strength=strength;return x.view_as(x)
    @staticmethod
    def backward(ctx,gradient):return -ctx.strength*gradient,None


def reverse_gradient(x,strength=1.):return _Reverse.apply(x,strength)


class DomainDiscriminator(nn.Module):
    def __init__(self):
        super().__init__();self.net=nn.Sequential(nn.Linear(24,16),nn.LeakyReLU(.1),nn.Linear(16,1))
    def forward(self,x):return self.net(x).squeeze(-1)


@torch.no_grad()
def ema_update(teacher,student,decay=.999):
    for a,b in zip(teacher.parameters(),student.parameters()):a.mul_(decay).add_(b,alpha=1-decay)


@torch.no_grad()
def stochastic_restore(model,anchor,probability,generator):
    for name,p in model.named_parameters():
        mask=torch.rand(p.shape,generator=generator,device=p.device)<probability
        p.copy_(torch.where(mask,anchor[name],p))
