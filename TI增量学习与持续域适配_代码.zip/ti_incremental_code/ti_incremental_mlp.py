"""Canonical-meter TI MLP retention methods and independent-path inference."""
from pathlib import Path
import copy
import math

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from audit_ti_finetune_implementation import canonical_model
from ti_sdk_nn import covariance_features
from ti_time_window import preprocess_single_path

VERSION='single_path_ti_incremental_mlp_v1'


class LoRALinear(nn.Module):
    def __init__(self,linear,rank):
        super().__init__();self.base=copy.deepcopy(linear)
        for p in self.base.parameters():p.requires_grad_(False)
        self.rank=min(rank,linear.in_features,linear.out_features)
        self.A=nn.Parameter(torch.empty(self.rank,linear.in_features))
        self.B=nn.Parameter(torch.zeros(linear.out_features,self.rank))
        nn.init.kaiming_uniform_(self.A,a=math.sqrt(5))

    def forward(self,x):
        return self.base(x)+F.linear(F.linear(x,self.A),self.B)


class LoRAMLP(nn.Module):
    """All4 FC matrices, alpha=rank so scaling1, all original biases frozen."""
    def __init__(self,rank):
        super().__init__();base=canonical_model()
        self.register_buffer('input_offset',base.input_offset.clone());self.register_buffer('input_gain',base.input_gain.clone())
        self.layers=nn.Sequential(*[LoRALinear(m,rank) if isinstance(m,nn.Linear) else copy.deepcopy(m) for m in base.layers])

    def forward(self,x):
        return self.layers((x-self.input_offset)*self.input_gain).squeeze(-1)

    def merged(self):
        result=canonical_model()
        with torch.no_grad():
            for dest,source in zip(result.layers,self.layers):
                if isinstance(source,LoRALinear):
                    dest.weight.copy_(source.base.weight+source.B@source.A);dest.bias.copy_(source.base.bias)
        return result


class AdapterMLP(nn.Module):
    """Identity residual bottleneck after the frozen24-D third ReLU."""
    def __init__(self,bottleneck):
        super().__init__();self.base=canonical_model()
        for p in self.base.parameters():p.requires_grad_(False)
        self.down=nn.Linear(24,bottleneck);self.up=nn.Linear(bottleneck,24)
        nn.init.zeros_(self.down.bias);nn.init.zeros_(self.up.weight);nn.init.zeros_(self.up.bias)

    def hidden(self,x):
        return self.base.layers[:-1]((x-self.base.input_offset)*self.base.input_gain)

    def from_hidden(self,h):
        return self.base.layers[-1](h+self.up(F.relu(self.down(h)))).squeeze(-1)

    def forward(self,x):
        return self.from_hidden(self.hidden(x))


def make_model(config):
    if config['method']=='lora':return LoRAMLP(config['rank'])
    if config['method']=='adapter':return AdapterMLP(config['bottleneck'])
    return canonical_model()


def gaussian_diagonal_fisher(model,x,weights=None):
    """E[(d(f/30)/dtheta)^2] for unit Gaussian normalized-distance likelihood.

    Exact per-example Jacobian squares, not the square of a minibatch mean
    gradient. Input distribution is supplied by the caller, not TI old data.
    Uses analytic ReLU backprop to avoid materializing Nx3265 Jacobians.
    """
    with torch.no_grad():
        h=[(x-model.input_offset)*model.input_gain];pre=[]
        linears=[m for m in model.layers if isinstance(m,nn.Linear)]
        for layer in linears[:-1]:
            pre.append(layer(h[-1]));h.append(F.relu(pre[-1]))
        delta=torch.ones((len(x),1),dtype=x.dtype,device=x.device)/30
        deltas=[None]*4;deltas[3]=delta
        for i in range(2,-1,-1):
            delta=(delta@linears[i+1].weight)*(pre[i]>0);deltas[i]=delta
        w=torch.ones(len(x),dtype=x.dtype,device=x.device) if weights is None else weights
        w=w/w.sum();out={}
        for i in range(4):
            squared=deltas[i].square()*w[:,None]
            out[f'layers.{2*i}.weight']=squared.T@h[i].square()
            out[f'layers.{2*i}.bias']=squared.sum(0)
        return out


def ewc_penalty(model,anchor,fisher):
    return .5*sum((fisher[name]*(p-anchor[name]).square()).sum() for name,p in model.named_parameters())


def load_incremental(checkpoint):
    obj=torch.load(Path(checkpoint),map_location='cpu',weights_only=True)
    protocol=obj['protocol']
    if protocol.get('version')!=VERSION or protocol.get('path_fusion') is not False:
        raise ValueError('Expected an independent-path incremental-model checkpoint')
    model=canonical_model() if protocol.get('merged_lora') else make_model(protocol['config'])
    model.load_state_dict(obj['state_dict']);model.eval()
    return model,protocol


def predict_incremental_iq(iq80,checkpoint,batch_size=512):
    z=np.asarray(iq80)
    if z.ndim!=2 or z.shape[1]!=80 or z.dtype.kind!='c' or not len(z) or batch_size<1 or not np.isfinite(z).all():
        raise ValueError('Expected nonempty finite already-combined calibrated complex N x80 IQ')
    model,_=load_incremental(checkpoint);pred=[]
    with torch.no_grad():
        for start in range(0,len(z),batch_size):
            features=covariance_features(preprocess_single_path(z[start:start+batch_size]))
            pred.append(model(torch.from_numpy(features)).numpy())
    result=np.concatenate(pred)
    if not np.isfinite(result).all():raise ValueError('Nonfinite meter prediction')
    return result
