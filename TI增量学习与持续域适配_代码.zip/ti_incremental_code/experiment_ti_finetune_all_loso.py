"""Full labelled-data, single-path TI-initialized scene holdout experiment.

Historical v1: its /30 output-head parameterization preserves forward values
but magnifies canonical Adam head steps by about30 at the same nominal LR.
See audit_ti_finetune_implementation.py for canonical-meter fine-tuning and
the implementation audit. Preserve this entry to reproduce archived v1 runs.

All valid static cached bench paths (not the old 96-frame subsample) and all
valid labelled car paths. Outer scene is never used for student fitting,
early stopping, preprocessing statistics or adaptation-method selection.
"""
from pathlib import Path
import argparse
import copy
import hashlib
import json
import re
import sys
import time

import numpy as np
import pandas as pd
import torch
from torch import nn
from threadpoolctl import threadpool_limits

from ti_sdk_nn import TiApuArchitecture, covariance_features
from ti_pretrained_nn import load_weights, predict as teacher_predict
from ti_time_window import preprocess_single_path
from real_car_geometry import GEOMETRY_VERSION, GEOMETRY, range_truth

BASE = Path(__file__).resolve().parent
ROOT = Path(r'C:\Users\wqp_9741\Documents\Ranging\测距日志\fob_v2')
OUT = BASE / 'outputs/ti_finetune_all_loso_20261118'
SCENES = ('室内二楼', '空旷场景', '车库负二楼', '实车')
METHODS = ('scratch', 'ti_head', 'ti_full')
SEEDS = (20261118, 20261119)
VERSION = 'full_labelled_paths_sdk_window_ti_finetune_v1'
sys.path.insert(0, str(BASE / 'ti_ble_ranging_project/src'))
from ble_ti_ranging.inputs import _parse_log


def sha(path):
    with Path(path).open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()


def write_json(path, value):
    Path(path).write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def inventory():
    audit = pd.read_csv(BASE / 'outputs/step12/file_audit.csv')
    prior = pd.read_csv(BASE / 'outputs/remnet_leave_scene_20261111/source_manifest.csv').set_index('source_id')
    rows, exclusions = [], []
    for r in audit.itertuples():
        if not np.isfinite(r.truth_m):
            exclusions.append(dict(file=str(ROOT / r.relative_path), reason='no framewise reference distance'))
            continue
        if pd.notna(r.duplicate_of):
            exclusions.append(dict(file=str(ROOT / r.relative_path), reason='duplicate source'))
            continue
        assert r.environment in SCENES[:3]
        source_id = f'bench:{r.file_id}'
        p = prior.loc[source_id]
        assert p.original_sha256 == r.sha256
        node = json.loads(r.anchors)
        rows.append(dict(source_id=source_id, scene=r.environment, file=str(ROOT / r.relative_path),
            source_sha256=r.sha256, cache_file=str(BASE / f'outputs/step12/cache/{r.file_id:04d}.npz'),
            cache_sha256=p.cache_sha256, condition=r.condition, nominal_m=float(r.truth_m),
            truth_m=float(r.truth_m), session_id='bench:' + r.session,
            stratum='|'.join([r.topology, r.antenna, r.condition]),
            topology=r.topology, antenna=r.antenna, anchor='node'+str(node[0]) if len(node)==1 else 'unresolved',
            reference='existing static bench distance annotation'))
    for p in sorted((ROOT / '实车锚点数据').rglob('*.log')):
        anchor = re.search(r'\]\[(master|slave\d+)\]', p.name)
        anchor = anchor.group(1) if anchor else ''
        distance = re.search(r'定点(\d+(?:\.\d+)?)M', p.parent.name, re.I)
        if anchor not in GEOMETRY or distance is None:
            exclusions.append(dict(file=str(p), reason='no confirmed 3D anchor geometry or static position', anchor=anchor))
            continue
        condition = 'NLOS' if 'NLOS' in p.parts else 'LOS' if 'LOS' in p.parts else 'UNKNOWN'
        nominal = float(distance.group(1))
        rows.append(dict(source_id='car:' + str(p.relative_to(ROOT)), scene='实车', file=str(p),
            source_sha256=None, cache_file='', cache_sha256='', condition=condition,
            nominal_m=nominal, truth_m=float(range_truth(nominal, anchor)),
            session_id=f'car:{condition}|{nominal}', stratum=condition,
            topology='real_car', antenna='four_paths', anchor=anchor, reference=GEOMETRY_VERSION))
    assert len(rows)==928 and len({r['source_id'] for r in rows})==len(rows)
    return rows, exclusions


def prepare():
    OUT.mkdir(parents=True, exist_ok=True)
    marker = OUT / 'dataset_protocol.json'
    if marker.exists():
        spec = json.loads(marker.read_text(encoding='utf-8'))
        assert spec['version']==VERSION and spec['geometry_version']==GEOMETRY_VERSION
        for name, digest in spec['artifact_sha256'].items():
            assert sha(OUT / name)==digest, name
        return
    sources, exclusions = inventory()
    shard_dir = OUT / 'data_shards'
    shard_dir.mkdir(exist_ok=True)
    started = time.perf_counter()
    for k, r in enumerate(sources):
        prefix = shard_dir / f'{k:04d}'
        record = prefix.with_suffix('.json')
        if record.exists():
            old = json.loads(record.read_text(encoding='utf-8'))
            assert old['version']==VERSION and old['source_id']==r['source_id']
            assert sha(r['file'])==old['source_sha256']
            r.update(old)
            continue
        actual_sha = sha(r['file'])
        if r['source_sha256'] is not None:
            assert actual_sha==r['source_sha256'], r['file']
        r['source_sha256'] = actual_sha
        if r['cache_file']:
            assert sha(r['cache_file'])==r['cache_sha256']
            with np.load(r['cache_file']) as c:
                coords = {key: c[key].copy() for key in ['line', 'epoch', 'key', 'ts', 'path']}
                iq = c['iq'].astype(np.float64)
            z = iq[:, :, 0] + 1j*iq[:, :, 1]
        else:
            raw, audit = _parse_log(Path(r['file']), complete_four_paths=False)
            assert audit['sha256']==actual_sha
            r['parse_audit'] = audit
            z = np.stack([v[5] for v in raw])
            coords = {name: np.array([v[j] for v in raw]) for name, j in [('epoch',0),('key',1),('ts',2),('path',3),('line',4)]}
        assert len(z)>0 and z.shape[1]==80 and np.isfinite(z).all()
        assert np.all(np.any(z!=0, axis=1))
        _, frame = np.unique(np.column_stack([coords[t] for t in ['epoch','key','ts']]), axis=0, return_inverse=True)
        assert len(np.unique(np.column_stack([frame,coords['path']]), axis=0))==len(z)
        f = np.lib.format.open_memmap(prefix.with_suffix('.partial.npy'), mode='w+', dtype=np.float32, shape=(len(z),156))
        states = np.empty(len(z), np.int32)
        for start in range(0,len(z),512):
            stop = min(start+512,len(z))
            zz, state = preprocess_single_path(z[start:stop], return_state=True)
            f[start:stop] = covariance_features(zz)
            states[start:stop] = state['peak_bin_sap']
        assert np.isfinite(f).all()
        f.flush(); del f
        prefix.with_suffix('.partial.npy').replace(prefix.with_suffix('.npy'))
        np.savez_compressed(prefix.with_suffix('.npz'), **coords, frame_local=frame.astype(np.int32), peak_bin_sap=states)
        r.update(version=VERSION, n_paths=len(z), n_frames=int(frame.max())+1,
            zero_tone_paths=int(np.any(z==0,axis=1).sum()), window_bypassed_n=int((states==0).sum()))
        write_json(record,r)
        if (k+1)%24==0 or k+1==len(sources):
            print('PREPARE',k+1,'/',len(sources),'paths',sum(s['n_paths'] for s in sources[:k+1]),'seconds',round(time.perf_counter()-started,1),flush=True)
    assert len({r['source_sha256'] for r in sources})==len(sources)
    total = sum(r['n_paths'] for r in sources)
    x = np.lib.format.open_memmap(OUT/'features.partial.npy',mode='w+',dtype=np.float32,shape=(total,156))
    arrays = {key: np.empty(total,dtype=dtype) for key,dtype in [('source_index',np.int16),('line',np.int32),
        ('epoch',np.int32),('key',np.int32),('ts',np.int64),('path',np.int8),('frame_id',np.int64),('peak_bin_sap',np.int32)]}
    offset=0; frame_offset=0
    for k,r in enumerate(sources):
        n=r['n_paths']; sl=slice(offset,offset+n); prefix=shard_dir/f'{k:04d}'
        x[sl]=np.load(prefix.with_suffix('.npy'),mmap_mode='r')
        with np.load(prefix.with_suffix('.npz')) as c:
            for key in ['line','epoch','key','ts','path','peak_bin_sap']:arrays[key][sl]=c[key]
            arrays['frame_id'][sl]=frame_offset+c['frame_local']
        arrays['source_index'][sl]=k
        r['source_index']=k; r['sample_start']=offset; r['sample_stop']=offset+n
        offset+=n; frame_offset+=r['n_frames']
    x.flush(); del x
    (OUT/'features.partial.npy').replace(OUT/'features.npy')
    np.savez_compressed(OUT/'sample_coordinates.npz',**arrays)
    slim=[{k:v for k,v in r.items() if k!='parse_audit'} for r in sources]
    sf=pd.DataFrame(slim); sf.to_csv(OUT/'sources.csv',index=False,encoding='utf-8-sig')
    write_json(OUT/'source_manifest.json',sources);write_json(OUT/'excluded_sources.json',exclusions)
    sf.groupby('scene').agg(n_paths=('n_paths','sum'),n_frames=('n_frames','sum'),files=('source_id','size'),
        min_truth_m=('truth_m','min'),max_truth_m=('truth_m','max')).to_csv(OUT/'dataset_summary.csv',encoding='utf-8-sig')
    write_json(marker,dict(version=VERSION,geometry_version=GEOMETRY_VERSION,n_paths=total,n_frames=frame_offset,
        n_files=len(sf),scenes=list(SCENES),bench_sampling='all valid paths, no 96-frame cap',
        conditions='all annotated static conditions, including LOS/NLOS candidates and rotation; no obstruction filter',
        incomplete_physical_frames='keep each valid path independently, never impute or fuse missing paths',
        nonzero_partial_tones='kept as recorded; no zero-tone or RSSI=-128 frame exclusion',
        preprocessing='already combined calibrated80 tones -> stateless SDK time window -> two2MHz groups, L12 -> upper L2 ->156',
        exclusion='no framewise truth on dynamic logs; no confirmed car slave3 geometry',
        trainable_input='156 covariance values only; no anchor/path/scene/truth/d0/history',
        artifact_sha256={name:sha(OUT/name) for name in ['features.npy','sample_coordinates.npz','sources.csv']},
        source_hashes_verified=True,cache_hashes_verified=True,seconds=time.perf_counter()-started))
    print('DATASET COMPLETE',total,'paths',frame_offset,'frames',flush=True)


def load_data():
    spec=json.loads((OUT/'dataset_protocol.json').read_text(encoding='utf-8'))
    assert spec['version']==VERSION
    sources=pd.read_csv(OUT/'sources.csv',keep_default_na=False)
    x=np.load(OUT/'features.npy',mmap_mode='r')
    with np.load(OUT/'sample_coordinates.npz') as c: coords={key:c[key] for key in c.files}
    si=coords['source_index']; truth=sources.truth_m.to_numpy()[si]
    assert len(x)==len(si)==spec['n_paths'] and x.shape[1]==156
    return sources,x,coords,truth


class MeterModel(TiApuArchitecture):
    """Historical /30 head: forward-equivalent, NOT Adam-update-equivalent.

    A head LR of1e-4 here is approximately3e-3 in original TI parameter units.
    Canonical-meter fine-tuning uses the independent audit entry instead.
    """
    def __init__(self, pretrained=False):
        super().__init__()
        if pretrained:
            off,gain,layers=load_weights()
            with torch.no_grad():
                self.input_offset.copy_(torch.from_numpy(off)); self.input_gain.copy_(torch.from_numpy(gain))
                for layer,(w,b) in zip([v for v in self.layers if isinstance(v,nn.Linear)],layers):
                    layer.weight.copy_(torch.from_numpy(w));layer.bias.copy_(torch.from_numpy(b))
                self.layers[-1].weight.div_(30);self.layers[-1].bias.div_(30)
    def forward(self,x):
        return super().forward(x)*30


def predict_model(model,x,ids,batch=16384):
    model.eval(); result=np.empty(len(ids),np.float32)
    with torch.no_grad():
        for start in range(0,len(ids),batch):
            chunk=np.array(x[ids[start:start+batch]],copy=True)
            result[start:start+len(chunk)]=model(torch.from_numpy(chunk)).numpy()
    assert np.isfinite(result).all()
    return result


def split_sources(sources,held):
    rng=np.random.default_rng(91723+SCENES.index(held)); validation=[]
    source=sources[sources.scene.ne(held)]
    for (scene,stratum),g in source.groupby(['scene','stratum'],sort=True):
        sessions=np.array(sorted(g.session_id.unique()))
        n=2 if scene=='实车' else 1
        assert len(sessions)>n
        validation.extend(rng.choice(sessions,n,replace=False).tolist())
    val=sources.session_id.isin(validation).to_numpy()
    test=sources.scene.eq(held).to_numpy(); train=~(val|test)
    result={key:np.flatnonzero(mask) for key,mask in [('train',train),('validation',val),('test',test)]}
    for name in ['source_id','session_id','source_sha256']:
        groups=[set(sources.iloc[ix][name]) for ix in result.values()]
        for i in range(3):
            for j in range(i+1,3): assert not groups[i]&groups[j],name
    assert set(sources.scene.iloc[result['test']])=={held}
    assert set(sources.scene.iloc[result['train']])==set(sources.scene.iloc[result['validation']])==set(SCENES)-{held}
    return result


def row_weights(sources,source_ids,si):
    """Equal scene, equal nominal distance within scene, equal file per distance."""
    subset=sources.iloc[source_ids]; ns=subset.scene.nunique(); wsource=np.zeros(len(sources),np.float64)
    for scene,g in subset.groupby('scene'):
        nd=g.nominal_m.nunique()
        for _,h in g.groupby('nominal_m'):
            for r in h.itertuples():wsource[r.Index]=1/(ns*nd*len(h)*r.n_paths)
    weights=wsource[si]
    weights *= len(si)/weights.sum()
    assert np.isclose(weights.mean(),1)
    return weights.astype(np.float32)


def validation_metrics(pred,truth,source_rows,sources):
    error=pred.astype(np.float64)-truth
    frame=pd.DataFrame(dict(scene=sources.scene.to_numpy()[source_rows],
        bin=np.digitize(truth,[5,10,15,20,30]),absolute=abs(error),squared=(error/30)**2))
    by=frame.groupby(['scene','bin']).absolute.mean().groupby('scene').mean()
    return float(by.mean()),float(frame.squared.mean()),{str(k):float(v) for k,v in by.items()}


def metrics(pred,truth):
    pred=np.asarray(pred,float);truth=np.asarray(truth,float); good=np.isfinite(pred)&np.isfinite(truth)
    e=pred[good]-truth[good]
    if not len(e):return dict(n=0,mae_m=np.nan,error_p5_m=np.nan,abs_error_p5_m=np.nan,cep95_m=np.nan,bias_m=np.nan,under3_pct=np.nan,over3_pct=np.nan)
    return dict(n=len(e),mae_m=float(abs(e).mean()),error_p5_m=float(np.quantile(e,.05)),
        abs_error_p5_m=float(np.quantile(abs(e),.05)),cep95_m=float(np.quantile(abs(e),.95)),
        bias_m=float(e.mean()),under3_pct=float(100*np.mean(e < -3)),over3_pct=float(100*np.mean(e > 3)))


def train_fold(sources,x,coords,truth,held,seed,method,epochs,batch):
    folder=OUT/f'seed_{seed}'/f'leave_{held}'/method;folder.mkdir(parents=True,exist_ok=True)
    done=folder/'protocol.json'
    if done.exists():
        previous=json.loads(done.read_text(encoding='utf-8'))
        assert previous['dataset_version']==VERSION and previous['seed']==seed
        return
    ss=split_sources(sources,held);si=coords['source_index']
    split={key:np.flatnonzero(np.isin(si,ids)) for key,ids in ss.items()}
    tr,va,te=[split[key] for key in ['train','validation','test']]
    for ids in split.values():assert len(ids)>0
    assert sum(map(len,split.values()))==len(x)
    assert not set(coords['frame_id'][tr])&set(coords['frame_id'][va])
    torch.manual_seed(seed+100*SCENES.index(held));rng=np.random.default_rng(seed+100*SCENES.index(held))
    model=MeterModel(pretrained=method!='scratch')
    assert sum(p.numel() for p in model.parameters())==3265
    if method!='scratch':
        check=va[np.linspace(0,len(va)-1,32).astype(int)]
        a=predict_model(model,x,check);b=teacher_predict(x[check])
        assert np.max(abs(a-b))<3e-4, float(np.max(abs(a-b)))
    if method=='scratch':
        optimizer=torch.optim.AdamW(model.parameters(),lr=.001,weight_decay=.0001)
    else:
        optimizer=torch.optim.AdamW([dict(params=list(model.layers[:-1].parameters()),lr=.00001),
            dict(params=list(model.layers[-1].parameters()),lr=.0001)],weight_decay=.0001)
    weights=row_weights(sources,ss['train'],si[tr]); val_weights=row_weights(sources,ss['validation'],si[va])
    xt=torch.from_numpy(np.array(x[tr],copy=True));yt=torch.from_numpy(truth[tr].astype(np.float32));wt=torch.from_numpy(weights)
    initial=predict_model(model,x,va);score,vmse,by=validation_metrics(initial,truth[va],si[va],sources)
    best=(score,0,copy.deepcopy(model.state_dict()));history=[dict(epoch=0,train_online_weighted_mse=np.nan,
        validation_mse=vmse,validation_balanced_mae_m=score,validation_weighted_mse=float(np.mean(val_weights*((initial-truth[va])/30)**2)),
        trainable='initial',**{f'val_{s}':v for s,v in by.items()})]
    if method=='scratch':best=(np.inf,-1,None)
    started=time.perf_counter()
    print('FIT START',seed,held,method,'rows',len(tr),len(va),len(te),'initial_val',round(score,4),flush=True)
    for epoch in range(1,epochs+1):
        train_head_only=method=='ti_head' or (method=='ti_full' and epoch<=2)
        for p in model.layers[:-1].parameters():p.requires_grad_(not train_head_only)
        model.train();order=rng.permutation(len(tr));total=0.
        for start in range(0,len(order),batch):
            ix=order[start:start+batch];optimizer.zero_grad(set_to_none=True)
            err=(model(xt[ix])-yt[ix])/30
            loss=torch.mean(wt[ix]*err.square());loss.backward();optimizer.step()
            total+=float(loss.detach())*len(ix)
        vp=predict_model(model,x,va);score,vmse,by=validation_metrics(vp,truth[va],si[va],sources)
        history.append(dict(epoch=epoch,train_online_weighted_mse=total/len(tr),validation_mse=vmse,
            validation_balanced_mae_m=score,validation_weighted_mse=float(np.mean(val_weights*((vp-truth[va])/30)**2)),
            trainable='head' if train_head_only else 'all',**{f'val_{s}':v for s,v in by.items()}))
        if score<best[0]-1e-5:best=(score,epoch,copy.deepcopy(model.state_dict()))
        pd.DataFrame(history).to_csv(folder/'learning_curve.csv',index=False)
        print('EPOCH',seed,held,method,epoch,'train',round(total/len(tr),5),'val',round(score,4),'best',best[1],'seconds',round(time.perf_counter()-started,1),flush=True)
        if epoch-best[1]>=6 and epoch>=4:break
    assert best[2] is not None
    model.load_state_dict(best[2]);pred=predict_model(model,x,te)
    # Export the checkpoint with the output factor folded into the final layer.
    direct=TiApuArchitecture();state=copy.deepcopy(model.state_dict());state['layers.6.weight']*=30;state['layers.6.bias']*=30
    direct.load_state_dict(state);check=te[np.linspace(0,len(te)-1,min(128,len(te))).astype(int)]
    exported=predict_model(direct,x,check);original=predict_model(model,x,check)
    assert np.max(abs(exported-original))<3e-4
    protocol=dict(dataset_version=VERSION,seed=seed,held_scene=held,method=method,architecture=[156,12,36,24,1],
        parameters=3265,initialization='random' if method=='scratch' else 'original frozen TI parameters copied then adapted',
        train_n=len(tr),validation_n=len(va),test_n=len(te),best_epoch=best[1],
        best_source_validation_balanced_mae_m=best[0],epochs_run=len(history)-1,max_epochs=epochs,patience=6,
        epoch0_frozen_TI_checkpoint_allowed=method!='scratch',all_training_rows_per_epoch=True,
        training_weights='equal source scene, equal nominal distance, equal file; all paths in file share weight',
        loss='weighted ((prediction_m - true_distance_m)/30)^2',output_unit='meters; no clipping and no posthoc offset',
        input_affine='original fixed TI offset/gain; no fitted global feature statistics',
        feature='single-path SDK stateless time-window80-tone adapter,2MHz L12,156D',
        lr_hidden=.001 if method=='scratch' else .00001,lr_head=.001 if method=='scratch' else .0001,
        optimizer='AdamW weight_decay0.0001',batch_size=batch,head_only_epochs='all' if method=='ti_head' else 2 if method=='ti_full' else 0,
        selection='source-validation MAE: equal bins within scene, then equal scenes; no outer labels used',
        validation_bins_m=[0,5,10,15,20,30,'infinity'],
        train_sources=sources.source_id.iloc[ss['train']].tolist(),validation_sources=sources.source_id.iloc[ss['validation']].tolist(),
        test_sources=sources.source_id.iloc[ss['test']].tolist(),geometry_version=GEOMETRY_VERSION,
        train_truth_min_m=float(truth[tr].min()),train_truth_max_m=float(truth[tr].max()),
        test_used_for_fitting_or_selection=False,path_fusion=False,shared_model_all_paths=True,identities_as_features=False,
        original_TI_pretraining_dataset_unknown=True,seconds=time.perf_counter()-started)
    np.savez_compressed(folder/'predictions.npz',sample_id=te,prediction_m=pred)
    torch.save(dict(state_dict=state,protocol=protocol),folder/'model_meters.pt')
    np.savez_compressed(folder/'split_sources.npz',**ss)
    diagnostic=[]
    for name,ids in [('train',tr),('validation',va)]:
        yy=predict_model(model,x,ids)
        for scope,mask in [('ALL',np.ones(len(ids),bool)),('true_gt15m',truth[ids]>15)]:
            diagnostic.append(dict(partition=name,scope=scope,**metrics(yy[mask],truth[ids][mask])))
    pd.DataFrame(diagnostic).to_csv(folder/'fit_diagnostics.csv',index=False)
    write_json(done,protocol)
    print('FIT COMPLETE',seed,held,method,'best',best[1],flush=True)


def frozen_predictions(sources,x,coords):
    target=OUT/'frozen_predictions.npy'
    if target.exists():return np.load(target,mmap_mode='r')
    p=np.lib.format.open_memmap(OUT/'frozen_predictions.partial.npy',mode='w+',dtype=np.float32,shape=(len(x),))
    for start in range(0,len(x),16384):p[start:start+16384]=teacher_predict(x[start:start+16384])
    p.flush();del p;(OUT/'frozen_predictions.partial.npy').replace(target)
    return np.load(target,mmap_mode='r')


def group_metrics(rows, prediction, truth, sources, source_ids, scopes=True):
    groups=[('ALL',np.ones(len(truth),bool)),('true_le15m',truth<=15),('true_gt15m',truth>15)]
    if scopes:
        for value in sorted(np.unique(sources.condition.to_numpy()[source_ids])):
            groups.append(('condition:'+str(value),sources.condition.to_numpy()[source_ids]==value))
    for scope,mask in groups:
        if not mask.any():continue
        rows.append(dict(scope=scope,**metrics(prediction[mask],truth[mask])))


def table_text(frame):
    columns=['scene','method','n','mae_m_mean','error_p5_m_mean','abs_error_p5_m_mean','cep95_m_mean','bias_m_mean','under3_pct_mean','over3_pct_mean']
    labels=['测试场景','方法','N','MAE','error P5','abs P5','CEP95','偏差','低估>3m%','高估>3m%']
    text='|'+'|'.join(labels)+'|\n|'+'|'.join(['---']*len(labels))+'|\n'
    for _,r in frame.iterrows():
        text+='|'+'|'.join(str(r[c]) if c in ['scene','method','n'] else f'{r[c]:.3f}' for c in columns)+'|\n'
    return text


def report():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','DejaVu Sans']
    plt.rcParams['axes.unicode_minus']=False
    sources,x,coords,truth=load_data();si=coords['source_index'];frozen=np.asarray(frozen_predictions(sources,x,coords))
    rows=[];details=[];selection=[];csv_paths=[]
    for seed in SEEDS:
        seed_predictions={name:np.full(len(x),np.nan,np.float32) for name in [*METHODS,'ti_selected']}
        seed_predictions['ti_frozen']=frozen
        seed_predictions['ti_frozen_minus094']=frozen-.94
        for held in SCENES:
            ss=split_sources(sources,held);te=np.flatnonzero(np.isin(si,ss['test']));va=np.flatnonzero(np.isin(si,ss['validation']))
            frozen_score=validation_metrics(frozen[va],truth[va],si[va],sources)[0]
            scores={'ti_frozen':frozen_score}
            protocols={}
            for method in METHODS:
                folder=OUT/f'seed_{seed}'/f'leave_{held}'/method
                protocol=json.loads((folder/'protocol.json').read_text(encoding='utf-8'));protocols[method]=protocol
                with np.load(folder/'predictions.npz') as c:
                    np.testing.assert_array_equal(c['sample_id'],te)
                    seed_predictions[method][te]=c['prediction_m']
                if method!='scratch':scores[method]=protocol['best_source_validation_balanced_mae_m']
            selected=min(scores,key=scores.get)
            seed_predictions['ti_selected'][te]=seed_predictions[selected][te]
            selection.append(dict(seed=seed,held_scene=held,selected_method=selected,source_validation_score=scores[selected],
                frozen_source_validation_score=frozen_score,**{f'{m}_best_epoch':p['best_epoch'] for m,p in protocols.items()}))
        for name,pred in seed_predictions.items():
            assert np.isfinite(pred).all(),name
            for scene in ['ALL',*SCENES]:
                ids=np.arange(len(x)) if scene=='ALL' else np.flatnonzero(sources.scene.to_numpy()[si]==scene)
                sub=[];group_metrics(sub,pred[ids],truth[ids],sources,si[ids],scopes=scene!='ALL')
                for r in sub:rows.append(dict(seed=seed,scene=scene,method=name,**r))
            car=np.flatnonzero(sources.scene.to_numpy()[si]=='实车')
            car_sources=si[car]
            fields=[('anchor',['anchor']),('path',None),('anchor_path',['anchor']),('distance',['nominal_m']),('anchor_distance',['anchor','nominal_m'])]
            for dimension,keys in fields:
                if dimension=='path':keyframe=pd.DataFrame(dict(path=coords['path'][car]))
                else:
                    keyframe=sources.iloc[car_sources][keys].reset_index(drop=True)
                    if dimension=='anchor_path':keyframe['path']=coords['path'][car]
                for key,ix in keyframe.groupby(list(keyframe.columns),sort=True).groups.items():
                    key=key if isinstance(key,tuple) else (key,);ids=car[np.asarray(ix)]
                    details.append(dict(seed=seed,dimension=dimension,group='|'.join(map(str,key)),method=name,**metrics(pred[ids],truth[ids])))
        # Write all out-of-scene predictions with numeric coordinates and compact source IDs.
        destination=OUT/f'predictions_seed_{seed}.csv.gz'
        data=dict(sample_id=np.arange(len(x)),source_index=si,source_line=coords['line'],path=coords['path'],
            frame_id=coords['frame_id'],truth_m=truth,**{f'{name}_m':v for name,v in seed_predictions.items()})
        pd.DataFrame(data).to_csv(destination,index=False);csv_paths.append(destination)
    per=pd.DataFrame(rows);per.to_csv(OUT/'metrics_each_seed.csv',index=False,encoding='utf-8-sig')
    fields=['mae_m','error_p5_m','abs_error_p5_m','cep95_m','bias_m','under3_pct','over3_pct']
    avg=per.groupby(['scene','scope','method']).agg(n=('n','first'),**{
        f'{key}_{stat}':(key,stat) for key in fields for stat in ['mean','std']}).reset_index()
    avg.to_csv(OUT/'metrics_two_seeds.csv',index=False,encoding='utf-8-sig')
    macro=per[per.scene.isin(SCENES)&per.scope.eq('ALL')].groupby(['seed','method']).mae_m.mean().reset_index(name='scene_macro_mae_m')
    macro.to_csv(OUT/'scene_macro_mae_each_seed.csv',index=False)
    detailed=pd.DataFrame(details);detailed.to_csv(OUT/'car_details_each_seed.csv',index=False,encoding='utf-8-sig')
    detailavg=detailed.groupby(['dimension','group','method']).agg(n=('n','first'),**{
        f'{key}_{stat}':(key,stat) for key in fields for stat in ['mean','std']}).reset_index()
    detailavg.to_csv(OUT/'car_details_two_seeds.csv',index=False,encoding='utf-8-sig')
    selected=pd.DataFrame(selection);selected.to_csv(OUT/'source_only_model_selection.csv',index=False,encoding='utf-8-sig')
    for method in METHODS:
        fig,axes=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
        for ax,held in zip(axes.flat,SCENES):
            for j,seed in enumerate(SEEDS):
                curve=pd.read_csv(OUT/f'seed_{seed}'/f'leave_{held}'/method/'learning_curve.csv')
                color=['#2563eb','#dc2626'][j]
                ax.plot(curve.epoch,curve.train_online_weighted_mse,color=color,label=f'{seed} train online')
                ax.plot(curve.epoch,curve.validation_weighted_mse,color=color,ls='--',label=f'{seed} validation')
            ax.set_title(held);ax.set_xlabel('Epoch');ax.set_ylabel('Normalized weighted MSE');ax.grid(alpha=.2);ax.legend(fontsize=8)
        fig.suptitle(method+' — all source training rows each epoch')
        fig.savefig(OUT/f'learning_curves_{method}.png',dpi=150);plt.close(fig)
    main=avg[(avg.scope=='ALL')&(avg.method.isin(['ti_frozen','scratch','ti_head','ti_full','ti_selected']))]
    far=avg[(avg.scope=='true_gt15m')&(avg.scene=='实车')&(avg.method.isin(['ti_frozen','ti_frozen_minus094','scratch','ti_head','ti_full','ti_selected']))]
    comparison=avg[(avg.scope=='ALL')&(avg.scene=='实车')&(avg.method.isin(['ti_frozen','ti_frozen_minus094','ti_selected']))]
    summary=pd.read_csv(OUT/'dataset_summary.csv')
    text='# TI原权重实车及多场景微调：全静态数据场景留一\n\n'
    text+='每折整体留出一个场景，只用其余三个场景训练、选轮次和选适配方式。四个场景为室内二楼、空旷场景、车库负二楼、实车。冻结TI原训练集未知，本报告仅保证本次学生训练和选择不使用留出场景。\n\n'
    car_all=avg[(avg.scope=='ALL')&(avg.scene=='实车')].set_index('method')
    car_far=avg[(avg.scope=='true_gt15m')&(avg.scene=='实车')].set_index('method')
    text+=f"本配置下，来源验证选择方案在整实车留出测试上的MAE为{car_all.loc['ti_selected','mae_m_mean']:.3f}m；冻结原模型为{car_all.loc['ti_frozen','mae_m_mean']:.3f}m，冻结后按既有值减0.94m为{car_all.loc['ti_frozen_minus094','mae_m_mean']:.3f}m。真值>15m组，选择方案MAE为{car_far.loc['ti_selected','mae_m_mean']:.3f}m，冻结原模型为{car_far.loc['ti_frozen','mae_m_mean']:.3f}m。\n\n"
    if car_far.loc['ti_selected','mae_m_mean']>car_far.loc['ti_frozen','mae_m_mean']:
        text+='远距离组在微调后退化，不能仅凭总体平均误差判断泛化改善。本折训练和验证只有1～15m来源标签，结果支持该训练配置下远距离保持不足，不证明所有微调方法都会失败。\n\n'
    text+='## 数据\n\n'+summary.to_csv(index=False)+'\n'
    text+='采用全部有可靠参考值的静态日志有效path，不再每文件抽96帧。台架含三脚架、手持、遮挡、人体转身；实车同时含LOS与NLOS。有效记录中的零频点保留，RSSI=-128不作无效依据。独立path样本允许不完整多path帧，不补齐、不融合。动态日志无逐帧真值、实车slave3无确认3D几何，因此不编造标签；排除文件见excluded_sources.json。\n\n'
    text+='实车真值为已确认几何计算的3D距离；其他静态场景沿用原有参考距离标注，未假装拥有其未提供的3D坐标。source_manifest.json记录源日志、IQ缓存哈希；旧缓存全部核对，源日志只读。\n\n'
    text+='## 固定训练协议\n\n'
    text+='输入统一为SDK单path无历史时域窗适配后的156维协方差：80点IQ、256点时域窗往返、奇偶两组2MHz、L12、上三角整体L2、SDK固定offset/gain。所有path、锚点共用模型，元数据不入网络，无多path/时间融合。保留80点适配，非完整TI原生双端/75信道/Adaptive固件。\n\n'
    text+='scratch随机初始化，lr0.001；ti_head从TI权重初始化、仅更新最后一层lr0.0001；ti_full前两轮只更新输出层，之后全网络，隐藏层lr0.00001、输出层lr0.0001。统一AdamW、wd0.0001、batch4096、最多25轮、耐心6轮。训练和推理的预测都为米，损失为((预测米−真值米)/30)²；输出尺度在参数内部条件化，导出时折入最后一层。未把真值单独除30后与原TI米输出比较。\n\n'
    text+='每个epoch遍历所有训练path。损失按来源场景、标称距离、文件逐层等权；同一文件各path同权。按完整采集session划分来源验证，同session的文件、path和frame不跨训练/验证。验证以真实距离分段[0,5,10,15,20,30,∞)，先段等权再场景等权MAE选轮次。TI适配允许选择epoch0保留冻结权重。ti_selected只在冻结/仅输出层/全网络之间按来源验证分数选择，外层测试不参与。两个种子20261118/19使用相同来源划分，分别训练，结果不是融合。\n\n'
    text+='没有新增蒸馏、合成增强或额外0.94m修正。比较的是冻结、随机重训和两种TI初始化微调方案；学习率及冻结策略不同，因此不是只改变初始化的单变量因果消融。补充表单列冻结输出减0.94m。所有NN保留负预测，不截零。\n\n'
    text+='## 场景留一结果\n\n'+table_text(main)+'\n'
    text+='表中为两次训练指标的均值；N是每次测试path数，未把两个种子重复计数。ALL分位数逐种子从全部误差计算后再平均，不是场景分位数平均。标准差见CSV，不能作为新场景总体置信区间。e=预测−真值；CEP95为|e|的P95。\n\n'
    text+='ALL为按实际path数汇总，台架数据占比较大；另提供四个场景等权的宏平均MAE，不能把场景P5或CEP95的平均当作总体分位数。\n\n'+macro.groupby('method').scene_macro_mae_m.agg(['mean','std']).to_csv()+'\n'
    text+='## 实车远距离外推\n\n'+table_text(far)+'\n'
    text+='实车留出折的来源场景只有1～15m参考距离，实车>15m同时包含未见距离外推。远距离无训练覆盖时，微调不能保证改善，且可能遗忘原模型行为。其他三折含来源实车远距离数据，任务难度不同。\n\n'
    text+='## 实车冻结校准对照\n\n'+table_text(comparison)+'\n'
    text+='减0.94m为此前已指定的独立输出校准，只用于补充冻结对照，不据本次测试拟合，也不自动叠加到已按真值微调的模型。\n\n'
    text+='## 来源验证选择\n\n'+selected.to_csv(index=False)+'\n'
    text+='## 训练曲线\n\n'
    for method in METHODS:text+=f'![{method}](learning_curves_{method}.png)\n\n'
    text+='训练曲线为epoch内更新过程中累计的加权MSE；验证为该epoch结束后的固定模型加权MSE，两者观察时点不同。最终选中模型的固定训练/验证误差及远距离诊断另见各折fit_diagnostics.csv。\n\n'
    text+='逐实车锚点、path、锚点×path和锚点×距离指标见car_details_two_seeds.csv；逐条件及远距离指标见metrics_two_seeds.csv。predictions_seed_*.csv.gz通过source_index关联sources.csv可追溯原日志及行号。每折model_meters.pt是独立留出模型，不存在一个在全部数据训练后再冒充留出验证的模型。\n\n'
    text+='模型加载入口为父工程predict_ti_finetuned_iq.py中的predict_finetuned_iq；输入已经双向合成和相位校准、升序80点的复数IQ，内部先执行SDK时域窗再构造协方差。导出模型直接输出米，不再乘30、不减0.94m、不截零。旧无窗独立path适配器不能直接替代该入口。\n\n'
    text+='本队列此前多次用于开发，本次为开发数据上的场景留一；未获得新车辆、新场地盲测。\n'
    (OUT/'report.md').write_text(text,encoding='utf-8')
    write_json(OUT/'run_summary.json',dict(dataset_version=VERSION,n_paths=len(x),seeds=list(SEEDS),
        models=len(SEEDS)*len(SCENES)*len(METHODS),model_selection_uses_outer_test=False,
        output_prediction_sha256={p.name:sha(p) for p in csv_paths},script_sha256=sha(__file__)))
    print('REPORT MAIN\n'+main.to_string(index=False),flush=True)


def verify():
    sources,x,coords,truth=load_data();si=coords['source_index'];rows=[]
    spec=json.loads((OUT/'dataset_protocol.json').read_text(encoding='utf-8'))
    for name,digest in spec['artifact_sha256'].items():assert sha(OUT/name)==digest
    plan=json.loads((OUT/'experiment_plan.json').read_text(encoding='utf-8'))
    assert sha(BASE/'outputs/ti_nn_reverse_20261117/ti_ffn_weights_raw.npz')==plan['original_weights_sha256']
    checkpoint_count=0
    for seed in SEEDS:
        for held in SCENES:
            ss=split_sources(sources,held);tr=np.flatnonzero(np.isin(si,ss['train']));va=np.flatnonzero(np.isin(si,ss['validation']));te=np.flatnonzero(np.isin(si,ss['test']))
            assert not set(coords['frame_id'][tr])&set(coords['frame_id'][te])
            weights=row_weights(sources,ss['train'],si[tr]);df=pd.DataFrame(dict(scene=sources.scene.to_numpy()[si[tr]],weight=weights))
            by_scene=df.groupby('scene').weight.sum().to_numpy();assert np.max(by_scene)-np.min(by_scene)<len(tr)*1e-5
            for method in METHODS:
                folder=OUT/f'seed_{seed}'/f'leave_{held}'/method
                obj=torch.load(folder/'model_meters.pt',map_location='cpu',weights_only=True);p=obj['protocol']
                assert held not in set(sources.scene.iloc[ss['train']]) and p['test_n']==len(te)
                assert p['output_unit'].startswith('meters') and not p['test_used_for_fitting_or_selection']
                model=TiApuArchitecture();model.load_state_dict(obj['state_dict'])
                with np.load(folder/'predictions.npz') as c:
                    np.testing.assert_array_equal(c['sample_id'],te)
                    loc=np.unique(np.linspace(0,len(te)-1,min(256,len(te))).astype(int));saved=c['prediction_m'][loc]
                replay=predict_model(model,x,te[loc]);error=float(abs(replay-saved).max());assert error<3e-4
                curve=pd.read_csv(folder/'learning_curve.csv');allowed=curve if method!='scratch' else curve[curve.epoch>0]
                # argmin with the same minimum-improvement tolerance as training.
                best=np.inf;epoch=-1
                for r in allowed.itertuples():
                    if r.validation_balanced_mae_m<best-1e-5:best=r.validation_balanced_mae_m;epoch=int(r.epoch)
                assert epoch==p['best_epoch'] and abs(best-p['best_source_validation_balanced_mae_m'])<1e-8
                rows.append(dict(seed=seed,held_scene=held,method=method,reload_max_error_m=error,best_epoch=epoch,
                    source_session_frame_isolation=True))
                checkpoint_count+=1
    assert checkpoint_count==24
    # Real-car labels must agree with the authoritative 3D geometry.
    for r in sources[sources.scene.eq('实车')].itertuples():assert abs(r.truth_m-float(range_truth(r.nominal_m,r.anchor)))<1e-10
    for seed in SEEDS:
        p=pd.read_csv(OUT/f'predictions_seed_{seed}.csv.gz',usecols=['sample_id','truth_m','ti_selected_m'])
        np.testing.assert_array_equal(p.sample_id,np.arange(len(x)));np.testing.assert_allclose(p.truth_m,truth,atol=1e-10,rtol=0)
        assert np.isfinite(p.ti_selected_m).all()
    from predict_ti_finetuned_iq import predict_finetuned_iq
    end_to_end=[]
    for scene,g in sources.groupby('scene'):
        r=g.iloc[0];start=int(r.sample_start);stop=min(int(r.sample_stop),start+8)
        if r.cache_file:
            with np.load(r.cache_file) as c:
                iq=c['iq'][:stop-start].astype(np.float64)
                z=iq[:,:,0]+1j*iq[:,:,1]
        else:
            raw,_=_parse_log(Path(r.file),complete_four_paths=False)
            z=np.stack([v[5] for v in raw[:stop-start]])
        for seed in SEEDS:
            for method in METHODS:
                checkpoint=OUT/f'seed_{seed}'/f'leave_{scene}'/method/'model_meters.pt'
                a=predict_finetuned_iq(z,checkpoint)
                saved=torch.load(checkpoint,map_location='cpu',weights_only=True)
                m=TiApuArchitecture();m.load_state_dict(saved['state_dict'])
                b=predict_model(m,x,np.arange(start,stop))
                err=float(abs(a-b).max());assert err<3e-4
                end_to_end.append(dict(scene=scene,seed=seed,method=method,max_error_m=err))
    pd.DataFrame(rows).to_csv(OUT/'verification_models.csv',index=False)
    write_json(OUT/'verification.json',dict(models_reloaded=checkpoint_count,source_session_frame_isolation=True,
        source_only_epoch_selection_recomputed=True,car_labels_3D_checked=True,predictions_unique_once_per_seed=True,
        maximum_reload_error_m=max(r['reload_max_error_m'] for r in rows),
        raw_IQ_to_exported_model_cases=len(end_to_end),maximum_raw_IQ_replay_error_m=max(r['max_error_m'] for r in end_to_end),
        native_TI_pipeline_or_target_chip_equivalence_claimed=False))
    print('VERIFICATION COMPLETE',checkpoint_count,'models',flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['prepare','train','report','verify','all'],default='all')
    parser.add_argument('--epochs',type=int,default=25);parser.add_argument('--batch-size',type=int,default=4096)
    args=parser.parse_args();sys.stdout.reconfigure(encoding='utf-8')
    torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    if args.stage in ['prepare','all']:prepare()
    if args.stage in ['train','all']:
        sources,x,coords,truth=load_data();frozen_predictions(sources,x,coords)
        for seed in SEEDS:
            for held in SCENES:
                for method in METHODS:train_fold(sources,x,coords,truth,held,seed,method,args.epochs,args.batch_size)
    if args.stage in ['report','all']:report()
    if args.stage in ['verify','all']:verify()


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
