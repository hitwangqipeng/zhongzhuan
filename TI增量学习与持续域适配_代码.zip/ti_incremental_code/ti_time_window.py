"""TI9.23 computeWindow operator and explicit NetHist window-state adapter.

The caller supplies peakBinSAP. Estimating that state from a single path's
largest IFFT bin is a separate experimental adapter, not part of this port.
"""
from pathlib import Path
from functools import lru_cache
import numpy as np

BASE=Path(__file__).resolve().parent
PROCESS_OBJECT=BASE/'outputs/ti_nn_reverse_20261117/objects_gcc/BleCsRangingProcess.c.obj'


@lru_cache(maxsize=1)
def load_filter96():
    from elftools.elf.elffile import ELFFile
    with PROCESS_OBJECT.open('rb') as stream:
        elf=ELFFile(stream)
        symbol=elf.get_section_by_name('.symtab').get_symbol_by_name('pTWFilter96')[0]
        section=elf.get_section(symbol['st_shndx'])
        start=symbol['st_value'];raw=section.data()[start:start+symbol['st_size']]
    a=np.frombuffer(raw,dtype='<f4').copy()
    if len(a)!=96:raise ValueError('Unexpected SDK pTWFilter96 size')
    a.setflags(write=False)
    return a


def compute_window(nfft,center_bin,window_type=2,win_len=32):
    """Port of computeWindow: center_bin is NOT peakBinSAP.

    The original routine writes complex numbers with zero imaginary parts.
    Return its real weights, including the alternate type1/len64 table branch.
    """
    if nfft<32 or nfft & (nfft-1) or nfft>65535:
        raise ValueError('Expected a power-of-two FFT length in32..32768')
    if not 0<=int(center_bin)<=65535:raise ValueError('center_bin must fit uint16')
    half=nfft//2
    if window_type==1 and win_len==64:
        if nfft<128:raise ValueError('96-entry window requires nfft>=128')
        w=np.zeros(nfft,np.float32)
        start=half+int(center_bin)-64
        if start<0 or start+96>nfft:
            raise ValueError('SDK96-entry table would write beyond the allocated window')
        w[start:start+96]=load_filter96()
        return np.roll(w,half)
    sigma=np.float32(nfft>>4)
    k=np.arange(half,dtype=np.float32)
    t=(k/sigma).astype(np.float32)
    exponent=(t*t*np.float32(-.5)).astype(np.float32)
    gaussian=np.exp(exponent).astype(np.float32)
    plateau=min(int(center_bin),half)
    positive=np.ones(half,np.float32)
    positive[plateau:]=gaussian[:half-plateau]
    return np.r_[positive,gaussian[::-1]]


def hist_window(peak_bin_sap,nfft=256,pdp_nfft=256,window_type=2,win_len=32):
    """Window setup in extractFeatureHist, including zero-state bypass.

    Other branch conditions (SNR and history) belong to the caller. This
    function explicitly assumes the windowed-current-PCT branch is selected.
    """
    p=int(peak_bin_sap)
    if not 0<=p<=65535:raise ValueError('peak_bin_sap must fit uint16')
    if pdp_nfft<=0:
        raise ValueError('Require a positive PDP FFT length')
    if p==0:return np.ones(nfft,np.float32)
    # SDK computes a uint16 center after an integer FFT-length ratio.
    center=((p+1)*(nfft//pdp_nfft)) & 0xffff
    return compute_window(nfft,center,window_type,win_len)


def apply_window(iq,peak_bin_sap,nfft=256,pdp_nfft=256,window_type=2,win_len=32):
    """IQ -> inverse FFT -> SDK-state-driven time window -> FFT -> IQ bins.

    No reference distance, no peak estimator and no cross-path fusion here.
    """
    z=np.asarray(iq)
    if z.ndim!=2 or not np.isfinite(z).all() or z.shape[1]>nfft:
        raise ValueError('Expected finite complex N x tones with tones<=nfft')
    peaks=np.broadcast_to(np.asarray(peak_bin_sap),(len(z),))
    w=np.stack([hist_window(p,nfft,pdp_nfft,window_type,win_len) for p in peaks])
    h=np.fft.ifft(z,nfft,axis=1)
    return np.fft.fft(h*w,nfft,axis=1)[:,:z.shape[1]]


def analyze_pdp(pdp):
    """Decision fields of SDK analyzePDP (not its distance/RMS reporting).

    Its threshold is max(estimated negative-delay noise x15.8489,
    global maximum x0.0158489), as set by initIfftParams.
    """
    p=np.asarray(pdp,np.float32)
    if p.ndim!=2 or not np.isfinite(p).all() or (p<0).any():
        raise ValueError('Expected finite nonnegative N x FFT PDP')
    n=p.shape[1];half=n//2
    if n<128 or n & (n-1):raise ValueError('Require power-of-two nfft>=128')
    maximum=p.max(axis=1);argmax=p.argmax(axis=1)
    # Preserve the SDK's sequential float32 noise accumulation.
    noise_sum=np.zeros(len(p),np.float32)
    for i in range(half+16,n-n//32):noise_sum+=p[:,i]
    noise=noise_sum/np.float32(n-n//32-half-16)
    threshold=np.maximum(noise*np.float32(15.848932266235352),maximum*np.float32(.015848930925130844))
    above=p[:,1:half-1]>threshold[:,None]
    first=np.where(above.any(axis=1),above.argmax(axis=1)+1,0)
    # analyzePDP compares the threshold against the PRECEDING sample when
    # counting a strict local maximum (s15 holds p[i-1] at0x0174).
    local=(p[:,1:half-1]>p[:,:half-2]) & (p[:,1:half-1]>p[:,2:half]) & (p[:,:half-2]>threshold[:,None])
    count=local.sum(axis=1)
    valid=(argmax<half)&(count>0)
    first=np.where(valid,first,0).astype(np.int32)
    count=np.where(valid,count,0).astype(np.int32)
    return dict(valid=valid,first_crossing=first,peak_count=count,noise=noise,threshold=threshold)


def estimate_single_path_state(iq,nfft=256):
    """computeCorrelogram's fresh single-path branch, with no temporal IIR.

    Linear frequency autocorrelation + Hermitian completion + IFFT gives
    power; the subsequent abs via complex multiply/sqrt keeps that power.
    It equals a common positive scaling of abs(IFFT(IQ))**2. That scale cancels
    from analyzePDP decisions. SDK prepends6 wrap samples, applies causal4
    averaging, then subtracts4 from the first crossing for peakBinSAP.
    The original 80-tone log adapter is retained, not TI75-tone recovery.
    """
    z=np.asarray(iq)
    if z.ndim!=2 or z.shape[1]>nfft//2 or not np.isfinite(z).all():
        raise ValueError('Expected finite batch with tones<=nfft/2')
    power=(abs(np.fft.ifft(z,nfft,axis=1))**2).astype(np.float32)
    padded=np.concatenate([power[:,-6:],power[:,:-1]],axis=1)
    smooth=np.zeros_like(power)
    for i in range(nfft):
        # Match scalar loop addition order: newest, preceding1,2,3.
        value=padded[:,i].copy()
        for j in range(1,min(i,3)+1):value+=padded[:,i-j]
        smooth[:,i]=value*np.float32(.25)
    decision=analyze_pdp(smooth)
    eligible=decision['valid'] & (decision['first_crossing']>3)
    state=np.where(eligible,decision['first_crossing']-4,0).astype(np.int32)
    decision.update(peak_bin_sap=state,correlogram_valid=eligible,pdp_smoothed=smooth)
    return decision


def preprocess_single_path(iq,return_state=False):
    state=estimate_single_path_state(iq)
    result=apply_window(iq,state['peak_bin_sap'])
    return (result,state) if return_state else result
