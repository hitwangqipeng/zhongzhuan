"""Small FC3-bias module: source-only P5 gating and strict monotonic variant.

All four scene holdouts use the existing full labelled-data cohort. The held
scene never enters fitting, tail-mask creation, epoch choice, or LR choice.
"""
from pathlib import Path
import argparse
import copy
import json
import sys
import time

import numpy as np
import pandas as pd
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

import experiment_ti_finetune_all_loso as data
from audit_ti_finetune_implementation import canonical_model
from ti_fc3_bias_adapter import TiFc3BiasAdapter,load_adapter,predict_fc3_bias_iq

BASE=Path(__file__).resolve().parent
OUT=BASE/'outputs/ti_fc3_bias_p5_20261118'
LRS=(1e-6,3e-6)
SEEDS=(20261118,20261119)
MODES=('free','monotonic')
EPOCHS=12
BATCH=4096
RADIUS=.02
P5_NUMERICAL_TOL_M=1e-6


def write_json(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


def run_folder(seed,scene,mode,lr):
    return OUT/f'seed_{seed}'/f'leave_{scene}'/f'{mode}_lr{lr:.0e}'


def prepare():
    OUT.mkdir(parents=True,exist_ok=True)
    sources,x,coords,truth=data.load_data()
    if not (OUT/'experiment_plan.json').exists():
        write_json(OUT/'experiment_plan.json',dict(implementation='ti_fc3_bias24_p5_v1',
            scenes=list(data.SCENES),seeds=list(SEEDS),lrs=list(LRS),epochs=EPOCHS,batch_size=BATCH,
            modes=list(MODES),bias_radius=RADIUS,max_parameter_step='current nominal LR; explicit projection each update',
            optimizer='Adam, no weight decay on bias delta',
            objective='weighted normalized MSE + source-training-teacher-lowest5% one-sided decrease penalty +0.1 output distillation',
            source_validation_gates='signed P5 noninferiority per scene, scene x distance bin, scene x path; numerical tolerance1e-6m',
            baseline='uncalibrated frozen original TI, same preprocessing',
            strict_release='only monotonic candidates or frozen baseline; source validation selects LR/epoch',
            held_scene_used_for_fitting_or_selection=False,independent_new_blind_test=False,
            source_dataset=str(data.OUT),source_dataset_sha256=data.sha(data.OUT/'dataset_protocol.json')))
    marker=OUT/'feature_protocol.json'
    if marker.exists():
        p=json.loads(marker.read_text(encoding='utf-8'))
        assert p['source_feature_sha256']==data.sha(data.OUT/'features.npy')
        assert p['preactivation_sha256']==data.sha(OUT/'fc3_preactivation.npy')
        assert p['teacher_sha256']==data.sha(OUT/'teacher_m.npy')
        return sources,x,coords,truth
    model=TiFc3BiasAdapter(canonical_model());model.eval()
    a=np.lib.format.open_memmap(OUT/'fc3_preactivation.partial.npy',mode='w+',dtype=np.float32,shape=(len(x),24))
    teacher=np.empty(len(x),np.float32)
    with torch.no_grad():
        for start in range(0,len(x),8192):
            xx=torch.from_numpy(np.array(x[start:start+8192],copy=True))
            h=model.fc3_preactivation(xx);p,t=model.from_preactivation(h,True)
            assert torch.equal(p,t)
            a[start:start+len(xx)]=h.numpy();teacher[start:start+len(xx)]=t.numpy()
    a.flush();del a;(OUT/'fc3_preactivation.partial.npy').replace(OUT/'fc3_preactivation.npy')
    np.save(OUT/'teacher_m.npy',teacher)
    old=np.load(data.OUT/'frozen_predictions.npy',mmap_mode='r')
    difference=float(abs(old-teacher).max());assert difference<3e-4
    write_json(marker,dict(n=len(x),features=24,feature='frozen FC3 preactivation, including original FC3 bias',
        source_feature_sha256=data.sha(data.OUT/'features.npy'),
        preactivation_sha256=data.sha(OUT/'fc3_preactivation.npy'),teacher_sha256=data.sha(OUT/'teacher_m.npy'),
        numpy_teacher_max_difference_m=difference,teacher_is_unmodified_TI=True))
    print('PREPARED',len(x),'rows; teacher difference',difference,flush=True)
    return sources,x,coords,truth


def validation_groups(sources,coords,truth,ids):
    si=coords['source_index'][ids];scenes=sources.scene.to_numpy()[si]
    bins=np.digitize(truth[ids],[5,10,15,20,30]);paths=coords['path'][ids]
    groups={}
    for scene in sorted(set(scenes)):
        mask=scenes==scene;groups['scene:'+scene]=np.flatnonzero(mask)
        for value in sorted(set(bins[mask])):
            ix=np.flatnonzero(mask&(bins==value))
            if len(ix)>=256:groups[f'range:{scene}:{value}']=ix
        for value in sorted(set(paths[mask])):
            ix=np.flatnonzero(mask&(paths==value))
            if len(ix)>=256:groups[f'path:{scene}:{value}']=ix
    return groups


def gate_p5(pred,truth,teacher,groups):
    err=pred.astype(np.float64)-truth;ref=teacher.astype(np.float64)-truth
    changes={key:float(np.quantile(err[ix],.05)-np.quantile(ref[ix],.05)) for key,ix in groups.items()}
    worst=min(changes.values())
    return worst>=-P5_NUMERICAL_TOL_M,worst,changes


def predict_cached(model,a,ids):
    model.eval();out=np.empty(len(ids),np.float32)
    with torch.no_grad():
        for start in range(0,len(ids),16384):
            h=torch.from_numpy(np.array(a[ids[start:start+16384]],copy=True))
            out[start:start+len(h)]=model.from_preactivation(h).numpy()
    return out


def training_tail(sources,coords,truth,tr,teacher):
    si=coords['source_index'][tr];scenes=sources.scene.to_numpy()[si]
    bins=np.digitize(truth[tr],[5,10,15,20,30]);e=teacher[tr].astype(float)-truth[tr]
    mask=np.zeros(len(tr),bool);thresholds=[]
    for scene in sorted(set(scenes)):
        for value in sorted(set(bins[scenes==scene])):
            ix=np.flatnonzero((scenes==scene)&(bins==value));q=float(np.quantile(e[ix],.05))
            mask[ix]=e[ix]<=q
            thresholds.append(dict(scene=scene,range_bin=int(value),n=len(ix),teacher_train_error_p5_m=q))
    return mask,thresholds


def fit(sources,a,coords,truth,teacher,seed,scene,mode,lr):
    folder=run_folder(seed,scene,mode,lr);folder.mkdir(parents=True,exist_ok=True)
    if (folder/'protocol.json').exists():return
    ss=data.split_sources(sources,scene);si=coords['source_index']
    split={key:np.flatnonzero(np.isin(si,ids)) for key,ids in ss.items()}
    tr,va,te=[split[key] for key in ['train','validation','test']]
    groups=validation_groups(sources,coords,truth,va)
    weight=data.row_weights(sources,ss['train'],si[tr]);tail,thresholds=training_tail(sources,coords,truth,tr,teacher)
    tail_mass=float(np.mean(weight*tail));assert tail_mass>0
    torch.manual_seed(seed+100*data.SCENES.index(scene));rng=np.random.default_rng(seed+100*data.SCENES.index(scene))
    model=TiFc3BiasAdapter(canonical_model(),monotonic=mode=='monotonic',bias_radius=RADIUS)
    assert sum(p.numel() for p in model.parameters() if p.requires_grad)==24
    base=model.teacher.state_dict();initial_teacher={k:v.detach().clone() for k,v in base.items()}
    optimizer=torch.optim.Adam([model.delta],lr=lr)
    ht=torch.from_numpy(np.array(a[tr],copy=True));yt=torch.from_numpy(truth[tr].astype(np.float32))
    wt=torch.from_numpy(weight);mt=torch.from_numpy(tail.astype(np.float32))
    initial=predict_cached(model,a,va);assert np.array_equal(initial,teacher[va])
    score=data.validation_metrics(initial,truth[va],si[va],sources)[0]
    best=(score,0,model.delta.detach().clone());raw=(score,0,model.delta.detach().clone())
    history=[dict(epoch=0,lr=lr,train_loss=np.nan,validation_mae_m=score,p5_feasible=True,
        worst_p5_change_m=0.,max_bias_change=0.,maximum_parameter_step=0.,batch_prediction_step_max_m=0.,
        max_validation_prediction_change_m=0.)]
    accepted=0;max_step_all=0.;start_time=time.perf_counter()
    print('FIT',seed,scene,mode,lr,'train',len(tr),'validation',len(va),'groups',len(groups),flush=True)
    for epoch in range(1,EPOCHS+1):
        current_lr=lr*(.1+.9*.5*(1+np.cos(np.pi*(epoch-1)/(EPOCHS-1))))
        optimizer.param_groups[0]['lr']=current_lr
        model.train();order=rng.permutation(len(tr));total=0.;max_step=0.;pred_step=0.
        for start in range(0,len(order),BATCH):
            ix=order[start:start+BATCH];optimizer.zero_grad(set_to_none=True)
            out,ref=model.from_preactivation(ht[ix],True)
            fit_loss=torch.mean(wt[ix]*((out-yt[ix])/30).square())
            tail_loss=torch.mean(wt[ix]*mt[ix]*F.relu((ref-out)/30))/tail_mass
            keep_loss=torch.mean(wt[ix]*((out-ref)/30).square())
            loss=fit_loss+tail_loss+.1*keep_loss
            loss.backward();previous=model.delta.detach().clone();optimizer.step();model.project_(previous,current_lr)
            step=float((model.delta.detach()-previous).abs().max());max_step=max(max_step,step)
            assert step<=current_lr+1e-9
            if start==0:
                with torch.no_grad():new=model.from_preactivation(ht[ix]);pred_step=float(abs(new-out.detach()).max())
            total+=float(loss.detach())*len(ix)
        vp=predict_cached(model,a,va)
        feasible,worst,_=gate_p5(vp,truth[va],teacher[va],groups)
        score=data.validation_metrics(vp,truth[va],si[va],sources)[0]
        if mode=='monotonic':assert np.all(vp>=teacher[va]) and feasible
        if score<raw[0]-1e-7:raw=(score,epoch,model.delta.detach().clone())
        if feasible:
            accepted+=1
            if score<best[0]-1e-7:best=(score,epoch,model.delta.detach().clone())
        max_step_all=max(max_step_all,max_step)
        history.append(dict(epoch=epoch,lr=current_lr,train_loss=total/len(tr),validation_mae_m=score,
            p5_feasible=feasible,worst_p5_change_m=worst,max_bias_change=float(model.delta.detach().abs().max()),
            maximum_parameter_step=max_step,batch_prediction_step_max_m=pred_step,
            max_validation_prediction_change_m=float(abs(vp-teacher[va]).max())))
        pd.DataFrame(history).to_csv(folder/'learning_curve.csv',index=False)
        print('EPOCH',seed,scene,mode,lr,epoch,'val',round(score,6),'p5_delta',round(worst,6),
            'accepted',feasible,'best',best[1],'seconds',round(time.perf_counter()-start_time,1),flush=True)
    protocol=dict(implementation='ti_fc3_bias24_p5_v1',source_dataset_version=data.VERSION,
        seed=seed,held_scene=scene,mode=mode,monotonic=mode=='monotonic',lr=lr,epochs=EPOCHS,
        best_epoch=best[1],best_source_validation_mae_m=best[0],raw_best_epoch=raw[1],raw_best_validation_mae_m=raw[0],
        source_validation_P5_feasible_epochs=accepted,trainable_parameters=24,updated_original_key='layers.4.bias',
        all_other_parameters_and_affine_frozen=True,bias_radius=RADIUS,
        parameterization='original TI parameter units; no forward scaling; train delta bias only',
        single_step_cap='current learning rate',maximum_observed_parameter_step=max_step_all,
        universal_absolute_distance_change_bound_m=model.distance_change_bound_m(),
        P5_baseline='frozen uncalibrated TI, shared teacher branch',p5_numerical_tolerance_m=P5_NUMERICAL_TOL_M,
        group_gate='all source scene, scene x distance bin, scene x path groups with>=256 rows',
        held_scene_used_for_training_or_selection=False,path_fusion=False,shared_model_all_paths=True,
        input='already combined calibrated80IQ -> SDK stateless time window ->156D',output_unit='meters',
        train_n=len(tr),validation_n=len(va),test_n=len(te),tail_thresholds_training_only=thresholds,
        raw_best_saved_for_diagnostics_not_selection=True)
    allpred={};delta_snapshots={}
    for label,state in [('gated',best),('raw_best',raw)]:
        with torch.no_grad():model.delta.copy_(state[2])
        vp=predict_cached(model,a,va);p=predict_cached(model,a,te)
        if mode=='monotonic':assert np.all(p>=teacher[te])
        assert np.max(abs(p-teacher[te]))<=model.distance_change_bound_m()+1e-4
        for k,v in model.teacher.state_dict().items():assert torch.equal(v,initial_teacher[k]),k
        feasible,worst,changes=gate_p5(vp,truth[va],teacher[va],groups)
        if label=='gated':assert feasible
        saved_protocol=dict(protocol,checkpoint_kind=label,checkpoint_epoch=state[1],
            worst_validation_p5_change_m=worst,source_validation_p5_feasible=feasible,
            max_bias_change=float(state[2].abs().max()))
        torch.save(dict(protocol=saved_protocol,teacher_state_dict=model.teacher.state_dict(),delta=state[2]),folder/f'{label}_adapter.pt')
        allpred[label+'_m']=p;delta_snapshots[label]=state[2].numpy()
        write_json(folder/f'{label}_validation_p5.json',changes)
    np.savez_compressed(folder/'predictions.npz',sample_id=te,**allpred)
    np.savez_compressed(folder/'delta_snapshots.npz',**delta_snapshots)
    write_json(folder/'protocol.json',protocol)


def summary(sources,a,coords,truth,teacher):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','DejaVu Sans'];plt.rcParams['axes.unicode_minus']=False
    si=coords['source_index'];rows=[];choices=[];verification=[];details=[]
    for seed in SEEDS:
        complete={key:np.full(len(a),np.nan,np.float32) for key in ['validation_selected','strict_selected','free_raw_best','monotonic_raw_best']}
        for scene in data.SCENES:
            ss=data.split_sources(sources,scene);te=np.flatnonzero(np.isin(si,ss['test']))
            va=np.flatnonzero(np.isin(si,ss['validation']));groups=validation_groups(sources,coords,truth,va)
            base_score=data.validation_metrics(teacher[va],truth[va],si[va],sources)[0]
            candidates=[dict(mode='frozen',lr=0.,score=base_score,epoch=0,pred=teacher[te],folder=None)]
            raw_candidates={mode:[] for mode in MODES}
            for mode in MODES:
                for lr in LRS:
                    folder=run_folder(seed,scene,mode,lr);p=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))
                    with np.load(folder/'predictions.npz') as c:
                        np.testing.assert_array_equal(c['sample_id'],te)
                        gp=c['gated_m'];rp=c['raw_best_m']
                    m,_=load_adapter(folder/'gated_adapter.pt')
                    vp=predict_cached(m,a,va);feasible,worst,_=gate_p5(vp,truth[va],teacher[va],groups);assert feasible
                    loc=np.unique(np.linspace(0,len(te)-1,128).astype(int))
                    replay=predict_cached(m,a,te[loc]);error=float(abs(replay-gp[loc]).max());assert error<3e-4
                    if mode=='monotonic':assert np.all(gp>=teacher[te]) and np.all(rp>=teacher[te])
                    candidates.append(dict(mode=mode,lr=lr,score=p['best_source_validation_mae_m'],epoch=p['best_epoch'],pred=gp,folder=str(folder)))
                    raw_candidates[mode].append(dict(score=p['raw_best_validation_mae_m'],pred=rp))
                    verification.append(dict(seed=seed,scene=scene,mode=mode,lr=lr,reload_max_error_m=error,
                        worst_validation_p5_change_m=worst,max_parameter_step=p['maximum_observed_parameter_step']))
            selected=min(candidates,key=lambda c:c['score'])
            strict=min([c for c in candidates if c['mode'] in ['frozen','monotonic']],key=lambda c:c['score'])
            release_dir=OUT/f'seed_{seed}'/f'leave_{scene}'
            for name,choice in [('validation_selected',selected),('strict_selected',strict)]:
                if choice['folder']:
                    saved=torch.load(Path(choice['folder'])/'gated_adapter.pt',map_location='cpu',weights_only=True)
                    saved['protocol']=dict(saved['protocol'],release_policy=name,source_only_release_selection=True)
                else:
                    empty=TiFc3BiasAdapter(canonical_model(),monotonic=True,bias_radius=RADIUS)
                    saved=dict(teacher_state_dict=empty.teacher.state_dict(),delta=empty.delta.detach().clone(),
                        protocol=dict(implementation='ti_fc3_bias24_p5_v1',monotonic=True,bias_radius=RADIUS,
                            release_policy=name,seed=seed,held_scene=scene,checkpoint_epoch=0,
                            trainable_parameters=24,source_only_release_selection=True,frozen_fallback=True))
                torch.save(saved,release_dir/f'{name}_adapter.pt')
            complete['validation_selected'][te]=selected['pred'];complete['strict_selected'][te]=strict['pred']
            for mode in MODES:complete[mode+'_raw_best'][te]=min(raw_candidates[mode],key=lambda c:c['score'])['pred']
            choices.append(dict(seed=seed,scene=scene,mode=selected['mode'],lr=selected['lr'],epoch=selected['epoch'],
                source_validation_score=selected['score'],strict_mode=strict['mode'],strict_lr=strict['lr'],
                strict_epoch=strict['epoch'],strict_source_validation_score=strict['score'],frozen_source_validation_score=base_score,
                selected_checkpoint=selected['folder'],strict_checkpoint=strict['folder']))
        complete['frozen_TI']=teacher
        assert np.all(complete['strict_selected']>=teacher)
        for method,pred in complete.items():
            assert np.isfinite(pred).all()
            for scene in ['ALL',*data.SCENES]:
                ids=np.arange(len(a)) if scene=='ALL' else np.flatnonzero(sources.scene.to_numpy()[si]==scene)
                scopes=[('ALL',np.ones(len(ids),bool)),('true_le15m',truth[ids]<=15),('true_gt15m',truth[ids]>15)]
                if scene=='实车':
                    conditions=sources.condition.to_numpy()[si[ids]]
                    for condition in ['LOS','NLOS']:scopes.append(('condition:'+condition,conditions==condition))
                for scope,mask in scopes:
                    if not mask.any():continue
                    m=data.metrics(pred[ids][mask],truth[ids][mask]);base=data.metrics(teacher[ids][mask],truth[ids][mask])
                    rows.append(dict(seed=seed,scene=scene,scope=scope,method=method,
                        p5_change_m=m['error_p5_m']-base['error_p5_m'],mae_change_m=m['mae_m']-base['mae_m'],
                        max_prediction_change_m=float(abs(pred[ids][mask]-teacher[ids][mask]).max()),**m))
            car=np.flatnonzero(sources.scene.to_numpy()[si]=='实车')
            for condition in ['ALL','LOS','NLOS']:
                ix=car if condition=='ALL' else car[sources.condition.to_numpy()[si[car]]==condition]
                keys=pd.DataFrame(dict(anchor=sources.anchor.to_numpy()[si[ix]],path=coords['path'][ix]))
                for (anchor,path),local in keys.groupby(['anchor','path'],sort=True).indices.items():
                    ids=ix[local];m=data.metrics(pred[ids],truth[ids]);base=data.metrics(teacher[ids],truth[ids])
                    details.append(dict(seed=seed,condition=condition,anchor=anchor,path=int(path),method=method,
                        p5_change_m=m['error_p5_m']-base['error_p5_m'],**m))
        np.savez_compressed(OUT/f'out_of_scene_seed_{seed}.npz',**{key+'_m':v for key,v in complete.items()})
    each=pd.DataFrame(rows);each.to_csv(OUT/'metrics_each_seed.csv',index=False)
    fields=['mae_m','error_p5_m','abs_error_p5_m','cep95_m','bias_m','under3_pct','over3_pct','p5_change_m','mae_change_m','max_prediction_change_m']
    avg=each.groupby(['scene','scope','method']).agg(n=('n','first'),**{f'{k}_{stat}':(k,stat) for k in fields for stat in ['mean','std']}).reset_index()
    avg.to_csv(OUT/'metrics_two_seeds.csv',index=False)
    detail=pd.DataFrame(details);detail.to_csv(OUT/'car_anchor_path_each_seed.csv',index=False)
    detail_fields=[k for k in fields if k not in ['mae_change_m','max_prediction_change_m']]
    detail.groupby(['condition','anchor','path','method']).agg(n=('n','first'),**{
        f'{k}_{stat}':(k,stat) for k in detail_fields for stat in ['mean','std']}).reset_index().to_csv(OUT/'car_anchor_path_two_seeds.csv',index=False)
    pd.DataFrame(choices).to_csv(OUT/'source_only_selection.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(verification).to_csv(OUT/'checkpoint_verification.csv',index=False)
    # Raw IQ replay of each selected variant, plus the monotonic guarantee.
    raw_errors=[]
    for r in choices:
        scene=r['scene'];first=sources[sources.scene.eq(scene)].iloc[0]
        if first.cache_file:
            with np.load(first.cache_file) as c:
                iq=c['iq'][:8].astype(np.float64);z=iq[:,:,0]+1j*iq[:,:,1]
        else:
            records,_=data._parse_log(Path(first.file),complete_four_paths=False);z=np.stack([v[5] for v in records[:8]])
        for policy in ['validation_selected','strict_selected']:
            checkpoint=OUT/f"seed_{r['seed']}"/f"leave_{scene}"/f'{policy}_adapter.pt'
            p,t=predict_fc3_bias_iq(z,checkpoint,return_teacher=True,require_strict_p5=policy=='strict_selected')
            model,_=load_adapter(checkpoint);ids=np.arange(int(first.sample_start),int(first.sample_start)+len(z))
            cached=predict_cached(model,a,ids);err=float(abs(p-cached).max());assert err<3e-4
            if model.monotonic:assert np.all(p>=t)
            raw_errors.append(err)
    write_json(OUT/'verification.json',dict(models_reloaded=len(verification),all_nonbias_teacher_parameters_unchanged=True,
        validation_P5_constraints_recomputed=True,strict_outputs_elementwise_ge_teacher=True,
        raw_IQ_selected_model_cases=len(raw_errors),max_raw_IQ_replay_error_m=max(raw_errors,default=0.),
        max_reload_error_m=max(r['reload_max_error_m'] for r in verification),
        nominal_lrs=list(LRS),explicit_per_step_projection=True,source_only_epoch_LR_mode_selection=True))
    fig,axes=plt.subplots(2,2,figsize=(12,7),constrained_layout=True)
    for ax,scene in zip(axes.flat,data.SCENES):
        for mode,color in [('free','#2563eb'),('monotonic','#dc2626')]:
            for lr,ls in zip(LRS,['-','--']):
                curves=[]
                for seed in SEEDS:curves.append(pd.read_csv(run_folder(seed,scene,mode,lr)/'learning_curve.csv').worst_p5_change_m.to_numpy())
                ax.plot(np.arange(EPOCHS+1),np.mean(curves,axis=0),color=color,ls=ls,label=f'{mode} lr={lr:g}')
        ax.axhline(0,color='black',lw=.8);ax.set_title(scene);ax.set_xlabel('Epoch');ax.set_ylabel('Worst source-group P5 change / m');ax.grid(alpha=.2);ax.legend(fontsize=7)
    fig.savefig(OUT/'validation_p5_curves.png',dpi=150);plt.close(fig)
    report='# FC3偏置24参数小模块：低学习率与P5约束\n\n'
    report+='沿用928份有参考值静态日志、1,690,110条path的四场景留一，两个种子。实车116,005条path，按3D几何真值计算。单path独立输入、所有path共享模型；预处理及原TI权重固定。测试场景不参与训练尾部掩码、选轮次、选学习率或选模式。\n\n'
    report+='只训练FC3的24维偏置增量，FC1/FC2、FC3权重、FC4及固定offset/gain全部冻结。原参数化，没有除参数30/forward乘30。学习率1e-6、3e-6，12个完整epoch内按余弦降到初值的1/10。Adam不对原偏置衰减；每步变化显式限制在当轮LR以内，累计偏置半径0.02。ReLU的Lipschitz性质给出全输入距离改动上限sum|FC4权重|×0.02，实际变化另记录。\n\n'
    report+='训练含真值MSE、来源训练组内冻结TI误差最低5%样本的单向降距惩罚，以及保持原输出的弱蒸馏项。来源验证对各场景、场景×距离段、场景×path检查有符号P5，容差1e-6m只用于数值误差；合格后按来源分距离段MAE选模型，无合格改善则保留epoch0冻结模型。\n\n'
    report+='free模式允许偏置双向更新，来源P5准入并不保证未知测试场景P5。monotonic模式把偏置变化方向绑定到固定FC4权重符号，增量幅值非负；由ReLU单调性，每个神经元对最终距离的变化非负。因此严格发布选择仅允许monotonic或冻结TI，在同一有效样本口径下有符号P5不会低于其冻结教师分支。它不能向下修正教师高估，也不保证MAE或CEP95不退化。\n\n'
    report+='基准统一为未减0.94m的冻结TI。缓存教师与原NumPy教师有微小浮点差异，最大值记录在feature_protocol.json；约束和指标使用共享教师分支，避免把浮点实现差异当作微调收益。\n\n'
    report+='## 场景留一结果\n\n|场景|范围|方法|N|MAE|error P5|CEP95|P5变化|MAE变化|\n|---|---|---|---|---|---|---|---|---|\n'
    for r in avg[avg.scope.eq('ALL')&avg.method.isin(['frozen_TI','validation_selected','strict_selected'])].itertuples():
        report+=f'|{r.scene}|{r.scope}|{r.method}|{r.n}|{r.mae_m_mean:.6f}|{r.error_p5_m_mean:.6f}|{r.cep95_m_mean:.6f}|{r.p5_change_m_mean:+.6f}|{r.mae_change_m_mean:+.6f}|\n'
    report+='\n## 实车远距离\n\n|方法|N|MAE|error P5|CEP95|低估>3m%|P5变化|\n|---|---|---|---|---|---|---|\n'
    for r in avg[avg.scene.eq('实车')&avg.scope.eq('true_gt15m')].itertuples():
        report+=f'|{r.method}|{r.n}|{r.mae_m_mean:.6f}|{r.error_p5_m_mean:.6f}|{r.cep95_m_mean:.6f}|{r.under3_pct_mean:.3f}|{r.p5_change_m_mean:+.6f}|\n'
    report+='\nsource_only_selection.csv列出各折实际模式、LR和epoch，frozen表示回退，并非模型已训练出收益。free_raw_best与monotonic_raw_best仅作训练诊断，不当作P5准入的发布模型。两个种子的指标分别计算后求均值，没有融合，也未重复计N。\n\n'
    report+='实车留出折来源只有1～15m，free模式不能用来源验证证明远距离P5；strict_selected通过结构限制提供相对教师的保证，但通常也会限制MAE改善。不能用抬高所有距离的办法宣称整体精度提升。\n\n![来源P5变化](validation_p5_curves.png)\n'
    report+='\n每个seed/leave_场景目录提供strict_selected_adapter.pt及validation_selected_adapter.pt；前者为严格相对P5保护入口，若无改善会保存零偏置的冻结回退模型。推理调用父工程ti_fc3_bias_adapter.py中的predict_fc3_bias_iq，默认require_strict_p5=True；只有显式关闭该参数才允许普通验证约束版。输入为已经合成及校准的升序80点复数IQ，内部完成SDK时域窗及协方差处理，直接输出米。\n'
    report+='\n实车LOS/NLOS分组见metrics_two_seeds.csv；每锚点每path的MAE、signed P5、abs P5、CEP95及相对冻结TI的P5变化见car_anchor_path_two_seeds.csv。\n'
    (OUT/'report.md').write_text(report,encoding='utf-8')
    print('SUMMARY\n'+avg[avg.scope.eq('ALL')].to_string(index=False),flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['prepare','train','report','all'],default='all');args=parser.parse_args()
    sys.stdout.reconfigure(encoding='utf-8');torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    if args.stage in ['prepare','all']:sources,x,coords,truth=prepare()
    else:sources,x,coords,truth=data.load_data()
    a=np.load(OUT/'fc3_preactivation.npy',mmap_mode='r');teacher=np.load(OUT/'teacher_m.npy',mmap_mode='r')
    if args.stage in ['train','all']:
        for seed in SEEDS:
            for scene in data.SCENES:
                for mode in MODES:
                    for lr in LRS:fit(sources,a,coords,truth,teacher,seed,scene,mode,lr)
    if args.stage in ['report','all']:summary(sources,a,coords,truth,teacher)


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
