"""Audit optimization equivalence and rerun the failing car-scene fold.

Original experiment artifacts remain untouched. Corrected models retain the
TI meter-parameterized final layer; only the residual in the loss is /30.
These are targeted development diagnostics, not a new independent benchmark.
"""
from pathlib import Path
import argparse
import copy
import json
import sys
import time

import numpy as np
import pandas as pd
import torch
from torch import nn
from threadpoolctl import threadpool_limits

import experiment_ti_finetune_all_loso as old
from ti_sdk_nn import TiApuArchitecture
from ti_pretrained_nn import load_weights, predict as teacher_predict

BASE=Path(__file__).resolve().parent
OUT=BASE/'outputs/ti_finetune_implementation_audit_20261118'


def save_json(name,value):
    (OUT/name).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


def canonical_model(dtype=torch.float32):
    model=TiApuArchitecture().to(dtype=dtype)
    off,gain,layers=load_weights()
    with torch.no_grad():
        model.input_offset.copy_(torch.from_numpy(off));model.input_gain.copy_(torch.from_numpy(gain))
        for mod,(w,b) in zip([v for v in model.layers if isinstance(v,nn.Linear)],layers):
            mod.weight.copy_(torch.from_numpy(w));mod.bias.copy_(torch.from_numpy(b))
    return model


def partitions(sources,coords):
    ss=old.split_sources(sources,'实车')
    split={key:np.flatnonzero(np.isin(coords['source_index'],ids)) for key,ids in ss.items()}
    return ss,split


def static_and_one_step(sources,x,coords,truth):
    ss,split=partitions(sources,coords);tr=split['train']
    rng=np.random.default_rng(20261418);local=rng.permutation(len(tr))[:4096];ids=tr[local]
    xx=torch.from_numpy(np.array(x[ids],copy=True));yy=torch.from_numpy(truth[ids].astype(np.float32))
    ww=torch.from_numpy(old.row_weights(sources,ss['train'],coords['source_index'][tr])[local])
    direct=canonical_model();norm=old.MeterModel(pretrained=True);noop=old.MeterModel(pretrained=True)
    for model in [direct,norm,noop]:
        for p in model.layers[:-1].parameters():p.requires_grad_(False)
    with torch.no_grad():a0=direct(xx).clone();b0=norm(xx).clone();n0=noop(xx).clone()
    originals=[m.layers[-1].weight.detach().clone() for m in [direct,norm,noop]]
    for model,lr in [(direct,1e-4),(norm,1e-4),(noop,0.)]:
        op=torch.optim.AdamW(model.parameters(),lr=lr,weight_decay=1e-4)
        op.zero_grad(set_to_none=True);loss=torch.mean(ww*((model(xx)-yy)/30).square());loss.backward();op.step()
    step_direct=float((direct.layers[-1].weight-originals[0]).abs().mean())
    step_norm=float(((norm.layers[-1].weight-originals[1])*30).abs().mean())
    with torch.no_grad():noop_output=float((noop(xx)-n0).abs().max())
    assert noop_output==0 and torch.equal(noop.layers[-1].weight,originals[2])
    # Exact optimizer mapping in float64, including epsilon and decoupled decay.
    a=canonical_model(torch.float64);b=old.MeterModel(pretrained=True).double()
    # Avoid float32 division rounding in the parameterization comparison.
    b.load_state_dict(a.state_dict())
    with torch.no_grad():b.layers[-1].weight.div_(30);b.layers[-1].bias.div_(30)
    for model in [a,b]:
        for p in model.layers[:-1].parameters():p.requires_grad_(False)
    for model,lr,eps,wd in [(a,1e-4,1e-8,1e-4),(b,1e-4/30,30e-8,30e-4)]:
        op=torch.optim.AdamW(model.parameters(),lr=lr,eps=eps,weight_decay=wd)
        loss=torch.mean(ww.double()*((model(xx.double())-yy.double())/30).square());loss.backward();op.step()
    with torch.no_grad():mapped_error=float((a(xx.double())-b(xx.double())).abs().max())
    assert mapped_error<1e-9
    original=canonical_model().state_dict();checks=[];duplicates=[]
    for p in sorted(old.OUT.glob('seed_*/leave_*/*/model_meters.pt')):
        obj=torch.load(p,map_location='cpu',weights_only=True);state=obj['state_dict'];protocol=obj['protocol']
        affine=max(float((state[key]-original[key]).abs().max()) for key in ['input_offset','input_gain'])
        hidden=max(float((state[key]-original[key]).abs().max()) for key in original if key.startswith('layers.') and not key.startswith('layers.6.'))
        assert affine==0
        if protocol['method']=='ti_head':assert hidden==0
        checks.append(dict(seed=protocol['seed'],scene=protocol['held_scene'],method=protocol['method'],affine_change=affine,hidden_change=hidden))
    for p in sorted((old.OUT/'parallel_second_seed').glob('seed_*/leave_*/*/model_meters.pt')):
        target=old.OUT/p.relative_to(old.OUT/'parallel_second_seed')
        a=torch.load(p,map_location='cpu',weights_only=True)['state_dict'];b=torch.load(target,map_location='cpu',weights_only=True)['state_dict']
        err=max(float((a[key]-b[key]).abs().max()) for key in a)
        assert err<1e-7
        duplicates.append(dict(file=str(p.relative_to(old.OUT)),maximum_parameter_difference=err))
    pd.DataFrame(checks).to_csv(OUT/'all_checkpoint_parameter_audit.csv',index=False)
    pd.DataFrame(duplicates).to_csv(OUT/'parallel_duplicate_audit.csv',index=False)
    result=dict(initial_prediction_max_difference_m=float((a0-b0).abs().max()),
        canonical_mean_parameter_step=step_direct,old_canonical_mean_parameter_step=step_norm,
        effective_head_step_ratio=step_norm/step_direct,zero_lr_prediction_change_m=noop_output,
        exact_optimizer_mapping_max_output_difference_m=mapped_error,
        checked_checkpoints=len(checks),parallel_duplicate_fits_checked=len(duplicates),
        head_hidden_layers_unchanged=True,fixed_affine_unchanged=True,
        conclusion='forward equivalence did not imply Adam optimization equivalence; old head updates were about30x larger in original TI parameter units')
    save_json('implementation_checks.json',result);print('IMPLEMENTATION_CHECKS',json.dumps(result),flush=True)


def two_parameter_control(sources,coords,truth):
    """Independent weighted closed-form affine calibration on source train only."""
    ss,split=partitions(sources,coords);si=coords['source_index']
    frozen=np.load(old.OUT/'frozen_predictions.npy',mmap_mode='r')
    tr,va,te=[split[k] for k in ['train','validation','test']]
    w=old.row_weights(sources,ss['train'],si[tr]).astype(np.float64)
    a=np.column_stack([np.asarray(frozen[tr],np.float64),np.ones(len(tr))])
    # Two-parameter linear least squares: no torch, no NN gradients or export.
    beta=np.linalg.solve(a.T@(w[:,None]*a),a.T@(w*truth[tr]))
    pred=np.asarray(frozen,np.float64)*beta[0]+beta[1]
    scores=[]
    for partition,ids in split.items():
        for scope,mask in [('ALL',np.ones(len(ids),bool)),('true_gt15m',truth[ids]>15)]:
            if mask.any():scores.append(dict(method='two_parameter_affine',partition=partition,scope=scope,**old.metrics(pred[ids][mask],truth[ids][mask])))
    pd.DataFrame(scores).to_csv(OUT/'independent_affine_control.csv',index=False)
    save_json('independent_affine_parameters.json',dict(slope=float(beta[0]),intercept_m=float(beta[1]),
        fit='weighted source training only; car labels never used to fit',training_min_m=float(truth[tr].min()),training_max_m=float(truth[tr].max())))
    print('AFFINE_CONTROL',beta.tolist(),scores[-2:],flush=True)


def fixed_features(x):
    target=OUT/'frozen_hidden24.npy'
    if target.exists():return np.load(target,mmap_mode='r')
    m=canonical_model();m.eval()
    h=np.lib.format.open_memmap(OUT/'frozen_hidden24.partial.npy',mode='w+',dtype=np.float32,shape=(len(x),24))
    with torch.no_grad():
        for start in range(0,len(x),8192):
            xx=torch.from_numpy(np.array(x[start:start+8192],copy=True))
            h[start:start+len(xx)]=m.layers[:-1]((xx-m.input_offset)*m.input_gain).numpy()
    h.flush();del h;(OUT/'frozen_hidden24.partial.npy').replace(target)
    return np.load(target,mmap_mode='r')


def run_corrected(sources,x,coords,truth,seed,method,epochs=25):
    folder=OUT/f'seed_{seed}'/method;folder.mkdir(parents=True,exist_ok=True)
    if (folder/'protocol.json').exists():return
    ss,split=partitions(sources,coords);tr,va,te=[split[k] for k in ['train','validation','test']];si=coords['source_index']
    torch.manual_seed(seed+300);rng=np.random.default_rng(seed+300);model=canonical_model()
    weights=old.row_weights(sources,ss['train'],si[tr]);ww=torch.from_numpy(weights);yy=torch.from_numpy(truth[tr].astype(np.float32))
    optimizer=torch.optim.AdamW([dict(params=list(model.layers[:-1].parameters()),lr=1e-5),
        dict(params=list(model.layers[-1].parameters()),lr=1e-4)],weight_decay=1e-4)
    # For frozen-head-only training, cache the unchanged prefix's activations.
    hidden=fixed_features(x) if method=='canonical_head' else None
    xt=torch.from_numpy(np.array(hidden[tr] if hidden is not None else x[tr],copy=True))
    def predictions(ids):
        if hidden is None:return old.predict_model(model,x,ids)
        model.eval();pieces=[]
        with torch.no_grad():
            for start in range(0,len(ids),16384):pieces.append(model.layers[-1](torch.from_numpy(np.array(hidden[ids[start:start+16384]],copy=True))).numpy()[:,0])
        return np.concatenate(pieces)
    initial=predictions(va);score,vmse,_=old.validation_metrics(initial,truth[va],si[va],sources)
    best=(score,0,copy.deepcopy(model.state_dict()));history=[]
    for scope,ids in [('validation',va),('car_test',te)]:
        pred=predictions(ids)
        for segment,mask in [('ALL',np.ones(len(ids),bool)),('true_le15m',truth[ids]<=15),('true_gt15m',truth[ids]>15)]:
            if mask.any():history.append(dict(epoch=0,partition=scope,scope=segment,**old.metrics(pred[mask],truth[ids][mask])))
    curves=[dict(epoch=0,train_online_weighted_mse=np.nan,validation_balanced_mae_m=score,validation_mse=vmse)]
    started=time.perf_counter();print('CORRECTED START',seed,method,'validation',score,flush=True)
    for epoch in range(1,epochs+1):
        head_only=method=='canonical_head' or epoch<=2
        for p in model.layers[:-1].parameters():p.requires_grad_(not head_only)
        order=rng.permutation(len(tr));total=0.;model.train()
        for start in range(0,len(order),4096):
            ix=order[start:start+4096];optimizer.zero_grad(set_to_none=True)
            out=model.layers[-1](xt[ix]).squeeze(1) if hidden is not None else model(xt[ix])
            loss=torch.mean(ww[ix]*((out-yy[ix])/30).square());loss.backward();optimizer.step()
            total+=float(loss.detach())*len(ix)
        vp=predictions(va);score,vmse,_=old.validation_metrics(vp,truth[va],si[va],sources)
        curves.append(dict(epoch=epoch,train_online_weighted_mse=total/len(tr),validation_balanced_mae_m=score,validation_mse=vmse))
        if score<best[0]-1e-5:best=(score,epoch,copy.deepcopy(model.state_dict()))
        # Test trajectory is diagnostic only; never fed to checkpoint selection.
        if epoch in [1,2,5,10,15,20,25]:
            for partition,ids in [('validation',va),('car_test',te)]:
                pred=vp if partition=='validation' else predictions(ids)
                for segment,mask in [('ALL',np.ones(len(ids),bool)),('true_le15m',truth[ids]<=15),('true_gt15m',truth[ids]>15)]:
                    if mask.any():history.append(dict(epoch=epoch,partition=partition,scope=segment,**old.metrics(pred[mask],truth[ids][mask])))
        print('CORRECTED EPOCH',seed,method,epoch,'source_val',round(score,4),'best',best[1],'seconds',round(time.perf_counter()-started,1),flush=True)
        if epoch-best[1]>=6 and epoch>=4:break
    model.load_state_dict(best[2]);pred=predictions(te)
    # Confirm cached-prefix predictions equal end-to-end canonical inference.
    loc=np.unique(np.linspace(0,len(te)-1,128).astype(int));replay=old.predict_model(model,x,te[loc]);err=float(abs(replay-pred[loc]).max());assert err<3e-4
    original=canonical_model().state_dict();hidden_error=max(float((model.state_dict()[k]-original[k]).abs().max()) for k in original if k.startswith('layers.') and not k.startswith('layers.6.'))
    if method=='canonical_head':assert hidden_error==0
    protocol=dict(dataset_version=old.VERSION,training_implementation='canonical_TΙ_meter_parameters_v2',method=method,
        seed=seed,held_scene='实车',architecture=[156,12,36,24,1],shared_model_all_paths=True,path_fusion=False,
        best_epoch=best[1],best_source_validation_balanced_mae_m=best[0],epochs_run=epoch,
        train_n=len(tr),validation_n=len(va),test_n=len(te),loss='weighted ((meter_prediction-meter_truth)/30)^2',
        lr_hidden=1e-5,lr_head=1e-4,parameterization='original TI meter-valued final layer; no parameter division and no forward x30',
        original_source_partitions_weights_batch_order_reused=True,source_only_checkpoint_selection=True,
        test_trajectory_observed_for_diagnostics_not_selection=True,independent_new_blind_test=False,
        prefix_cache_prediction_max_error_m=err,hidden_parameter_change=hidden_error)
    torch.save(dict(state_dict=model.state_dict(),protocol=protocol),folder/'model_meters.pt')
    np.savez_compressed(folder/'predictions.npz',sample_id=te,prediction_m=pred)
    pd.DataFrame(curves).to_csv(folder/'learning_curve.csv',index=False)
    pd.DataFrame(history).to_csv(folder/'diagnostic_trajectory.csv',index=False)
    save=(folder/'protocol.json');save.write_text(json.dumps(protocol,ensure_ascii=False,indent=2),encoding='utf-8')
    print('CORRECTED COMPLETE',seed,method,best[1],old.metrics(pred,truth[te]),flush=True)


def summarize(sources,coords,truth):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','DejaVu Sans'];plt.rcParams['axes.unicode_minus']=False
    _,split=partitions(sources,coords);te=split['test'];rows=[];raw_replays=[]
    from predict_ti_finetuned_iq import predict_finetuned_iq
    first=sources[sources.scene.eq('实车')].iloc[0]
    raw_records,_=old._parse_log(Path(first.file),complete_four_paths=False)
    raw_iq=np.stack([v[5] for v in raw_records[:8]])
    raw_ids=np.arange(int(first.sample_start),int(first.sample_start)+len(raw_iq))
    raw_positions=np.searchsorted(te,raw_ids);np.testing.assert_array_equal(te[raw_positions],raw_ids)
    frozen=np.load(old.OUT/'frozen_predictions.npy')[te]
    for seed in old.SEEDS:
        predictions={'frozen_TI':frozen,'frozen_minus094':frozen-.94}
        for method in ['ti_head','ti_full']:
            with np.load(old.OUT/f'seed_{seed}'/'leave_实车'/method/'predictions.npz') as c:
                np.testing.assert_array_equal(c['sample_id'],te);predictions['old_'+method]=c['prediction_m']
        for method in ['canonical_head','canonical_full']:
            with np.load(OUT/f'seed_{seed}'/method/'predictions.npz') as c:
                np.testing.assert_array_equal(c['sample_id'],te);predictions[method]=c['prediction_m']
            obj=torch.load(OUT/f'seed_{seed}'/method/'model_meters.pt',map_location='cpu',weights_only=True)
            m=TiApuArchitecture();m.load_state_dict(obj['state_dict']);loc=np.linspace(0,len(te)-1,128).astype(int)
            np.testing.assert_allclose(old.predict_model(m,np.load(old.OUT/'features.npy',mmap_mode='r'),te[loc]),predictions[method][loc],atol=3e-4,rtol=1e-5)
            replay=predict_finetuned_iq(raw_iq,OUT/f'seed_{seed}'/method/'model_meters.pt')
            raw_error=float(abs(replay-predictions[method][raw_positions]).max());assert raw_error<3e-4
            raw_replays.append(dict(seed=seed,method=method,max_error_m=raw_error))
        for method,p in predictions.items():
            for scope,mask in [('ALL',np.ones(len(te),bool)),('true_le15m',truth[te]<=15),('true_gt15m',truth[te]>15)]:
                rows.append(dict(seed=seed,method=method,scope=scope,**old.metrics(p[mask],truth[te][mask])))
    each=pd.DataFrame(rows);each.to_csv(OUT/'corrected_comparison_each_seed.csv',index=False)
    fields=['mae_m','error_p5_m','cep95_m','bias_m','under3_pct','over3_pct']
    avg=each.groupby(['method','scope']).agg(n=('n','first'),**{f'{k}_{stat}':(k,stat) for k in fields for stat in ['mean','std']}).reset_index()
    avg.to_csv(OUT/'corrected_comparison_two_seeds.csv',index=False)
    checks=json.loads((OUT/'implementation_checks.json').read_text(encoding='utf-8'))
    text='# TI微调实现核查与原参数化修正对照\n\n'
    text+='发现训练设置问题：旧实现将最后一层参数除30，前向乘30；虽然初始预测和导出推理保持米制等价，但Adam在该参数化中的更新不等价。相同名义学习率使原TI参数单位下的输出层更新约放大30倍。之前仅核验推理等价，未核验优化等价，不能据旧结果直接断言小步微调也会产生同等退化。\n\n'
    text+=f"真实训练batch的初始输出最大差{checks['initial_prediction_max_difference_m']:.3g}m；原参数化单步平均变化{checks['canonical_mean_parameter_step']:.6g}，旧参数化换算后{checks['old_canonical_mean_parameter_step']:.6g}，比例{checks['effective_head_step_ratio']:.6f}。零学习率更新后的输出变化为{checks['zero_lr_prediction_change_m']}m。\n\n"
    text+='已核查所有24个原模型的输入仿射，8个只更新输出层的模型隐藏层完全未变；保留的并发重复训练模型参数一致。原报告中的单位、导出及数据隔离核验仍成立，但这些不能排除上述优化尺度变化。\n\n'
    text+='修正对照只针对发生退化的整实车场景留出折，仍用其余三个场景全部训练数据、相同来源验证、权重、batch顺序、最多25轮及早停。两个种子都保持原TI米制参数，隐藏层lr1e-5、输出层lr1e-4；不再除参数或在forward乘30，loss中的误差仍除30。它是开发核查，不冒充重新完成四场景盲测。\n\n'
    selected=avg.set_index(['method','scope'])
    text+=f"修正后仅输出层微调的实车总体MAE为{selected.loc[('canonical_head','ALL'),'mae_m_mean']:.3f}m，远距离MAE为{selected.loc[('canonical_head','true_gt15m'),'mae_m_mean']:.3f}m；旧实现分别为{selected.loc[('old_ti_head','ALL'),'mae_m_mean']:.3f}m和{selected.loc[('old_ti_head','true_gt15m'),'mae_m_mean']:.3f}m。说明优化尺度问题有实质影响。修正后全网络微调的远距离MAE仍为{selected.loc[('canonical_full','true_gt15m'),'mae_m_mean']:.3f}m，不能把所有退化都归因于这一处问题。\n\n"
    text+='|方法|范围|N|MAE|error P5|CEP95|偏差|低估>3m%|\n|---|---|---|---|---|---|---|---|\n'
    for r in avg.itertuples():text+=f'|{r.method}|{r.scope}|{r.n}|{r.mae_m_mean:.3f}|{r.error_p5_m_mean:.3f}|{r.cep95_m_mean:.3f}|{r.bias_m_mean:.3f}|{r.under3_pct_mean:.2f}|\n'
    text+='\n独立二参数校准是对冻结预测拟合a*T+b，仅使用来源训练标签，由NumPy闭式最小二乘计算，不经过Torch梯度或模型导出；用于检验范围受限监督是否也能改变远距离输出。参数和结果分别见independent_affine_parameters.json及independent_affine_control.csv。\n\n'
    text+='每折的diagnostic_trajectory.csv记录epoch0及预定轮次的测试行为，仅用于事后归因，不参与选轮次；检查点仍只由来源验证决定。\n'
    fig,axes=plt.subplots(1,2,figsize=(12,4),constrained_layout=True)
    for ax,scope in zip(axes,['ALL','true_gt15m']):
        for seed in old.SEEDS:
            for method,color in [('canonical_head','#2563eb'),('canonical_full','#dc2626')]:
                p=pd.read_csv(OUT/f'seed_{seed}'/method/'diagnostic_trajectory.csv')
                p=p[p.partition.eq('car_test')&p.scope.eq(scope)]
                ax.plot(p.epoch,p.mae_m,marker='o',ms=3,color=color,ls='-' if seed==old.SEEDS[0] else '--',label=f'{method} {seed}')
                spec=json.loads((OUT/f'seed_{seed}'/method/'protocol.json').read_text(encoding='utf-8'))
                end=each[each.seed.eq(seed)&each.method.eq(method)&each.scope.eq(scope)].mae_m.iloc[0]
                ax.scatter([spec['best_epoch']],[end],marker='*',s=90,color=color,zorder=5)
        ax.set_title(scope);ax.set_xlabel('Epoch');ax.set_ylabel('Car held-out MAE / m');ax.grid(alpha=.2);ax.legend(fontsize=8)
    fig.savefig(OUT/'canonical_test_trajectory.png',dpi=150);plt.close(fig)
    text+='\n![原参数化诊断轨迹](canonical_test_trajectory.png)\n\n星号标记来源验证选择的实际检查点，未按测试曲线最小值选轮次。全网络在约第5轮已有较好的测试表现，继续适配1～15m来源分布后，来源验证改善而远距离退化。测试轨迹是事后诊断，不能据此把第5轮当作一个经过独立验证的部署选择。\n'
    (OUT/'report.md').write_text(text,encoding='utf-8')
    save_json('verification.json',dict(corrected_models_reloaded=4,source_only_selection=True,
        canonical_parameterization=True,old_results_preserved=True,implementation_checks=checks,
        raw_IQ_replay_cases=len(raw_replays),max_raw_IQ_replay_error_m=max(r['max_error_m'] for r in raw_replays)))
    print('CORRECTED SUMMARY\n'+avg.to_string(index=False),flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['checks','train','report','all'],default='all');args=parser.parse_args()
    sys.stdout.reconfigure(encoding='utf-8');torch.set_num_threads(2);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    OUT.mkdir(parents=True,exist_ok=True);sources,x,coords,truth=old.load_data()
    if args.stage in ['checks','all']:
        static_and_one_step(sources,x,coords,truth);two_parameter_control(sources,coords,truth)
    if args.stage in ['train','all']:
        for seed in old.SEEDS:
            for method in ['canonical_head','canonical_full']:run_corrected(sources,x,coords,truth,seed,method)
    if args.stage in ['report','all']:summarize(sources,coords,truth)


if __name__=='__main__':
    with threadpool_limits(limits=2):main()
