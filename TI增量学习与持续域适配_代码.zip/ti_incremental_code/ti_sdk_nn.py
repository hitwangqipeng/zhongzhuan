"""TI F3 9.23.00.27 APU NN dimensions, recovered from ELF/DWARF.

Rebuild the verified architecture for retraining, not binary-identical SDK
inference. The original NN weights are retained separately without claiming
their APU packing is converted. Our logs have 80 calibrated, combined tones;
we train a fresh model against their corrected 3D truth.
"""
from pathlib import Path
import json
import numpy as np
import torch
from torch import nn

PROFILE_PATH=Path(__file__).resolve().parent/'outputs/ti_nn_reverse_20261117/nn_profile.json'
L=12
COL=np.repeat(np.arange(L),np.arange(1,L+1))
ROW=np.concatenate([np.arange(j+1) for j in range(L)])
DIM=156


def load_profile():
    profile=json.loads(PROFILE_PATH.read_text(encoding='utf8'))
    assert profile['architecture']==[156,12,36,24,1]
    return profile


def covariance_features(iq80):
    """Two frequency-interleaved groups, forward smoothing, unit packed L2.

    Mirrors the recovered NetIAP -> computeCovMat settings (L=12, factor=2,
    FB=false). Adaptation: retain all 80 log tones rather than fabricate a
    72/75-channel BLE mapping. Standard x*x^H convention; hardware numerical
    equivalence and the SDK's full upstream preprocessing are not claimed.
    """
    z=np.asarray(iq80)
    if z.ndim!=2 or z.shape[1]!=80 or not np.isfinite(z).all():
        raise ValueError('Expected finite complex IQ with shape (N,80)')
    energy=np.mean(abs(z)**2,axis=1)
    if np.any(energy<=0):raise ValueError('All-zero input has undefined covariance normalization')
    z=(z/np.sqrt(energy)[:,None]).astype(np.complex64)
    r=np.zeros((len(z),L,L),np.complex64)
    for parity in [0,1]:
        x=np.lib.stride_tricks.sliding_window_view(z[:,parity::2],L,axis=1)
        r+=np.matmul(x.transpose(0,2,1),x.conj())/x.shape[1]
    packed=r[:,ROW,COL]
    packed/=np.linalg.norm(packed,axis=1)[:,None]
    result=np.empty((len(z),DIM),np.float32)
    result[:,0::2]=packed.real;result[:,1::2]=packed.imag
    return result


class TiApuArchitecture(nn.Module):
    """156 -> 12 -> 36 -> 24 -> 1, ReLU x3, fixed SDK affine input."""
    def __init__(self):
        super().__init__();profile=load_profile()
        self.register_buffer('input_offset',torch.tensor(profile['affine_offset'],dtype=torch.float32))
        self.register_buffer('input_gain',torch.tensor(profile['affine_gain'],dtype=torch.float32))
        self.layers=nn.Sequential(nn.Linear(156,12),nn.ReLU(),nn.Linear(12,36),nn.ReLU(),
            nn.Linear(36,24),nn.ReLU(),nn.Linear(24,1))

    def forward(self,x):
        return self.layers((x-self.input_offset)*self.input_gain).squeeze(-1)
