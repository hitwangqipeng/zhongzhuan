"""Inference for the SDK-windowed TI fine-tuning experiment's meter checkpoints.

Inputs are already two-way combined, phase-calibrated complex N x80 IQ in
ascending 1MHz tone order. Do not substitute the old unwindowed adapter.
"""
from pathlib import Path
import numpy as np
import torch
from ti_sdk_nn import TiApuArchitecture, covariance_features
from ti_time_window import preprocess_single_path


def predict_finetuned_iq(iq80, checkpoint, batch_size=512):
    z=np.asarray(iq80)
    if z.ndim!=2 or z.shape[1]!=80 or len(z)==0 or z.dtype.kind!='c' or not np.isfinite(z).all():
        raise ValueError('Expected nonempty finite complex N x80 already-combined IQ')
    if batch_size<1:raise ValueError('batch_size must be positive')
    saved=torch.load(Path(checkpoint),map_location='cpu',weights_only=True)
    protocol=saved['protocol']
    if protocol.get('dataset_version')!='full_labelled_paths_sdk_window_ti_finetune_v1':
        raise ValueError('Checkpoint does not declare the expected windowed80-tone input contract')
    if not protocol.get('shared_model_all_paths') or protocol.get('path_fusion'):
        raise ValueError('Expected one shared independent-path model')
    model=TiApuArchitecture();model.load_state_dict(saved['state_dict']);model.eval()
    result=np.empty(len(z),np.float32)
    with torch.no_grad():
        for start in range(0,len(z),batch_size):
            chunk=preprocess_single_path(z[start:start+batch_size])
            result[start:start+len(chunk)]=model(torch.from_numpy(covariance_features(chunk))).numpy()
    if not np.isfinite(result).all():raise ValueError('Nonfinite prediction')
    return result
