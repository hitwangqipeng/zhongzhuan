# 持续域学习与持续无标签域适配

两套评估分开：

1. `strict/`：留出场景输入与标签不用于训练。三个来源域按正序/反序到达，比较naive、域平衡ER、域平衡DER++回归版及新标签曝光匹配joint4。固定种子20261119，两个顺序，不称为两个随机种子。每来源4遍新样本，当前batch2048、回放512、总缓冲4096。来源验证最终选轮次，含冻结TI回退。
2. `unlabelled/`：用留出场景独立采集会话的无标签IQ校准，其余完整会话测试。这不是零样本LOSO。每校准文件最多256条path，实车4096条；同一校准会话未采样帧也排除出测试。实车最终测试86356条。每个外折从此前三来源联合训练、来源验证选出的同一个模型开始，比较source_replay控制、CORAL、CORAL+目标回放、DANN+目标回放和CoTTA回归移植。

```powershell
.\.venv\Scripts\python.exe -m unittest tests.test_ti_continual_domain tests.test_ti_cda_unlabelled -v
.\.venv\Scripts\python.exe experiment_ti_cda_strict.py --order forward
.\.venv\Scripts\python.exe experiment_ti_cda_strict.py --order reverse
.\.venv\Scripts\python.exe experiment_ti_cda_unlabelled.py --stage prepare
.\.venv\Scripts\python.exe experiment_ti_cda_unlabelled.py --stage train --seed 20261118
.\.venv\Scripts\python.exe experiment_ti_cda_unlabelled.py --stage train --seed 20261119
.\.venv\Scripts\python.exe report_ti_cda.py
```

不同顺序/种子写入不同目录，可并行。命令从工作区根目录执行。完成的单次实验按最后写入的protocol.json跳过；完整会话划分在unlabelled/partition_*.npz和.json中。使用原数据缓存：928份有标签静态日志、1690110条独立path，不补造动态轨迹或未知slave3几何。

校准函数 `adapt_features` 的接口只接收来源记忆和无标签校准特征，不接收目标距离或测试特征。CoTTA连来源记忆也不接收；其raw适配source-free，guarded选择额外依赖有标签来源验证。每条path一个估计，共享权重，不以锚点/path/LOS/NLOS身份作为输入，真值使用已确认3D几何。

初始预算：模型lr3e-6，CORAL/DANN权重0.01/0.1；CoTTA lr3e-6/1e-5，EMA0.999、随机恢复0.01。每校准batch更新一次，实车仅16次。因此在未查看测试误差前增加预算对照：lr1e-4，每当前batch连续10步（实车160次），当前样本只插入回放一次，无未来batch信息。该对照同时改变学习率和更新数，不能分别归因。配置见unlabelled/experiment_plan.json与budget_amendment.json。

TI MLP没有BN、输出标量距离，没有直接使用分类softmax熵跑TENT/EATA。CoTTA明确改为两个固定缓存的1% RMS复噪声IQ视图的回归teacher一致性，最后冻结EMA独立推理；不声称原分类论文逐项复现。CORAL/DANN用固定来源统计标准化的24维hidden仅计算对齐loss，不改变部署前向。

主要输出：report.md、strict_metrics_two_orders.csv、CDA_metrics_two_seeds_two_orders.csv；两协议样本集合和额外无标签信息不同，不能混成一个排名。strict_on_CDA_test_sessions.csv提供相同最终会话上的source-only对照。CDA_source_forgetting_and_guard.csv给旧来源域遗忘与来源P5准入；CDA_car_anchor_path.csv给逐锚点/path误差。不扣0.94m，不截断负输出。

推理复用根目录 `predict_ti_finetuned_iq.predict_finetuned_iq(iq80, checkpoint)`，输入已双向合成且校准的复数N×80IQ。模型保持原156→12→36→24→1米制MLP；判别器/对齐标准化不部署。严格留一的raw_model_meters.pt为来源MAE选择，gated_model_meters.pt为来源P5准入。无标签适配的model_meters.pt是固定预算最终模型；guarded_model_meters.pt可能回退适配前模型。通过来源准入不保证新域P5。
