# 单path微调方法比较

同一份156维TI前端，原始3265参数米制MLP，四场景留一，所有path独立输入且共享模型。没有多天线融合，没有把path/锚点/场景编号作为输入。928份静态有标签源文件、1,690,110条path；实车116,005条，按确认的3D几何给真值。

```powershell
.\.venv\Scripts\python.exe experiment_ti_incremental_loso.py --stage prepare
.\.venv\Scripts\python.exe experiment_ti_incremental_loso.py --stage train --seed 20261118
.\.venv\Scripts\python.exe experiment_ti_incremental_loso.py --stage train --seed 20261119
.\.venv\Scripts\python.exe experiment_ti_incremental_loso.py --stage report
```

种子可并行，目录互不覆盖；完成的试验根据最后写入的protocol.json跳过。原实验计划和source-only强度修订分别保留；有效网格为EWC λ1/10/1000/10000、LwF λ1/10、LoRA rank2/4、Adapter bottleneck4/8。共80个主试验，另对来源验证选中的方法做匹配配置的无低估惩罚消融（若为已跑过的全量基线，则复用对应试验）。

主试验共同的新任务损失为归一化距离误差平方加4倍低估平方附加项，低估总权重5。每次完整12epoch、batch4096、Adam无weight_decay、余弦LR降到初始的1/10。EWC/LwF lr3e-6，LoRA/Adapter lr3e-5。没有按留出数据选择配置、轮次或学习率。

EWC是代理实验：TI原训练集和旧任务Fisher不可得，只在各折来源训练输入分布上估计原模型参数重要性。采用Gaussian f/30输出的逐样本Jacobian平方（单位噪声方差），未使用来源标签或留出数据。不能把它称为TI旧任务Fisher。

LwF保留原TI对来源输入的输出；LoRA冻结原矩阵及bias，训练所有4FC的低秩增量，原始输出1维末层有效rank1；Adapter冻结骨干，在24维末隐藏层加零初始化输出的残差瓶颈。LoRA的MAE选择模型合并回原网络；Adapter仍需额外分支。所有方法初始化时与原TI一致，原固定部分不允许被更新。

report.md、metrics_two_seeds.csv给最终结果。scene_macro_two_seeds.csv按4个场景等权比较MAE，candidate_metrics_each_seed.csv给各固定配置结果。source_only_selection.csv给实际选择及是否epoch0回退。P5准入要求来源分场景/距离段/path的有符号P5不低于冻结TI，不能保证未知场景P5。实际回退必须与训练收益分开解释。

推理接口：根目录ti_incremental_mlp.predict_incremental_iq(iq80, checkpoint)。输入已双向合成并校准的复数N×80 IQ，直接输出米，不减0.94，不截零。各折<method>_selected.pt按来源MAE选择，<method>_P5_selected.pt按来源P5准入；source_policy_selected.pt按来源验证在4方法、全量5倍惩罚与冻结TI之间选择。未知新数据请勿直接挑实车留出最好的权重作为泛化保证。

该数据队列已用于多轮开发，不能当成新盲测；实车留出时来源距离最高15m，远距是外推。这里衡量我方留出数据的适配泛化，不是对TI未知旧任务遗忘程度的完整测量。
