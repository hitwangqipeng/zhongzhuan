"""24-parameter FC3-bias adaptation in original TI parameter units.

No output rescaling. The optional monotonic constraint makes the adapted
distance >= its frozen-teacher branch for every finite input, independent
of labels or distribution. This is a signed-error-P5 guarantee, not a
guarantee about MAE, absolute-error P5, CEP95, or teacher accuracy itself.
"""
from pathlib import Path
import copy
import numpy as np
import torch
from torch import nn
from torch.nn import functional as F

from ti_sdk_nn import TiApuArchitecture, covariance_features
from ti_time_window import preprocess_single_path


class TiFc3BiasAdapter(nn.Module):
    def __init__(self, teacher, monotonic=True, bias_radius=.02):
        super().__init__()
        if bias_radius<=0:raise ValueError('bias_radius must be positive')
        self.teacher=copy.deepcopy(teacher)
        for p in self.teacher.parameters():p.requires_grad_(False)
        self.delta=nn.Parameter(torch.zeros_like(self.teacher.layers[4].bias))
        self.monotonic=bool(monotonic)
        self.bias_radius=float(bias_radius)
        self.register_buffer('direction',self.teacher.layers[6].weight.detach()[0].sign().clone())

    def fc3_preactivation(self,x):
        return self.teacher.layers[:5]((x-self.teacher.input_offset)*self.teacher.input_gain)

    def signed_bias_delta(self):
        return self.direction*self.delta if self.monotonic else self.delta

    def from_preactivation(self,preactivation,return_teacher=False):
        before=F.relu(preactivation)
        after=F.relu(preactivation+self.signed_bias_delta())
        baseline=F.linear(before,self.teacher.layers[6].weight,self.teacher.layers[6].bias).squeeze(-1)
        correction=((after-before)*self.teacher.layers[6].weight[0]).sum(dim=-1)
        # Each contribution is nonnegative in monotonic mode, since ReLU is
        # nondecreasing and the bias direction matches the fixed head sign.
        result=baseline+correction
        return (result,baseline) if return_teacher else result

    def forward(self,x,return_teacher=False):
        return self.from_preactivation(self.fc3_preactivation(x),return_teacher)

    @torch.no_grad()
    def project_(self,previous,max_step):
        if max_step<0:raise ValueError('max_step must be nonnegative')
        self.delta.copy_(torch.maximum(torch.minimum(self.delta,previous+max_step),previous-max_step))
        self.delta.clamp_(0. if self.monotonic else -self.bias_radius,self.bias_radius)
        return self

    def distance_change_bound_m(self):
        return float(self.teacher.layers[6].weight.detach().abs().sum())*self.bias_radius


def load_adapter(checkpoint):
    saved=torch.load(Path(checkpoint),map_location='cpu',weights_only=True)
    p=saved['protocol']
    if p.get('implementation')!='ti_fc3_bias24_p5_v1':raise ValueError('Unexpected checkpoint contract')
    teacher=TiApuArchitecture();teacher.load_state_dict(saved['teacher_state_dict'])
    model=TiFc3BiasAdapter(teacher,p['monotonic'],p['bias_radius'])
    with torch.no_grad():model.delta.copy_(saved['delta'])
    if model.delta.abs().max()>model.bias_radius+1e-8:raise ValueError('Bias radius violated')
    if model.monotonic and model.delta.min()<0:raise ValueError('Monotonic constraint violated')
    model.eval();return model,p


def predict_fc3_bias_iq(iq80,checkpoint,batch_size=512,return_teacher=False,require_strict_p5=True):
    """Already combined/calibrated ascending80-tone IQ -> SDK window -> meters."""
    z=np.asarray(iq80)
    if z.ndim!=2 or z.shape[1]!=80 or z.dtype.kind!='c' or len(z)==0 or not np.isfinite(z).all():
        raise ValueError('Expected finite complex N x80 already-combined IQ')
    if batch_size<1:raise ValueError('batch_size must be positive')
    model,_=load_adapter(checkpoint);out=[];reference=[]
    if require_strict_p5 and not model.monotonic:
        raise ValueError('This adapter has validation-only P5 gating; use a strict_selected_adapter.pt checkpoint, or explicitly disable require_strict_p5 for diagnostics')
    with torch.no_grad():
        for start in range(0,len(z),batch_size):
            f=covariance_features(preprocess_single_path(z[start:start+batch_size]))
            p,t=model(torch.from_numpy(f),return_teacher=True)
            if model.monotonic and not torch.all(p>=t):raise AssertionError('Teacher lower bound violated')
            out.append(p.numpy());reference.append(t.numpy())
    prediction=np.concatenate(out);teacher=np.concatenate(reference)
    return (prediction,teacher) if return_teacher else prediction
