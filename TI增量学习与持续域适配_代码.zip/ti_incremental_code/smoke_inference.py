"""Synthetic IQ checks API compatibility, not real-world accuracy."""
import numpy as np
import torch
from audit_ti_finetune_implementation import canonical_model
from ti_incremental_mlp import LoRAMLP,AdapterMLP
from ti_pretrained_nn import predict
from ti_time_window import preprocess_single_path
from ti_sdk_nn import covariance_features

def main():
    torch.set_num_threads(1)
    k=np.arange(80)
    iq=np.exp(-1j*4*np.pi*(k*1e6)*10/299792458)[None,:]
    features=covariance_features(preprocess_single_path(iq))
    with torch.no_grad():
        reference=canonical_model()(torch.from_numpy(features))
        for model in [LoRAMLP(2),LoRAMLP(4),AdapterMLP(4),AdapterMLP(8)]:
            torch.testing.assert_close(model(torch.from_numpy(features)),reference,rtol=0,atol=0)
    np.testing.assert_allclose(reference.numpy(),predict(features),rtol=2e-5,atol=1e-4)
    print('PASS: IQ frontend, canonical meter MLP, teacher equivalence and zero-init LoRA/Adapter.')
    print('Synthetic input is not an accuracy benchmark.')

if __name__=='__main__':main()
