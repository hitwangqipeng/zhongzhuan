"""Audit and compare strict source-only CL and unlabeled-session CDA separately."""
from pathlib import Path
import json,sys
import numpy as np
import pandas as pd
import torch
from threadpoolctl import threadpool_limits

import experiment_ti_finetune_all_loso as data
import experiment_ti_full_under_loso as prior
from experiment_ti_fc3_bias_p5 import validation_groups,gate_p5
from audit_ti_finetune_implementation import canonical_model
from predict_ti_finetuned_iq import predict_finetuned_iq
import experiment_ti_cda_strict as strict
import experiment_ti_cda_unlabelled as cda

OUT=strict.OUT


def write_json(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


def metrics_for(sources,coords,truth,ids,pred,scene):
    masks=[('ALL',np.ones(len(ids),bool)),('true_gt15m',truth[ids]>15),('true_le15m',truth[ids]<=15)]
    if scene=='实车':
        condition=sources.condition.to_numpy()[coords['source_index'][ids]]
        masks.extend([('LOS',condition=='LOS'),('NLOS',condition=='NLOS')])
    return [dict(scope=name,**data.metrics(pred[mask],truth[ids][mask])) for name,mask in masks if mask.any()]


def validate_checkpoint(path,x,ids,pred):
    obj=torch.load(path,map_location='cpu',weights_only=True)
    model=canonical_model();model.load_state_dict(obj['state_dict'])
    loc=np.unique(np.linspace(0,len(ids)-1,min(128,len(ids))).astype(int))
    error=float(abs(data.predict_model(model,x,ids[loc])-pred[loc]).max());assert error<3e-4
    reference=canonical_model().state_dict()
    for name in ['input_offset','input_gain']:assert torch.equal(model.state_dict()[name],reference[name])
    return error,model,obj


def main():
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    sys.stdout.reconfigure(encoding='utf-8');torch.set_num_threads(1);torch.set_num_interop_threads(1)
    sources,x,coords,truth=data.load_data();checks=[];strict_rows=[];paired_strict=[];forgetting=[];cda_rows=[];retention=[];anchors=[]
    fixed_seed=20261119
    strict_predictions={}
    for held in data.SCENES:
        _,parts=prior.split_rows(sources,coords,held);va,te=parts['validation'],parts['test'];vref,tref=prior.baseline(held,va,te)
        with np.load(cda.UOUT/f'partition_{held}.npz') as a:
            target_test=a['test_ids'];target_cal=a['calibration_ids'];mem=a['source_memory_ids']
        assert not set(coords['frame_id'][target_cal])&set(coords['frame_id'][target_test])
        for order in ['forward','reverse']:
            models={'frozen_TI':tref}
            for method in ['joint4',*strict.METHODS]:
                folder=OUT/'strict'/f'leave_{held}'/('joint' if method=='joint4' else order)/method
                p=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))
                assert p['held_domain_input_or_labels_used'] is False
                with np.load(folder/'predictions.npz') as a:
                    np.testing.assert_array_equal(a['sample_id'],te);preds={kind:a[kind+'_m'] for kind in ['raw','gated']}
                for kind,pred in preds.items():
                    error,model,_=validate_checkpoint(folder/f'{kind}_model_meters.pt',x,te,pred)
                    if kind=='gated':
                        vp=data.predict_model(model,x,va);ok,_,_=gate_p5(vp,truth[va],vref,validation_groups(sources,coords,truth,va));assert ok
                    checks.append(dict(protocol='strict',held_scene=held,seed=fixed_seed,order=order,method=method,kind=kind,error_m=error))
                    models[method+('_P5' if kind=='gated' else '')]=pred
                if method!='joint4':
                    hist=pd.read_csv(folder/'old_domain_validation.csv')
                    for name in p['order'][:-1]:
                        past=hist[hist.domain.eq(name)&hist.stage.isin(['1','2'])]
                        final=hist[hist.domain.eq(name)&hist.stage.eq('selected_final')].mae_m.iloc[0]
                        forgetting.append(dict(held_scene=held,order=order,method=method,old_domain=name,
                            best_prior_validation_mae_m=past.mae_m.min(),final_validation_mae_m=final,forgetting_mae_m=final-past.mae_m.min()))
            strict_predictions[(held,order)]=(te,models)
            for method,pred in models.items():
                for metric in metrics_for(sources,coords,truth,te,pred,held):
                    strict_rows.append(dict(scene=held,order=order,method=method,**metric))
                loc=np.searchsorted(te,target_test);np.testing.assert_array_equal(te[loc],target_test)
                for metric in metrics_for(sources,coords,truth,target_test,pred[loc],held):
                    paired_strict.append(dict(scene=held,order=order,method=method,**metric))
    strict_each=pd.DataFrame(strict_rows);strict_each.to_csv(OUT/'strict_metrics_each_order.csv',index=False,encoding='utf-8-sig')
    fields=['mae_m','error_p5_m','abs_error_p5_m','cep95_m','bias_m','under3_pct','over3_pct']
    def aggregate(frame,keys):
        return frame.groupby(keys).agg(n=('n','first'),**{f'{k}_{s}':(k,s) for k in fields for s in ['mean','std']}).reset_index()
    strict_avg=aggregate(strict_each,['scene','scope','method']);strict_avg.to_csv(OUT/'strict_metrics_two_orders.csv',index=False,encoding='utf-8-sig')
    aggregate(pd.DataFrame(paired_strict),['scene','scope','method']).to_csv(OUT/'strict_on_CDA_test_sessions.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(forgetting).to_csv(OUT/'strict_old_domain_forgetting.csv',index=False,encoding='utf-8-sig')
    strict_each[strict_each.scope.eq('ALL')].groupby(['order','method']).mae_m.mean().rename('scene_macro_mae_m').reset_index().groupby('method').scene_macro_mae_m.agg(['mean','std']).reset_index().to_csv(OUT/'strict_scene_macro.csv',index=False)
    partition_rows=[]
    for held in data.SCENES:
        with np.load(cda.UOUT/f'partition_{held}.npz') as a:
            te=a['test_ids'];cal=a['calibration_ids'];mem=a['source_memory_ids']
        _,parts=prior.split_rows(sources,coords,held);va=parts['validation'];groups=validation_groups(sources,coords,truth,va)
        assert held not in set(sources.scene.to_numpy()[coords['source_index'][mem]])
        condition=sources.condition.to_numpy()[coords['source_index'][te]]
        partition_rows.append(dict(scene=held,calibration_paths=len(cal),test_paths=len(te),test_frames=len(np.unique(coords['frame_id'][te])),
            cal_files=len(np.unique(coords['source_index'][cal])),test_files=len(np.unique(coords['source_index'][te])),
            test_LOS_n=int(np.sum(condition=='LOS')),test_NLOS_n=int(np.sum(condition=='NLOS'))))
        for seed in cda.SEEDS:
            root=cda.UOUT/f'seed_{seed}'/f'leave_{held}'
            with np.load(root/'initial_predictions.npz') as a:
                np.testing.assert_array_equal(a['sample_id'],te);initial_pred=a['initial_m']
            initial_options=[]
            for lr in prior.LRS:
                folder=prior.run_folder(seed,held,lr,4.);p=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))
                initial_options.append((p['raw_best_validation_mae_m'],folder))
            init_path=min(initial_options,key=lambda z:z[0])[1]/'raw_best_model_meters.pt'
            _,init_model,_=validate_checkpoint(init_path,x,te,initial_pred);vref=data.predict_model(init_model,x,va)
            frozen=data.predict_model(canonical_model(),x,te)
            for order in ['forward','reverse']:
                predictions={'initial_source':initial_pred,'frozen_TI':frozen}
                for config in cda.ALL_CONFIGS:
                    folder=root/order/config['id'];p=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))
                    assert not p['target_calibration_labels_used'] and not p['target_test_features_or_labels_used_for_adaptation']
                    with np.load(folder/'predictions.npz') as a:
                        np.testing.assert_array_equal(a['sample_id'],te);raw=a['raw_m'];guard=a['guarded_m']
                    for kind,pred,name in [('raw',raw,'model_meters.pt'),('guarded',guard,'guarded_model_meters.pt')]:
                        error,model,_=validate_checkpoint(folder/name,x,te,pred)
                        vp=data.predict_model(model,x,va);passed,worst,_=gate_p5(vp,truth[va],vref,groups)
                        if kind=='guarded':assert passed
                        checks.append(dict(protocol='unlabelled',held_scene=held,seed=seed,order=order,method=config['id'],kind=kind,error_m=error))
                        if kind=='raw':
                            before=data.validation_metrics(vref,truth[va],coords['source_index'][va],sources)[0]
                            after=data.validation_metrics(vp,truth[va],coords['source_index'][va],sources)[0]
                            retention.append(dict(scene=held,seed=seed,order=order,config=config['id'],source_mae_before_m=before,
                                source_mae_after_m=after,source_forgetting_mae_m=after-before,worst_source_p5_change_m=worst,
                                source_guard_passed=p['source_guard_passed'],target_prediction_change_mae_m=float(abs(raw-initial_pred).mean()),
                                target_prediction_change_max_m=float(abs(raw-initial_pred).max())))
                    predictions[config['id']]=raw;predictions[config['id']+'_guarded']=guard
                for method,pred in predictions.items():
                    for metric in metrics_for(sources,coords,truth,te,pred,held):cda_rows.append(dict(scene=held,seed=seed,order=order,method=method,**metric))
                    if held=='实车':
                        for anchor in sources[sources.scene.eq(held)].anchor.unique():
                            for path in range(4):
                                use=(sources.anchor.to_numpy()[coords['source_index'][te]]==anchor)&(coords['path'][te]==path)
                                anchors.append(dict(seed=seed,order=order,anchor=anchor,path=path,method=method,**data.metrics(pred[use],truth[te][use])))
    cda_each=pd.DataFrame(cda_rows);cda_each.to_csv(OUT/'CDA_metrics_each_run.csv',index=False,encoding='utf-8-sig')
    cda_avg=aggregate(cda_each,['scene','scope','method']);cda_avg.to_csv(OUT/'CDA_metrics_two_seeds_two_orders.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(partition_rows).to_csv(OUT/'CDA_partition_summary.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(retention).to_csv(OUT/'CDA_source_forgetting_and_guard.csv',index=False,encoding='utf-8-sig')
    aggregate(pd.DataFrame(anchors),['anchor','path','method']).to_csv(OUT/'CDA_car_anchor_path.csv',index=False,encoding='utf-8-sig')
    cda_each[cda_each.scope.eq('ALL')].groupby(['seed','order','method']).mae_m.mean().rename('scene_macro_mae_m').reset_index().groupby('method').scene_macro_mae_m.agg(['mean','std']).reset_index().to_csv(OUT/'CDA_scene_macro.csv',index=False)
    pd.DataFrame(checks).to_csv(OUT/'model_reload_checks.csv',index=False)
    # IQ end-to-end replay in each test scene; only data not adapted on.
    iq_checks=[]
    for held in data.SCENES:
        with np.load(cda.UOUT/f'partition_{held}.npz') as a:te=a['test_ids']
        first=sources.iloc[int(coords['source_index'][te[0]])]
        if first.cache_file:
            with np.load(first.cache_file) as a:q=a['iq'][:8].astype(np.float64);z=q[:,:,0]+1j*q[:,:,1]
        else:
            rows,_=data._parse_log(Path(first.file),complete_four_paths=False);z=np.stack([r[5] for r in rows[:8]])
        ids=np.arange(int(first.sample_start),int(first.sample_start)+len(z));assert set(ids)<=set(te)
        files=[OUT/'strict'/f'leave_{held}'/o/m/'raw_model_meters.pt' for o in ['forward','reverse'] for m in strict.METHODS]
        files.extend(cda.UOUT/f'seed_{seed}'/f'leave_{held}'/o/cfg['id']/'model_meters.pt'
            for seed in cda.SEEDS for o in ['forward','reverse'] for cfg in cda.ALL_CONFIGS)
        for checkpoint in files:
            p=predict_finetuned_iq(z,checkpoint);obj=torch.load(checkpoint,map_location='cpu',weights_only=True)
            model=canonical_model();model.load_state_dict(obj['state_dict']);q=data.predict_model(model,x,ids)
            delta=float(abs(p-q).max());assert delta<3e-4;iq_checks.append(dict(checkpoint=str(checkpoint),error_m=delta))
    pd.DataFrame(iq_checks).to_csv(OUT/'raw_IQ_replay.csv',index=False)
    write_json(OUT/'verification.json',dict(models_reloaded=len(checks),maximum_reload_error_m=max(r['error_m'] for r in checks),
        raw_IQ_replay_cases=len(iq_checks),maximum_IQ_replay_error_m=max(r['error_m'] for r in iq_checks),
        calibration_test_source_session_and_frame_disjoint=True,target_labels_not_used_in_adaptation=True,
        fixed_TI_frontend=True,shared_single_path_model=True,source_only_and_CDA_protocols_reported_separately=True,
        strict_seed_fixed_two_orders=True,CDA_two_seeds_two_orders=True))
    plot_results(strict_avg,cda_avg)
    write_report(strict_avg,cda_avg,pd.DataFrame(partition_rows),pd.DataFrame(retention))
    print('STRICT_CAR\n'+strict_avg[strict_avg.scene.eq('实车')&strict_avg.scope.eq('ALL')].to_string(index=False),flush=True)
    print('CDA_CAR\n'+cda_avg[cda_avg.scene.eq('实车')&cda_avg.scope.eq('ALL')].to_string(index=False),flush=True)


def interpret_results(strict_avg,cda_avg,retention):
    def row(frame,method,scope='ALL'):
        return frame[frame.scene.eq('实车')&frame.scope.eq(scope)&frame.method.eq(method)].iloc[0]
    seq=row(strict_avg,'naive_seq');er=row(strict_avg,'ER');der=row(strict_avg,'DERpp')
    initial=row(cda_avg,'initial_source');control=row(cda_avg,'source_replay_budget10')
    dann=row(cda_avg,'DANN_replay_budget10');coral=row(cda_avg,'CORAL_replay_budget10');cotta=row(cda_avg,'CoTTA_reg_budget10')
    far0=row(cda_avg,'initial_source','true_gt15m');far1=row(cda_avg,'DANN_replay_budget10','true_gt15m')
    selected=retention[retention.scene.eq('实车')]
    admitted=int(selected.source_guard_passed.sum())
    return (f"严格留一中，ER实车MAE {er.mae_m_mean:.4f}m，顺序微调{seq.mae_m_mean:.4f}m，改善仅{seq.mae_m_mean-er.mae_m_mean:.4f}m；"
        f"DER++为{der.mae_m_mean:.4f}m。回放收益很小，未解决远距外推问题。旧来源域验证误差在后续域训练后平均继续下降，"
        "这组数据没有表现出明显的旧来源验证集遗忘，不能把新域低估简单归因于忘记已有来源任务。\n\n"
        f"独立无标签校准的同一实车测试集上，适配前MAE {initial.mae_m_mean:.4f}m、P5 {initial.error_p5_m_mean:.4f}m；"
        f"大预算DANN+回放为{dann.mae_m_mean:.4f}m、{dann.error_p5_m_mean:.4f}m；CORAL+回放为{coral.mae_m_mean:.4f}m、{coral.error_p5_m_mean:.4f}m。"
        f"目标IQ数值不影响更新、只继续旧来源监督回放的同预算控制，MAE反而更低，为{control.mae_m_mean:.4f}m，"
        f"但P5更差，为{control.error_p5_m_mean:.4f}m。附加域对齐/目标回放改善了相对该控制的低估尾部，"
        "同时牺牲部分MAE；未证实额外目标IQ带来超过继续来源训练的MAE收益。\n\n"
        f"CoTTA回归版即使大预算，MAE仍为{cotta.mae_m_mean:.4f}m，接近适配前，没有实质提升。"
        f"DANN远距P5由适配前{far0.error_p5_m_mean:.4f}退化至{far1.error_p5_m_mean:.4f}m，"
        "因此不能认为持续域适配已经保住大距离P5。当前结果更像误差取舍，而非整体测距能力改善。\n\n"
        f"实车共{len(selected)}次配置/顺序/种子适配，{admitted}次通过全部来源分组P5准入，{len(selected)-admitted}次回退适配前模型。"
        "微小变化及冻结回退不计为适配收益。以上是固定配置的结果描述，没有据测试排名继续调参。\n\n")


def plot_results(strict_avg,cda_avg):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','DejaVu Sans'];plt.rcParams['axes.unicode_minus']=False
    fig,axes=plt.subplots(2,2,figsize=(12,8),constrained_layout=True)
    ids=['frozen_TI','joint4','naive_seq','ER','DERpp'];labels=['冻结TI','联合4遍','顺序微调','ER','DER++']
    values=[strict_avg[strict_avg.scene.eq('实车')&strict_avg.scope.eq('ALL')&strict_avg.method.eq(m)].mae_m_mean.iloc[0] for m in ids]
    axes[0,0].barh(labels,values,color='#2563eb');axes[0,0].invert_yaxis();axes[0,0].set_title('严格留一：实车MAE（116005条）')
    methods=['initial_source','source_replay_budget10','CORAL_budget10','CORAL_replay_budget10','DANN_replay_budget10','CoTTA_reg_budget10']
    labels=['适配前','仅来源回放','CORAL','CORAL+回放','DANN+回放','CoTTA回归']
    for ax,scope,field,title in [(axes[0,1],'ALL','mae_m_mean','较大预算：实车MAE（86356条）'),
        (axes[1,0],'ALL','error_p5_m_mean','较大预算：实车error P5'),
        (axes[1,1],'true_gt15m','error_p5_m_mean','较大预算：>15m error P5')]:
        values=[cda_avg[cda_avg.scene.eq('实车')&cda_avg.scope.eq(scope)&cda_avg.method.eq(m)][field].iloc[0] for m in methods]
        ax.barh(labels,values,color='#059669' if field=='mae_m_mean' else '#d97706');ax.invert_yaxis();ax.set_title(title)
        for y,value in enumerate(values):ax.text(value,y,f' {value:.3f}',va='center',ha='left',fontsize=8)
    for ax in axes.flat:ax.set_xlabel('m');ax.grid(axis='x',alpha=.2);ax.margins(x=.15)
    fig.savefig(OUT/'performance_tradeoff.png',dpi=160);plt.close(fig)


def write_report(strict_avg,cda_avg,partitions,retention):
    report='# 单path：持续域学习与持续无标签域适配\n\n'
    report+=interpret_results(strict_avg,cda_avg,retention)
    report+='两种协议分开评估。严格留一不把留出场景输入用于训练；CDA明确使用留出场景独立会话的无标签IQ校准，最终测试来自其他完整会话，不能称为零样本LOSO。所有path独立输入、共享3265参数TI米制MLP，真实距离沿用3D几何，TI前端与先前相同。数据已用于多轮开发，不是新盲测。\n\n'
    report+='## A：严格留一的顺序域学习对照\n\n'
    report+='训练来源三个场景分别到达，测试第四个场景全部数据。每域4轮、当前batch2048，lr3e-6按域余弦降到1/10，Adam按新域重建；正序与反序共用固定seed20261119，当前域批次随机种子按域身份固定。两顺序差异包含历史状态/回放随顺序的变化，不能当成随机种子置信区间。中间域只评价已到达域，最终轮次按全部已到达来源验证选择，含冻结TI回退。\n\n'
    report+='对比naive_seq、域平衡ER、域平衡DER++回归版；缓冲总容量4096，每步额外回放512。DER++保存样本首轮到达、更新前的标量距离作为dark target，额外平方蒸馏权重1，回放真值权重1。缓冲只在首遍接收唯一观测，避免多轮重复插入；原参数化及固定输入仿射不变。每次新域出现时按域均分缓冲容量，各域内优先级蓄水池均匀抽样。\n\n'
    report+='joint4为新标签曝光次数匹配的联合训练（各来源4遍）；回放方法有额外旧样本计算，不是完全相同FLOP预算。此前joint12多三倍新标签曝光，不作为匹配预算对照。source_P5准入相对原始TI；原始MAE选择和准入版本分别保留。\n\n'
    report+='|留出场景|方法|N|MAE|error P5|绝对P5|CEP95|\n|---|---|---|---|---|---|---|\n'
    for r in strict_avg[strict_avg.scope.eq('ALL')&~strict_avg.method.str.endswith('_P5')].itertuples():
        report+=f'|{r.scene}|{r.method}|{r.n}|{r.mae_m_mean:.4f}|{r.error_p5_m_mean:.4f}|{r.abs_error_p5_m_mean:.4f}|{r.cep95_m_mean:.4f}|\n'
    report+='\n旧来源域遗忘以最终选择模型的MAE−该域此前最小验证MAE衡量，正值表示退化，见strict_old_domain_forgetting.csv；验证集合本来参与来源模型选择，该项是诊断，不是新旧任务的独立盲测。\n\n'
    report+='## B：独立无标签会话的持续域适配\n\n'
    report+='每个留出场景按stratum固定随机选取约四分之一会话（向下取整且至少1个）作校准，会话剩余部分不混入测试；每校准日志最多256条path，未采样的同会话观测也全部排除出测试。校准流以采集会话为块，测试文件/session/物理frame完全隔离。块边界已知；按文件名确定块顺序与反向顺序，不声称模拟连续驾驶。目标距离数值不进入适配API，不用于轮次、配置、样本可靠性选择。\n\n'
    report+='|场景|校准path|独立测试path|测试帧|校准日志|测试日志|\n|---|---|---|---|---|---|\n'
    for r in partitions.itertuples():report+=f'|{r.scene}|{r.calibration_paths}|{r.test_paths}|{r.test_frames}|{r.cal_files}|{r.test_files}|\n'
    report+='\n初始模型固定为此前三来源full_under5按来源验证选出的权重，两个种子各自保留，所有CDA方法共用该初始模型。初始模型和原TI均重新在当前相同测试子集打分；不可与此前116005条全实车表直接混比。每配置跑两种子×两顺序，指标各自计算后平均，N不重复。\n\n'
    report+='source_replay控制组仅用4096容量内的有标签来源记忆继续训练，目标输入值不影响更新，已用单元测试验证；其优化步数与其他方法相同，用来区分额外训练和真正域对齐的影响。CORAL使用固定初始来源统计标准化的24维隐藏特征，其协方差Frobenius损失形式不变。CORAL_replay额外回放2048容量内过去目标观测的到达前预测，目标真值不可见。DANN_replay使用24→16→1二分类域判别器、梯度反转、渐增对抗系数，并保留同样来源监督及目标输出回放。对齐系数0.01/0.1、模型lr3e-6，判别器lr1e-3。固定来源标准化只用于适配loss，不改变部署前向。\n\n'
    report+='CoTTA_reg为明确的回归移植：目标IQ加1% RMS复高斯弱噪声，两个前处理后teacher视图平均作目标，使用MSE/30一致性；EMA0.999，逐参数恢复概率0.01，lr3e-6/1e-5，单遍消费校准流，最后冻结EMA模型独立测试。它不使用来源记忆或标签，不使用分类熵/分类置信阈值/BN更新；与原分类CoTTA不是逐项等价复现。原TI网络没有BN且只有标量距离，TENT/EATA的分类熵目标不直接适用。\n\n'
    report+='所有CDA配置预算固定，最终时刻checkpoint固定，无目标标签挑选最优轮次或配置。guarded版本另按原来源验证分组P5相对于适配前模型准入，不通过回退适配前模型；此策略需要有标签来源验证，即使原CoTTA适配本身source-free，guarded选择也不是纯source-free设置。来源准入不保证目标P5。\n\n'
    report+='单遍实车校准仅16个batch更新，因此在查看任何测试误差前，另加固定的大预算对照：source_replay/CORAL/CORAL_replay/DANN_replay/CoTTA_reg统一lr1e-4，每当前batch连续10步；对齐权重仍0.01，CoTTA的EMA/恢复参数不变。同一校准观测只插入回放一次，不使用未来校准batch；这同时改变LR和更新次数，属于预算组合对照，不把效果单独归因于某一个因素。记录在unlabelled/budget_amendment.json。\n\n'
    for scope,title in [('ALL','实车整体'),('true_gt15m','实车>15m'),('LOS','实车LOS'),('NLOS','实车NLOS')]:
        report+=f'### {title}\n\n|方法|N|MAE|error P5|绝对P5|CEP95|低估>3m%|\n|---|---|---|---|---|---|---|\n'
        for r in cda_avg[cda_avg.scene.eq('实车')&cda_avg.scope.eq(scope)&~cda_avg.method.str.endswith('_guarded')].itertuples():
            report+=f'|{r.method}|{r.n}|{r.mae_m_mean:.4f}|{r.error_p5_m_mean:.4f}|{r.abs_error_p5_m_mean:.4f}|{r.cep95_m_mean:.4f}|{r.under3_pct_mean:.2f}|\n'
        report+='\n'
    report+='单位米，e=预测−真值，error P5=Q05(e)，绝对P5=Q05(|e|)，CEP95=Q95(|e|)。不额外减0.94m、不截零。除场景宏平均MAE外不对场景分位数简单平均。每配置结果直接展示，不按留出结果回选“最优”再宣称独立测试；回退不得算作适配收益。\n\n'
    report+='无标签对齐并不知道真实距离分布。实车来源标签只到15m，而新域包含更远距离，场景分布变化与距离先验变化并存；对齐有可能抹去距离信息，较低域判别误差不等于较好测距。这里是有限静态日志的校准块模拟，不是动态驾驶闭环验证。\n\n'
    report+='## 文件与推理\n\n完整逐场景/条件结果：strict_metrics_two_orders.csv和CDA_metrics_two_seeds_two_orders.csv；同一CDA测试会话上的严格留一对照：strict_on_CDA_test_sessions.csv。逐锚点/path：CDA_car_anchor_path.csv。source遗忘/准入：CDA_source_forgetting_and_guard.csv。原始IQ重放及模型重加载最大差异见verification.json。\n\n'
    report+='所有导出模型都是原始156→12→36→24→1米制MLP，域判别器不部署。可直接调用根目录predict_ti_finetuned_iq.predict_finetuned_iq(combined_calibrated_IQ80, checkpoint)。strict的raw_model_meters.pt是来源MAE选中的模型，gated_model_meters.pt是来源P5准入模型；unlabelled的model_meters.pt是固定校准预算后的模型，guarded_model_meters.pt可能回退适配前权重。\n\n'
    report+='![不同预算的精度与低估取舍](performance_tradeoff.png)\n\n'
    report+='原文：[DER++](https://arxiv.org/abs/2004.07211)、[Deep CORAL](https://arxiv.org/abs/1607.01719)、[DANN](https://arxiv.org/abs/1505.07818)、[CoTTA](https://arxiv.org/abs/2203.13591)、[ConDA](https://arxiv.org/abs/2103.11056)、[EATA](https://proceedings.mlr.press/v162/niu22a.html)。回归损失、域平衡缓冲、TI输入适配和预算是本实验选择，不宣称分类论文或作者原超参数的完整复现。\n'
    (OUT/'report.md').write_text(report,encoding='utf-8')


if __name__=='__main__':
    with threadpool_limits(limits=1):main()
