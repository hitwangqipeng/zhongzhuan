"""Compare initial functional steps on source training data, never held labels."""
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from threadpoolctl import threadpool_limits
from experiment_ti_incremental_loso import OUT,CONFIGS,data,prior,make_model
from audit_ti_finetune_implementation import canonical_model


def main():
    torch.set_num_threads(1);torch.set_num_interop_threads(1)
    sources,x,coords,truth=data.load_data();_,parts=prior.split_rows(sources,coords,'实车')
    seed=20261118+300;rng=np.random.default_rng(seed);local=rng.permutation(len(parts['train']))[:4096]
    ids=parts['train'][local];xx=torch.from_numpy(np.array(x[ids],copy=True));yy=torch.from_numpy(truth[ids].astype(np.float32))
    ss=data.split_sources(sources,'实车');weights=data.row_weights(sources,ss['train'],coords['source_index'][parts['train']])
    ww=torch.from_numpy(weights[local]);rows=[]
    configs=[dict(id='full_lr3e-6',method='full',lr=3e-6),*[c for c in CONFIGS if c['method'] in ['lora','adapter']]]
    teacher=canonical_model()
    with torch.no_grad():reference=teacher(xx)
    for config in configs:
        torch.manual_seed(seed);model=make_model(config)
        with torch.no_grad():before=model(xx).clone()
        torch.testing.assert_close(before,reference,rtol=0,atol=0)
        opt=torch.optim.Adam([p for p in model.parameters() if p.requires_grad],lr=config['lr'])
        opt.zero_grad();loss=prior.asymmetric_mse(model(xx),yy,ww,4.);loss.backward();opt.step()
        with torch.no_grad():delta=(model(xx)-before).numpy()
        rows.append(dict(config=config['id'],lr=config['lr'],first_step_prediction_mae_m=float(abs(delta).mean()),
            first_step_prediction_p95_m=float(np.quantile(abs(delta),.95)),first_step_prediction_max_m=float(abs(delta).max()),
            source_only=True,held_scene='实车',n=len(ids)))
    pd.DataFrame(rows).to_csv(OUT/'effective_step_audit.csv',index=False)
    np.savez_compressed(OUT/'effective_step_audit_source_ids.npz',sample_id=ids)
    print(pd.DataFrame(rows).to_string(index=False))


if __name__=='__main__':
    with threadpool_limits(limits=1):main()
