# TI 测距：增量学习与持续域适配代码快照

日期：2026-11-19。先阅读 `docs/增量学习与持续域适配_原理与实现.md`。

这是已经跑过实验的单 path 156 维版本，架构 156→12→36→24→1。
不包含尚未训练的 930 维/L30 新架构。所有 path 共用模型，实车使用 3D 真值。

## 包含内容

- EWC 代理、LwF、LoRA、Adapter、24 参数 FC3 bias 模块与 P5 保护。
- 正确米制全量微调基线、Naive/ER/DER++ 顺序域学习。
- Source replay 控制、CORAL、CORAL+回放、DANN+回放、CoTTA 回归适配。
- 训练、推理、汇总、审计代码及其本地 Python 依赖；相关单元测试。
- 原 TI 小型推理资产、时域窗资产，及原实验报告/CSV 摘要。
- 一份来源文件清单 sources.csv，供会话隔离测试使用；不含 IQ 或特征矩阵。
- `MANIFEST.json` 给出逐文件 SHA256，`SOURCE_MAP.json` 标出源码来源。

## 环境与无需原始数据的验证

命令在本解压目录运行。依赖见 requirements.txt；environment.json 记录本次实际环境。
可在已有项目的 Python 环境中运行，也可新建环境：

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe verify_bundle.py
.\.venv\Scripts\python.exe smoke_inference.py
```

验证检查文件完整性和七组已有单元测试，不需要实车日志或大特征缓存。
smoke_inference.py 只检查接口与数值一致性；合成输入不用于宣称测距精度。

## 完整训练需要外部数据

代码包不包含原始日志、约 1.05 GB 特征矩阵、全部微调模型及逐样本预测。
原实验工作区是 `C:/Users/wqp_9741/Documents/ChatGPT/Ranging`；原始日志根目录在
`experiment_ti_finetune_all_loso.py` 的 ROOT。src 中保留原实验路径，未静默改写。

在原工作区使用对应代码可复用已有数据；若在独立解压目录运行，需要先复制/准备：

1. `outputs/ti_finetune_all_loso_20261118/` 中的 dataset_protocol.json、sources.csv、
   features.npy、sample_coordinates.npz、frozen_predictions.npy。
2. 来源清单中的原始日志与 cache_file 路径仍需可访问；报告/IQ 重放和无标签增强会读取它们。
   跨电脑搬迁需要显式更新数据配置和清单路径，不能把缺失输入视为已经复现。
3. 全量基线首先运行 prepare/train/report，生成 `outputs/ti_full_under_loso_20261118/`。
   后续增量报告会复用基线结果，CDA 会读取其来源验证选中的起始模型。
4. 如果需要从零重建数据缓存，另需历史 `outputs/step12/file_audit.csv`、step12/cache/、
   `outputs/remnet_leave_scene_20261111/source_manifest.csv` 等输入；这些不在本包。

如果直接复制前置输出目录，建议复制完整的 ti_full_under_loso_20261118/，保留协议、
模型、基线与报告需要的预测文件。本包 summary/ 中只是供阅读的历史结果，
不作为新的训练完成标记或模拟训练输出。

## 训练命令

以下均使用原始已确认的数据协议，不会重新为本次打包训练模型。

```powershell
python experiment_ti_full_under_loso.py --stage prepare
python experiment_ti_full_under_loso.py --stage train --seed 20261118
python experiment_ti_full_under_loso.py --stage train --seed 20261119
python experiment_ti_full_under_loso.py --stage report

python experiment_ti_incremental_loso.py --stage prepare
python experiment_ti_incremental_loso.py --stage train --seed 20261118
python experiment_ti_incremental_loso.py --stage train --seed 20261119
python experiment_ti_incremental_loso.py --stage report

python experiment_ti_cda_strict.py --order forward
python experiment_ti_cda_strict.py --order reverse
python experiment_ti_cda_unlabelled.py --stage prepare
python experiment_ti_cda_unlabelled.py --stage train --seed 20261118
python experiment_ti_cda_unlabelled.py --stage train --seed 20261119
python report_ti_cda.py
```

`experiment_ti_finetune_all_loso.py` 保留旧训练实现以供数据读取和审计，
不要运行它的历史 /30 输出头训练入口来代替上面的正确米制全量微调入口。

## 推理与模型选择

EWC/LwF/LoRA/Adapter：`ti_incremental_mlp.predict_incremental_iq(iq80, checkpoint)`。
全量微调/CDA：`predict_ti_finetuned_iq.predict_finetuned_iq(iq80, checkpoint)`。
24 参数模块：`ti_fc3_bias_adapter.predict_fc3_bias_iq(iq80, checkpoint)`。

输入是复数 N×80 已双向合成且校准的 IQ；输出为米。不额外减 0.94，不截零。
本包不指定一个“最优部署模型”；应检查 checkpoint 的 protocol 与是否回退。
来源验证 P5 准入不保证未知域 P5。EWC 是来源 Fisher 代理，CoTTA 是回归改写。

## 已有结果的位置

summary/ti_incremental_loso_20261119/：四方法与全量基线比较。
summary/ti_cda_20261119/：严格留一及独立无标签会话适配，两个协议分别呈现。
summary/ti_full_under_loso_20261118/：正确米制全量微调基线。

TI 资产来自此前 SDK 静态分析，保留在原相对目录供本项目复现；不是本项目新训练的权重。
