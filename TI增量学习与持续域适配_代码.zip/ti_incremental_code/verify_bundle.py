"""Check package hashes, then execute data-independent existing tests."""
from pathlib import Path
import hashlib,json,subprocess,sys

def main():
    root=Path(__file__).resolve().parent
    manifest=json.loads((root/'MANIFEST.json').read_text(encoding='utf-8'))
    for row in manifest['files']:
        p=root/row['path']
        if not p.is_file():raise SystemExit('Missing: '+row['path'])
        digest=hashlib.sha256(p.read_bytes()).hexdigest()
        if digest!=row['sha256']:raise SystemExit('Hash mismatch: '+row['path'])
    print('Verified',len(manifest['files']),'files',flush=True)
    tests=manifest['test_modules']
    return subprocess.call([sys.executable,'-m','unittest',*tests,'-v'],cwd=root)

if __name__=='__main__':raise SystemExit(main())
