"""Unmodified TI9.23 APU pretrained weights, decoded to canonical real MLP.

Each hidden matrix stores the even output-neuron rows before the odd rows.
Biases retain canonical interleaved order. Conversion is validated against
the SDK's original predictNNAPU instruction sequence in audit_ti_pretrained.py.
"""
from pathlib import Path
import numpy as np

BASE=Path(__file__).resolve().parent
RAW=BASE/'outputs/ti_nn_reverse_20261117/ti_ffn_weights_raw.npz'


def load_weights():
    with np.load(RAW) as source:
        data={k:source[k].copy() for k in source.files}
    sizes=[156,12,36,24,1];weights=[]
    for i,(nin,nout) in enumerate(zip(sizes[:-1],sizes[1:]),1):
        packed=data[f'ffn_fc{i}_A'].reshape(nout,nin)
        if nout==1:w=packed.copy()
        else:
            w=np.empty_like(packed)
            w[::2]=packed[:nout//2];w[1::2]=packed[nout//2:]
        b=data[f'ffn_fc{i}_b'][:nout]
        weights.append((w,b))
    return data['ffn_fil_fv'],data['ffn_fil_y'][:156],weights


def predict(features,return_layers=False):
    x=np.asarray(features,np.float32)
    if x.ndim!=2 or x.shape[1]!=156 or not np.isfinite(x).all():
        raise ValueError('Expected finite N x156 TI covariance features')
    offset,gain,weights=load_weights()
    h=(x-offset)*gain;layers=[h.copy()]
    for i,(w,b) in enumerate(weights):
        h=h@w.T+b
        if i<3:h=np.maximum(h,0)
        layers.append(h.copy())
    out=h[:,0]
    return (out,layers) if return_layers else out
