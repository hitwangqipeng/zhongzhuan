"""All-layer canonical TI fine-tuning with small LR and underestimation cost.

No layer freezing, no monotonic output floor, no parameter/forward x30
reparameterization. Loss-only /30 scaling is shared by all controls.
"""
from pathlib import Path
import argparse
import copy
import json
import sys
import time

import numpy as np
import pandas as pd
import torch
from threadpoolctl import threadpool_limits

import experiment_ti_finetune_all_loso as data
from audit_ti_finetune_implementation import canonical_model
from experiment_ti_fc3_bias_p5 import validation_groups,gate_p5

BASE=Path(__file__).resolve().parent
OUT=BASE/'outputs/ti_full_under_loso_20261118'
SEEDS=(20261118,20261119)
LRS=(1e-6,3e-6)
UNDER_EXTRA=(0.,4.)
EPOCHS=12
BATCH=4096
VERSION='canonical_all_fc_small_lr_under_v1'


def write_json(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


def run_folder(seed,scene,lr,under):
    return OUT/f'seed_{seed}'/f'leave_{scene}'/f'under{under:g}_lr{lr:.0e}'


def asymmetric_mse(pred,truth,weight,under_extra=4.):
    e=(pred-truth)/30
    return torch.mean(weight*(e.square()+float(under_extra)*torch.relu(-e).square()))


def result_interpretation(avg):
    def row(scene,scope,method):
        return avg[avg.scene.eq(scene)&avg.scope.eq(scope)&avg.method.eq(method)].iloc[0]
    frozen=row('实车','ALL','frozen_TI');plain=row('实车','ALL','plain_raw_selected');under=row('实车','ALL','under_raw_selected')
    far0=row('实车','true_gt15m','frozen_TI');far1=row('实车','true_gt15m','under_raw_selected')
    all0=row('ALL','ALL','frozen_TI');all1=row('ALL','ALL','under_raw_selected')
    return (f"实际微调结果（未执行P5准入）：实车MAE {frozen.mae_m_mean:.4f}→{under.mae_m_mean:.4f}m，"
        f"改善{100*(1-under.mae_m_mean/frozen.mae_m_mean):.2f}%；error P5 {frozen.error_p5_m_mean:.4f}→{under.error_p5_m_mean:.4f}m。"
        f"相对同学习率无惩罚微调，P5由{plain.error_p5_m_mean:.4f}改善至{under.error_p5_m_mean:.4f}m，"
        f"代价是MAE由{plain.mae_m_mean:.4f}升至{under.mae_m_mean:.4f}m。\n\n"
        f"整体接近冻结P5不能掩盖远距尾部：>15m P5 {far0.error_p5_m_mean:.4f}→{far1.error_p5_m_mean:.4f}m，"
        f"低估>3m比例{far0.under3_pct_mean:.2f}%→{far1.under3_pct_mean:.2f}%。低学习率和5倍惩罚缓解低估，但尚不满足P5不退化。"
        f"四场景合并MAE {all0.mae_m_mean:.4f}→{all1.mae_m_mean:.4f}m，P5 {all0.error_p5_m_mean:.4f}→{all1.error_p5_m_mean:.4f}m；"
        "该合并指标不能代替逐场景及逐距离段检查。\n\n"
        "严格来源分组P5检查没有接受任何更新轮次，因此*_selected实际全部回退冻结TI。上述微调收益对应*_raw_selected，不能归到通过P5准入的模型上。\n\n")


def split_rows(sources,coords,scene):
    ss=data.split_sources(sources,scene)
    parts={k:np.flatnonzero(np.isin(coords['source_index'],v)) for k,v in ss.items()}
    return ss,parts


def prepare():
    OUT.mkdir(parents=True,exist_ok=True);(OUT/'baselines').mkdir(exist_ok=True)
    sources,x,coords,truth=data.load_data()
    if not (OUT/'experiment_plan.json').exists():
        write_json(OUT/'experiment_plan.json',dict(version=VERSION,scenes=list(data.SCENES),seeds=list(SEEDS),
            lrs=list(LRS),under_extra=list(UNDER_EXTRA),epochs=EPOCHS,batch_size=BATCH,threads_per_process=1,
            starting_weights='original TI, canonical meter parameterization',trainable='all3265 FC weights and biases, from first update',
            fixed='SDK input affine buffers and stateless-window covariance preprocessing',
            optimizer='Adam, no weight decay',schedule='cosine to initial LR /10 over12 full epochs',
            loss='mean(weight*((error_m/30)^2 + lambda*relu(-error_m/30)^2)); lambda4 gives5x underestimation cost',
            selection='source-only grouped signed-P5 noninferiority then balanced MAE; epoch0 frozen fallback',
            primary_penalty=4.,primary_LR_and_epoch_selected_without_test=True,
            no_output_lower_bound=True,no_hidden_layer_freezing=True,no_distillation_or_synthetic_data=True,
            dataset=str(data.OUT),dataset_protocol_sha256=data.sha(data.OUT/'dataset_protocol.json'),
            original_weight_sha256=data.sha(BASE/'outputs/ti_nn_reverse_20261117/ti_ffn_weights_raw.npz'),
            held_scene_used_for_training_or_selection=False,independent_new_blind_test=False))
    model=canonical_model();assert sum(p.numel() for p in model.parameters() if p.requires_grad)==3265
    records=[]
    for scene in data.SCENES:
        target=OUT/'baselines'/f'{scene}.npz'
        ss,parts=split_rows(sources,coords,scene);va,te=parts['validation'],parts['test']
        if not target.exists():
            vp=data.predict_model(model,x,va);tp=data.predict_model(model,x,te)
            np.savez_compressed(target,validation_ids=va,validation_m=vp,test_ids=te,test_m=tp)
        with np.load(target) as c:
            np.testing.assert_array_equal(c['validation_ids'],va);np.testing.assert_array_equal(c['test_ids'],te)
            old_teacher=np.load(data.OUT/'frozen_predictions.npy',mmap_mode='r')[te]
            difference=float(abs(c['test_m']-old_teacher).max());assert difference<3e-4
        records.append(dict(scene=scene,train_n=len(parts['train']),validation_n=len(va),test_n=len(te),
            baseline_sha256=data.sha(target),old_numpy_teacher_max_difference_m=difference,
            train_truth_max_m=float(truth[parts['train']].max())))
    pd.DataFrame(records).to_csv(OUT/'baseline_audit.csv',index=False,encoding='utf-8-sig')
    print('PREPARED',len(x),'paths,4 complete scene holdouts',flush=True)


def baseline(scene,va,te):
    with np.load(OUT/'baselines'/f'{scene}.npz') as c:
        np.testing.assert_array_equal(c['validation_ids'],va);np.testing.assert_array_equal(c['test_ids'],te)
        return c['validation_m'].copy(),c['test_m'].copy()


def train(sources,x,coords,truth,seed,scene,lr,under):
    folder=run_folder(seed,scene,lr,under);folder.mkdir(parents=True,exist_ok=True)
    if (folder/'protocol.json').exists():
        assert json.loads((folder/'protocol.json').read_text(encoding='utf-8'))['version']==VERSION
        return
    ss,parts=split_rows(sources,coords,scene);tr,va,te=[parts[k] for k in ['train','validation','test']]
    si=coords['source_index'];vref,tref=baseline(scene,va,te)
    groups=validation_groups(sources,coords,truth,va)
    weights=data.row_weights(sources,ss['train'],si[tr]);yy=torch.from_numpy(truth[tr].astype(np.float32));ww=torch.from_numpy(weights)
    torch.manual_seed(seed+100*data.SCENES.index(scene));rng=np.random.default_rng(seed+100*data.SCENES.index(scene))
    model=canonical_model();parameters=list(model.parameters())
    assert len(parameters)==8 and sum(p.numel() for p in parameters)==3265 and all(p.requires_grad for p in parameters)
    original={k:v.detach().clone() for k,v in model.state_dict().items()}
    initial=data.predict_model(model,x,va);np.testing.assert_array_equal(initial,vref)
    optimizer=torch.optim.Adam(parameters,lr=lr)
    score=data.validation_metrics(initial,truth[va],si[va],sources)[0]
    best=(score,0,copy.deepcopy(model.state_dict()));raw=(score,0,copy.deepcopy(model.state_dict()))
    curves=[dict(epoch=0,lr=lr,train_loss=np.nan,validation_mae_m=score,p5_feasible=True,worst_p5_change_m=0.,
        first_batch_parameter_step_max=0.,first_batch_prediction_step_max_m=0.,cumulative_parameter_change_max=0.)]
    start_time=time.perf_counter();accepted=0;max_step=0.
    print('FIT',seed,scene,'lr',lr,'under_extra',under,'rows',len(tr),len(va),len(te),flush=True)
    for epoch in range(1,EPOCHS+1):
        current_lr=lr*(.1+.9*.5*(1+np.cos(np.pi*(epoch-1)/(EPOCHS-1))))
        optimizer.param_groups[0]['lr']=current_lr
        model.train();order=rng.permutation(len(tr));total=0.;step=0.;prediction_step=0.
        for start in range(0,len(order),BATCH):
            local=order[start:start+BATCH];global_ids=tr[local]
            # Advanced indexing makes a writable batch copy; no entire training
            # tensor copy is retained. Parallel seeds share the read-only cache.
            xx=torch.from_numpy(np.asarray(x[global_ids]))
            optimizer.zero_grad(set_to_none=True);pred=model(xx)
            loss=asymmetric_mse(pred,yy[local],ww[local],under)
            if start==0:before=[p.detach().clone() for p in parameters]
            loss.backward();optimizer.step();total+=float(loss.detach())*len(local)
            if start==0:
                step=max(float((p.detach()-q).abs().max()) for p,q in zip(parameters,before))
                with torch.no_grad():prediction_step=float(abs(model(xx)-pred.detach()).max())
        vp=data.predict_model(model,x,va)
        feasible,worst,_=gate_p5(vp,truth[va],vref,groups)
        score=data.validation_metrics(vp,truth[va],si[va],sources)[0]
        if score<raw[0]-1e-6:raw=(score,epoch,copy.deepcopy(model.state_dict()))
        if feasible:
            accepted+=1
            if score<best[0]-1e-6:best=(score,epoch,copy.deepcopy(model.state_dict()))
        state=model.state_dict()
        for k in ['input_offset','input_gain']:assert torch.equal(state[k],original[k])
        change=max(float((state[k]-v).abs().max()) for k,v in original.items() if k.startswith('layers.'))
        max_step=max(max_step,step)
        curves.append(dict(epoch=epoch,lr=current_lr,train_loss=total/len(tr),validation_mae_m=score,
            p5_feasible=feasible,worst_p5_change_m=worst,first_batch_parameter_step_max=step,
            first_batch_prediction_step_max_m=prediction_step,cumulative_parameter_change_max=change))
        pd.DataFrame(curves).to_csv(folder/'learning_curve.csv',index=False)
        print('EPOCH',seed,scene,lr,under,epoch,'val',round(score,5),'p5_delta',round(worst,5),
            'feasible',feasible,'best',best[1],'seconds',round(time.perf_counter()-start_time,1),flush=True)
    final=model.state_dict();layer_changes={}
    for layer in [0,2,4,6]:
        amount=max(float((final[f'layers.{layer}.{name}']-original[f'layers.{layer}.{name}']).abs().max()) for name in ['weight','bias'])
        assert amount>0;layer_changes[f'FC{layer//2+1}']=amount
    protocol=dict(version=VERSION,dataset_version=data.VERSION,training_implementation='canonical_all_fc_meters',
        seed=seed,held_scene=scene,lr=lr,under_extra=under,underestimation_weight=1+under,
        best_epoch=best[1],best_source_validation_mae_m=best[0],raw_best_epoch=raw[1],raw_best_validation_mae_m=raw[0],
        P5_feasible_epochs=accepted,epochs=EPOCHS,batch_size=BATCH,trainable_parameters=3265,
        all_four_FC_layers_updated=True,last_epoch_layer_parameter_changes=layer_changes,
        fixed_input_affine_unchanged=True,output_unit='meters',original_parameterization=True,
        no_parameter_or_forward_rescaling=True,optimizer='Adam, no weight decay',lr_schedule='cosine to one tenth',
        train_n=len(tr),validation_n=len(va),test_n=len(te),
        source_validation_rule='all source scene/range/path groups: signedP5 >= frozenP5 -1e-6m; then minimize source-balanced MAE',
        source_only_model_selection=True,held_scene_used_for_training_or_selection=False,
        no_output_floor=True,no_hidden_freezing=True,path_fusion=False,shared_model_all_paths=True,
        first_batch_parameter_step_max_across_epochs=max_step,threads=torch.get_num_threads(),
        primary_penalty=4.,baseline='canonical frozen original TI, no0.94m correction')
    predictions={}
    for kind,snapshot in [('gated',best),('raw_best',raw)]:
        model.load_state_dict(snapshot[2]);vp=data.predict_model(model,x,va);tp=data.predict_model(model,x,te)
        ok,worst,changes=gate_p5(vp,truth[va],vref,groups)
        if kind=='gated':assert ok
        saved=dict(protocol,checkpoint_kind=kind,checkpoint_epoch=snapshot[1],
            source_P5_passed=ok,worst_source_P5_change_m=worst)
        torch.save(dict(state_dict=model.state_dict(),protocol=saved),folder/f'{kind}_model_meters.pt')
        check=te[np.unique(np.linspace(0,len(te)-1,128).astype(int))]
        restored=canonical_model();restored.load_state_dict(snapshot[2])
        np.testing.assert_allclose(data.predict_model(restored,x,check),data.predict_model(model,x,check),atol=1e-5,rtol=1e-6)
        predictions[kind+'_m']=tp;write_json(folder/f'{kind}_source_p5.json',changes)
    np.savez_compressed(folder/'predictions.npz',sample_id=te,**predictions)
    write_json(folder/'protocol.json',protocol)
    print('COMPLETE',seed,scene,lr,under,'accepted',accepted,'best',best[1],'raw_best',raw[1],flush=True)


def summarize(sources,x,coords,truth):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from predict_ti_finetuned_iq import predict_finetuned_iq
    plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','DejaVu Sans'];plt.rcParams['axes.unicode_minus']=False
    si=coords['source_index'];records=[];details=[];choices=[];checks=[]
    for seed in SEEDS:
        complete={key:np.full(len(x),np.nan,np.float32) for key in ['frozen_TI','plain_selected','under_selected','plain_raw_selected','under_raw_selected']}
        for scene in data.SCENES:
            ss,parts=split_rows(sources,coords,scene);va,te=parts['validation'],parts['test'];vref,tref=baseline(scene,va,te)
            complete['frozen_TI'][te]=tref;groups=validation_groups(sources,coords,truth,va)
            frozen_score=data.validation_metrics(vref,truth[va],si[va],sources)[0]
            candidates={u:[dict(lr=0.,score=frozen_score,epoch=0,folder=None,pred=tref)] for u in UNDER_EXTRA}
            raw_candidates={u:[] for u in UNDER_EXTRA}
            for under in UNDER_EXTRA:
                for lr in LRS:
                    folder=run_folder(seed,scene,lr,under);p=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))
                    with np.load(folder/'predictions.npz') as c:
                        np.testing.assert_array_equal(c['sample_id'],te);g=c['gated_m'];r=c['raw_best_m']
                    obj=torch.load(folder/'gated_model_meters.pt',map_location='cpu',weights_only=True)
                    model=canonical_model();model.load_state_dict(obj['state_dict'])
                    vp=data.predict_model(model,x,va);ok,worst,_=gate_p5(vp,truth[va],vref,groups);assert ok
                    loc=np.unique(np.linspace(0,len(te)-1,128).astype(int));error=float(abs(data.predict_model(model,x,te[loc])-g[loc]).max());assert error<3e-4
                    raw_obj=torch.load(folder/'raw_best_model_meters.pt',map_location='cpu',weights_only=True)
                    raw_model=canonical_model();raw_model.load_state_dict(raw_obj['state_dict'])
                    raw_error=float(abs(data.predict_model(raw_model,x,te[loc])-r[loc]).max());assert raw_error<3e-4
                    candidates[under].append(dict(lr=lr,score=p['best_source_validation_mae_m'],epoch=p['best_epoch'],folder=str(folder),pred=g))
                    raw_candidates[under].append(dict(lr=lr,score=p['raw_best_validation_mae_m'],epoch=p['raw_best_epoch'],folder=str(folder),pred=r))
                    checks.append(dict(seed=seed,scene=scene,lr=lr,under_extra=under,reload_max_error_m=error,worst_source_p5_change_m=worst,
                        raw_reload_max_error_m=raw_error,all_FC_layers_changed=p['all_four_FC_layers_updated']))
            for under,label in [(0.,'plain'),(4.,'under')]:
                choice=min(candidates[under],key=lambda c:c['score']);raw=min(raw_candidates[under],key=lambda c:c['score'])
                complete[label+'_selected'][te]=choice['pred'];complete[label+'_raw_selected'][te]=raw['pred']
                choices.append(dict(seed=seed,scene=scene,method=label,selected_lr=choice['lr'],selected_epoch=choice['epoch'],
                    selected_validation_mae=choice['score'],raw_lr=raw['lr'],raw_epoch=raw['epoch'],raw_validation_mae=raw['score'],
                    frozen_validation_mae=frozen_score,selected_folder=choice['folder'],raw_folder=raw['folder']))
                if choice['folder']:
                    release=torch.load(Path(choice['folder'])/'gated_model_meters.pt',map_location='cpu',weights_only=True)
                else:
                    release=dict(state_dict=canonical_model().state_dict(),protocol=dict(dataset_version=data.VERSION,version=VERSION,
                        shared_model_all_paths=True,path_fusion=False,held_scene=scene,seed=seed,frozen_fallback=True,checkpoint_epoch=0))
                release['protocol']=dict(release['protocol'],release_policy=label+'_selected',source_only_selection=True)
                torch.save(release,OUT/f'seed_{seed}'/f'leave_{scene}'/f'{label}_selected_model_meters.pt')
                raw_release=torch.load(Path(raw['folder'])/'raw_best_model_meters.pt',map_location='cpu',weights_only=True)
                raw_release['protocol']=dict(raw_release['protocol'],release_policy=label+'_raw_selected',source_only_selection=True)
                torch.save(raw_release,OUT/f'seed_{seed}'/f'leave_{scene}'/f'{label}_raw_selected_model_meters.pt')
        for method,pred in complete.items():
            assert np.isfinite(pred).all()
            for scene in ['ALL',*data.SCENES]:
                ids=np.arange(len(x)) if scene=='ALL' else np.flatnonzero(sources.scene.to_numpy()[si]==scene)
                scopes=[('ALL',np.ones(len(ids),bool)),('true_le15m',truth[ids]<=15),('true_gt15m',truth[ids]>15)]
                if scene=='实车':
                    condition=sources.condition.to_numpy()[si[ids]]
                    scopes.extend([('condition:LOS',condition=='LOS'),('condition:NLOS',condition=='NLOS')])
                for scope,mask in scopes:
                    if mask.any():
                        m=data.metrics(pred[ids][mask],truth[ids][mask]);ref=data.metrics(complete['frozen_TI'][ids][mask],truth[ids][mask])
                        records.append(dict(seed=seed,scene=scene,scope=scope,method=method,
                            p5_change_m=m['error_p5_m']-ref['error_p5_m'],mae_change_m=m['mae_m']-ref['mae_m'],**m))
            car=np.flatnonzero(sources.scene.to_numpy()[si]=='实车')
            for condition in ['ALL','LOS','NLOS']:
                ix=car if condition=='ALL' else car[sources.condition.to_numpy()[si[car]]==condition]
                key=pd.DataFrame(dict(anchor=sources.anchor.to_numpy()[si[ix]],path=coords['path'][ix]))
                for (anchor,path),local in key.groupby(['anchor','path']).indices.items():
                    ids=ix[local];m=data.metrics(pred[ids],truth[ids]);ref=data.metrics(complete['frozen_TI'][ids],truth[ids])
                    details.append(dict(seed=seed,condition=condition,anchor=anchor,path=int(path),method=method,
                        p5_change_m=m['error_p5_m']-ref['error_p5_m'],**m))
        np.savez_compressed(OUT/f'out_of_scene_seed_{seed}.npz',**{k+'_m':v for k,v in complete.items()})
    each=pd.DataFrame(records);each.to_csv(OUT/'metrics_each_seed.csv',index=False)
    fields=['mae_m','error_p5_m','abs_error_p5_m','cep95_m','bias_m','under3_pct','over3_pct','p5_change_m','mae_change_m']
    avg=each.groupby(['scene','scope','method']).agg(n=('n','first'),**{f'{k}_{st}':(k,st) for k in fields for st in ['mean','std']}).reset_index()
    avg.to_csv(OUT/'metrics_two_seeds.csv',index=False)
    detail=pd.DataFrame(details);detail.to_csv(OUT/'car_anchor_path_each_seed.csv',index=False)
    detail.groupby(['condition','anchor','path','method']).agg(n=('n','first'),**{f'{k}_{st}':(k,st) for k in fields if k!='mae_change_m' for st in ['mean','std']}).reset_index().to_csv(OUT/'car_anchor_path_two_seeds.csv',index=False)
    pd.DataFrame(choices).to_csv(OUT/'source_only_selection.csv',index=False,encoding='utf-8-sig')
    source_diagnostics=[]
    for choice in choices:
        changes=json.loads((Path(choice['raw_folder'])/'raw_best_source_p5.json').read_text(encoding='utf-8'))
        worst_group=min(changes,key=changes.get)
        source_diagnostics.append(dict(seed=choice['seed'],held_scene=choice['scene'],method=choice['method'],
            raw_source_mae_m=choice['raw_validation_mae'],frozen_source_mae_m=choice['frozen_validation_mae'],
            worst_source_group=worst_group,worst_source_p5_change_m=changes[worst_group],
            groups_with_p5_decline=sum(v < -1e-6 for v in changes.values()),groups_total=len(changes)))
    pd.DataFrame(source_diagnostics).to_csv(OUT/'source_p5_diagnostics.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(checks).to_csv(OUT/'model_verification.csv',index=False)
    # Representative source IQ -> full exported model checks, both policies.
    raw_errors=[]
    for seed in SEEDS:
        for scene,g in sources.groupby('scene'):
            first=g.iloc[0]
            if first.cache_file:
                with np.load(first.cache_file) as c:
                    iq=c['iq'][:8].astype(np.float64);z=iq[:,:,0]+1j*iq[:,:,1]
            else:
                rows,_=data._parse_log(Path(first.file),complete_four_paths=False);z=np.stack([r[5] for r in rows[:8]])
            ids=np.arange(int(first.sample_start),int(first.sample_start)+len(z))
            for label in ['plain_selected','under_selected','plain_raw_selected','under_raw_selected']:
                checkpoint=OUT/f'seed_{seed}'/f'leave_{scene}'/f'{label}_model_meters.pt'
                p=predict_finetuned_iq(z,checkpoint)
                obj=torch.load(checkpoint,map_location='cpu',weights_only=True);model=canonical_model();model.load_state_dict(obj['state_dict'])
                q=data.predict_model(model,x,ids);error=float(abs(p-q).max());assert error<3e-4;raw_errors.append(error)
    write_json(OUT/'verification.json',dict(models_reloaded=2*len(checks),all_four_FC_layers_updated_in_every_run=True,
        original_parameterization=True,source_only_epoch_LR_selection=True,source_P5_constraints_recomputed=True,
        raw_IQ_selected_model_cases=len(raw_errors),max_raw_IQ_replay_error_m=max(raw_errors),
        maximum_reload_error_m=max(max(c['reload_max_error_m'],c['raw_reload_max_error_m']) for c in checks),structural_P5_guarantee=False))
    fig,axes=plt.subplots(2,2,figsize=(12,7),constrained_layout=True)
    for ax,scene in zip(axes.flat,data.SCENES):
        for under,color in [(0.,'#2563eb'),(4.,'#dc2626')]:
            for lr,ls in zip(LRS,['-','--']):
                curves=[pd.read_csv(run_folder(seed,scene,lr,under)/'learning_curve.csv') for seed in SEEDS]
                ax.plot(curves[0].epoch,np.mean([c.validation_mae_m for c in curves],axis=0),color=color,ls=ls,label=f'under={under:g}, lr={lr:g}')
        ax.set_title(scene);ax.set_xlabel('Epoch');ax.set_ylabel('Source validation balanced MAE /m');ax.grid(alpha=.2);ax.legend(fontsize=7)
    fig.savefig(OUT/'source_validation_mae_curves.png',dpi=150);plt.close(fig)
    for under in UNDER_EXTRA:
        fig,axes=plt.subplots(2,2,figsize=(12,7),constrained_layout=True)
        for ax,scene in zip(axes.flat,data.SCENES):
            for lr,color in zip(LRS,['#2563eb','#dc2626']):
                for seed,ls in zip(SEEDS,['-','--']):
                    curve=pd.read_csv(run_folder(seed,scene,lr,under)/'learning_curve.csv')
                    ax.plot(curve.epoch,curve.worst_p5_change_m,color=color,ls=ls,label=f'lr{lr:g} seed{seed}')
            ax.axhline(0,color='black',lw=.8);ax.set_title(scene);ax.set_xlabel('Epoch');ax.set_ylabel('Worst source P5 change /m');ax.grid(alpha=.2);ax.legend(fontsize=7)
        fig.suptitle(f'All-layer fine-tuning, extra underestimation weight={under:g}')
        fig.savefig(OUT/f'p5_curves_under{under:g}.png',dpi=150);plt.close(fig)
    report='# 全参数微调：低学习率与低估惩罚的四场景留一\n\n'
    report+=result_interpretation(avg)
    report+='使用全部有可靠标签的静态数据：928份日志、1,690,110条独立path输入；四场景留一、两个种子。实车116,005条path，真值按已确认3D几何换算。动态日志缺逐帧真值及未知slave3几何不编造标签。所有path共享模型，身份信息不入网络。\n\n'
    report+='从TI原权重开始，四个FC层的3265参数全部从第1步更新；固定协方差前端及输入offset/gain。不冻结隐藏层、不限制输出只能增加，不添加蒸馏或合成数据。保持原米制参数，loss中统一将误差除30，不对参数或forward再缩放。\n\n'
    report+='学习率1e-6与3e-6，12个全量epoch内余弦衰减到初始的1/10，batch4096，Adam无weight_decay。损失为mean(w*((e/30)^2+λ*relu(-e/30)^2))；λ4使低估平方损失为高估的5倍，λ0为相同小学习率的无惩罚对照。训练权重按来源场景、标称距离、文件等权。\n\n'
    report+='*_selected只使用来源验证的分组P5准入与MAE选择轮次和学习率：来源各场景、距离段、path的有符号P5不得低于同组冻结TI，容差1e-6m用于数值误差；无合格改善则回退epoch0。*_raw_selected按来源MAE选择但不执行P5准入，仅供诊断，不当作P5已合格模型。低估惩罚不构成未知场景P5的数学保证。\n\n'
    report+='## 场景留一\n\n|场景|方法|N|MAE|error P5|CEP95|P5变化|低估>3m%|\n|---|---|---|---|---|---|---|---|\n'
    for r in avg[avg.scope.eq('ALL')].itertuples():
        report+=f'|{r.scene}|{r.method}|{r.n}|{r.mae_m_mean:.4f}|{r.error_p5_m_mean:.4f}|{r.cep95_m_mean:.4f}|{r.p5_change_m_mean:+.5f}|{r.under3_pct_mean:.2f}|\n'
    report+='\n## 实车远距离\n\n|方法|N|MAE|error P5|CEP95|P5变化|低估>3m%|\n|---|---|---|---|---|---|---|\n'
    for r in avg[avg.scene.eq('实车')&avg.scope.eq('true_gt15m')].itertuples():
        report+=f'|{r.method}|{r.n}|{r.mae_m_mean:.4f}|{r.error_p5_m_mean:.4f}|{r.cep95_m_mean:.4f}|{r.p5_change_m_mean:+.5f}|{r.under3_pct_mean:.2f}|\n'
    report+='\n实车留出折来源只有1～15m，因此>15m包含距离外推；来源P5验收不保证未覆盖距离或新场景P5。模型/超参数从未按留出实车指标回选。该队列已用于开发，本次不属于新采集盲测。各指标为两次训练分别计算后取均值，N不重复计数，分位数不按场景简单平均。\n\n'
    car_ids=np.flatnonzero(sources.scene.to_numpy()[si]=='实车')
    with np.load(OUT/'baselines'/'实车.npz') as c:
        np.testing.assert_array_equal(c['test_ids'],car_ids)
        calibrated=data.metrics(c['test_m']-.94,truth[car_ids])
    write_json(OUT/'car_frozen_minus094_control.json',calibrated)
    report+=f"此前固定−0.94m校准的冻结TI实车对照：MAE {calibrated['mae_m']:.4f}m，error P5 {calibrated['error_p5_m']:.4f}m，CEP95 {calibrated['cep95_m']:.4f}m。该校准仅作已指定的附加对照，本轮模型不再次减0.94m。\n\n"
    report+='每折plain_selected_model_meters.pt和under_selected_model_meters.pt为来源验证选择模型；gated_model_meters.pt及raw_best_model_meters.pt保留各候选。直接米输出，不截零、不额外减0.94m；推理使用父工程predict_ti_finetuned_iq.py中的predict_finetuned_iq。source_only_selection.csv记录实际是否回退、学习率和轮次。逐LOS/NLOS及每锚点/path指标见CSV。\n\n'
    report+='raw_selected_model_meters.pt是实际微调后按来源MAE选择的诊断模型；可用于复查，但未通过P5准入不能称为满足P5要求。verification.json同时校验筛选及未筛选模型。\n\n'
    report+='![来源验证MAE](source_validation_mae_curves.png)\n\n![无惩罚P5曲线](p5_curves_under0.png)\n\n![加低估惩罚P5曲线](p5_curves_under4.png)\n'
    (OUT/'report.md').write_text(report,encoding='utf-8')
    print('SUMMARY\n'+avg[(avg.scope=='ALL')&(avg.scene=='实车')].to_string(index=False),flush=True)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['prepare','train','report','all'],default='all')
    parser.add_argument('--seed',type=int,choices=SEEDS,action='append');args=parser.parse_args()
    sys.stdout.reconfigure(encoding='utf-8');torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    if args.stage in ['prepare','all']:prepare()
    if args.stage in ['train','all']:
        sources,x,coords,truth=data.load_data()
        for seed in (args.seed or SEEDS):
            for scene in data.SCENES:
                for under in UNDER_EXTRA:
                    for lr in LRS:train(sources,x,coords,truth,seed,scene,lr,under)
    if args.stage in ['report','all']:
        sources,x,coords,truth=data.load_data();summarize(sources,x,coords,truth)


if __name__=='__main__':
    with threadpool_limits(limits=1):main()
