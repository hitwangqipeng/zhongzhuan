"""Strict unseen-scene control: sequential source domains with ER/DER++.

No held-scene input enters any update. This is supervised domain-incremental
learning followed by domain generalization, not unlabeled target adaptation.
"""
from pathlib import Path
import argparse,copy,json,sys,time
import numpy as np
import pandas as pd
import torch
from threadpoolctl import threadpool_limits
import experiment_ti_finetune_all_loso as data
import experiment_ti_full_under_loso as prior
from experiment_ti_fc3_bias_p5 import validation_groups,gate_p5
from audit_ti_finetune_implementation import canonical_model
from ti_continual_domain import DomainReplay

BASE=Path(__file__).resolve().parent
OUT=BASE/'outputs/ti_cda_20261119'
SEED=20261119
METHODS=('naive_seq','ER','DERpp')
EPOCHS_PER_DOMAIN=4
BATCH=2048
REPLAY_BATCH=512
CAPACITY=4096
LR=3e-6
VERSION='strict_source_sequential_replay_v1'


def write_json(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


def source_partition(sources,coords,scene):
    ss,parts=prior.split_rows(sources,coords,scene)
    si=coords['source_index'];domain_rows={};weights=np.zeros(len(si),np.float32)
    for name in data.SCENES:
        if name==scene:continue
        src=ss['train'][sources.scene.to_numpy()[ss['train']]==name]
        ids=parts['train'][sources.scene.to_numpy()[si[parts['train']]]==name]
        domain_rows[name]=ids;weights[ids]=data.row_weights(sources,src,si[ids])
    return ss,parts,domain_rows,weights


def train(sources,x,coords,truth,scene,order_name,method):
    folder=OUT/'strict'/f'leave_{scene}'/order_name/method;folder.mkdir(parents=True,exist_ok=True)
    if (folder/'protocol.json').exists():return
    ss,parts,rows,weights=source_partition(sources,coords,scene)
    order=list(rows)
    if order_name=='reverse':order.reverse()
    if method=='joint4':order=['JOINT']
    va,te=parts['validation'],parts['test'];si=coords['source_index'];groups=None
    vref,tref=prior.baseline(scene,va,te)
    model=canonical_model();original=copy.deepcopy(model.state_dict());memory=DomainReplay(CAPACITY,SEED)
    history=[];stage_validation=[];started=time.perf_counter();step_count=0;replay_exposures=0
    best=None;gated=None
    for stage,domain in enumerate(order,1):
        ids=parts['train'] if domain=='JOINT' else rows[domain]
        if domain=='JOINT':weights[ids]=data.row_weights(sources,ss['train'],si[ids])
        domain_seed=SEED+100*data.SCENES.index(scene)+(500 if domain=='JOINT' else 17*data.SCENES.index(domain))
        rng=np.random.default_rng(domain_seed);torch.manual_seed(domain_seed)
        optimizer=torch.optim.Adam(model.parameters(),lr=LR)
        if method!='naive_seq' and domain!='JOINT':memory.register(domain)
        is_final=stage==len(order)
        if is_final:
            # Delay the constant reference score until all source domains
            # arrive. It never affected earlier updates; final choices match.
            groups=validation_groups(sources,coords,truth,va)
            frozen_score=data.validation_metrics(vref,truth[va],si[va],sources)[0]
            best=(frozen_score,0,copy.deepcopy(original));gated=(frozen_score,0,copy.deepcopy(original))
            vp=data.predict_model(model,x,va);score=data.validation_metrics(vp,truth[va],si[va],sources)[0]
            if score<best[0]:best=(score,0,copy.deepcopy(model.state_dict()))
            ok,_,_=gate_p5(vp,truth[va],vref,groups)
            if ok and score<gated[0]:gated=(score,0,copy.deepcopy(model.state_dict()))
        print('FIT',scene,order_name,method,stage,domain,len(ids),flush=True)
        for epoch in range(1,EPOCHS_PER_DOMAIN+1):
            lr=LR*(.1+.9*.5*(1+np.cos(np.pi*(epoch-1)/(EPOCHS_PER_DOMAIN-1))))
            optimizer.param_groups[0]['lr']=lr;permutation=rng.permutation(ids);model.train();total=0.;n=0
            for start in range(0,len(ids),BATCH):
                current=permutation[start:start+BATCH];optimizer.zero_grad(set_to_none=True)
                pred=model(torch.from_numpy(np.array(x[current],copy=True)))
                y=torch.from_numpy(truth[current].astype(np.float32));w=torch.from_numpy(weights[current])
                loss=prior.asymmetric_mse(pred,y,w,4.)
                if method in ('ER','DERpp'):
                    old_ids,logits=memory.sample(REPLAY_BATCH,rng)
                    if len(old_ids):
                        old=model(torch.from_numpy(np.array(x[old_ids],copy=True)))
                        ow=torch.from_numpy(weights[old_ids]);oy=torch.from_numpy(truth[old_ids].astype(np.float32))
                        loss=loss+prior.asymmetric_mse(old,oy,ow,4.)
                        if method=='DERpp':loss=loss+torch.mean(ow*((old-torch.from_numpy(logits))/30).square())
                        replay_exposures+=len(old_ids)
                    if epoch==1:memory.add(domain,current,pred.detach().numpy())
                assert torch.isfinite(loss);loss.backward();optimizer.step()
                total+=float(loss.detach())*len(current);n+=len(current);step_count+=1
            visible=[d for d in order[:stage] if d!='JOINT']
            val=va if is_final else va[np.isin(sources.scene.to_numpy()[si[va]],visible)]
            vp=data.predict_model(model,x,val);score=data.validation_metrics(vp,truth[val],si[val],sources)[0]
            history.append(dict(stage=stage,domain=domain,epoch=epoch,lr=lr,loss=total/n,
                validation_seen_domains_mae=score,validation_domains='|'.join(visible) if domain!='JOINT' else '|'.join(rows)))
            if is_final:
                if score<best[0]-1e-6:best=(score,epoch,copy.deepcopy(model.state_dict()))
                ok,_,_=gate_p5(vp,truth[val],vref,groups)
                if ok and score<gated[0]-1e-6:gated=(score,epoch,copy.deepcopy(model.state_dict()))
            pd.DataFrame(history).to_csv(folder/'learning_curve.csv',index=False)
            print('EPOCH',scene,order_name,method,stage,epoch,round(score,5),'seconds',round(time.perf_counter()-started,1),flush=True)
        vp=data.predict_model(model,x,va if is_final else val)
        use=va if is_final else val
        for name in sorted(set(sources.scene.to_numpy()[si[use]])):
            mask=sources.scene.to_numpy()[si[use]]==name
            stage_validation.append(dict(stage=stage,domain=name,mae_m=float(abs(vp[mask]-truth[use][mask]).mean())))
    protocol=dict(version=VERSION,dataset_version=data.VERSION,method=method,held_scene=scene,order=order,seed=SEED,
        epochs_per_domain=EPOCHS_PER_DOMAIN,lr=LR,batch=BATCH,replay_batch=REPLAY_BATCH,memory_capacity=CAPACITY,
        DERpp_alpha=1.,DERpp_beta=1.,underestimation_squared_weight=5,new_sample_passes_per_source=4,
        joint12_baseline_has_three_times_new_label_exposure=True,steps=step_count,replay_exposures=replay_exposures,
        new_domain_source_labels=True,held_domain_input_or_labels_used=False,source_only_final_checkpoint_selection=True,
        intermediate_domain_epochs_fixed=True,future_domain_validation_not_used_before_arrival=True,
        replay_domain_balanced_priority_reservoir=True,replay_logits='at first-pass arrival before update',
        path_fusion=False,shared_model_all_paths=True,original_meter_parameterization=True)
    preds={}
    for kind,snapshot in [('raw',best),('gated',gated)]:
        model.load_state_dict(snapshot[2]);vp=data.predict_model(model,x,va);tp=data.predict_model(model,x,te)
        passed,worst,_=gate_p5(vp,truth[va],vref,groups)
        if kind=='gated':assert passed
        for key in ['input_offset','input_gain']:assert torch.equal(model.state_dict()[key],original[key])
        torch.save(dict(state_dict=model.state_dict(),protocol=dict(protocol,checkpoint_epoch=snapshot[1],
            source_validation_mae=snapshot[0],source_P5_passed=passed,worst_source_P5_change_m=worst)),folder/f'{kind}_model_meters.pt')
        preds[kind+'_m']=tp
        if kind=='raw':
            for name in rows:
                mask=sources.scene.to_numpy()[si[va]]==name
                stage_validation.append(dict(stage='selected_final',domain=name,mae_m=float(abs(vp[mask]-truth[va][mask]).mean())))
    np.savez_compressed(folder/'predictions.npz',sample_id=te,**preds)
    pd.DataFrame(stage_validation).to_csv(folder/'old_domain_validation.csv',index=False,encoding='utf-8-sig')
    write_json(folder/'protocol.json',protocol)
    print('COMPLETE',scene,order_name,method,flush=True)


def main():
    p=argparse.ArgumentParser();p.add_argument('--order',choices=['forward','reverse'],required=True);args=p.parse_args()
    sys.stdout.reconfigure(encoding='utf-8');torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    OUT.mkdir(parents=True,exist_ok=True)
    sources,x,coords,truth=data.load_data()
    for scene in data.SCENES:
        if args.order=='forward':train(sources,x,coords,truth,scene,'joint','joint4')
        for method in METHODS:train(sources,x,coords,truth,scene,args.order,method)
    write_json(OUT/f'strict_{args.order}_complete.json',dict(order=args.order,version=VERSION))


if __name__=='__main__':
    with threadpool_limits(limits=1):main()
