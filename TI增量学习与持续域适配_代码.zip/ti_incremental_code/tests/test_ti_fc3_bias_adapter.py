import unittest
import numpy as np
import torch

from audit_ti_finetune_implementation import canonical_model
from ti_fc3_bias_adapter import TiFc3BiasAdapter
from experiment_ti_fc3_bias_p5 import gate_p5


class TestFc3BiasAdapter(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(1)

    def test_zero_delta_has_exact_teacher_output(self):
        model=TiFc3BiasAdapter(canonical_model());x=torch.randn(37,156)*.02
        p,t=model(x,True);self.assertTrue(torch.equal(p,t))
        self.assertEqual(sum(p.numel() for p in model.parameters() if p.requires_grad),24)

    def test_monotonic_output_for_positive_bias_magnitudes(self):
        model=TiFc3BiasAdapter(canonical_model(),monotonic=True)
        with torch.no_grad():model.delta.copy_(torch.linspace(0,.02,24))
        # Direct preactivations exercise positive/negative head weights and
        # ReLU threshold crossings, independent of the actual data manifold.
        a=torch.linspace(-.03,.03,2400).reshape(100,24)
        p,t=model.from_preactivation(a,True)
        self.assertTrue(torch.all(p>=t))
        self.assertGreater(float((p-t).detach().max()),0)
        self.assertLessEqual(float((p-t).detach().max()),model.distance_change_bound_m()+1e-5)

    def test_matches_actual_fc3_bias_change(self):
        import copy
        model=TiFc3BiasAdapter(canonical_model(),monotonic=False)
        with torch.no_grad():model.delta.copy_(torch.linspace(-.003,.003,24))
        folded=copy.deepcopy(model.teacher)
        with torch.no_grad():folded.layers[4].bias.add_(model.delta)
        x=torch.randn(53,156)*.02
        with torch.no_grad():a=model(x);b=folded(x)
        torch.testing.assert_close(a,b,rtol=1e-5,atol=1e-4)

    def test_monotonic_zero_initialization_can_learn(self):
        model=TiFc3BiasAdapter(canonical_model(),monotonic=True)
        a=torch.ones(16,24)
        output,teacher=model.from_preactivation(a,True)
        optimizer=torch.optim.Adam([model.delta],lr=1e-6)
        loss=(output-(teacher.detach()+1)).square().mean();loss.backward()
        previous=model.delta.detach().clone();optimizer.step();model.project_(previous,1e-6)
        after,baseline=model.from_preactivation(a,True)
        self.assertGreater(float(model.delta.detach().max()),0)
        self.assertTrue(torch.all(after>=baseline))

    def test_projected_step_and_frozen_teacher(self):
        model=TiFc3BiasAdapter(canonical_model(),monotonic=False)
        old={k:v.clone() for k,v in model.teacher.state_dict().items()}
        optimizer=torch.optim.Adam([model.delta],lr=1e-6)
        x=torch.randn(32,156)*.02;output=model(x)
        loss=(output-20).square().mean();loss.backward();previous=model.delta.detach().clone();optimizer.step();model.project_(previous,1e-6)
        self.assertLessEqual(float((model.delta.detach()-previous).abs().max()),1.00001e-6)
        self.assertGreater(float(model.delta.detach().abs().max()),0)
        for k,v in model.teacher.state_dict().items():self.assertTrue(torch.equal(v,old[k]))

    def test_signed_p5_gate_rejects_downward_shift(self):
        teacher=np.linspace(1,20,1000);truth=np.linspace(2,18,1000);groups={'all':np.arange(1000)}
        ok,_,_=gate_p5(teacher-.01,truth,teacher,groups);self.assertFalse(ok)
        ok,_,_=gate_p5(teacher+.01,truth,teacher,groups);self.assertTrue(ok)


if __name__=='__main__':unittest.main()
