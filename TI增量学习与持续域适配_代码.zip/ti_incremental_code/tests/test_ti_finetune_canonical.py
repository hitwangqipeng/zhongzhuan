import unittest
import numpy as np
import torch
from torch import nn

from audit_ti_finetune_implementation import canonical_model
from ti_pretrained_nn import load_weights, predict
from ti_sdk_nn import covariance_features


class TestCanonicalFinetune(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(1)

    def test_original_parameter_values_are_preserved(self):
        model=canonical_model();_,_,layers=load_weights()
        for layer,(w,b) in zip([v for v in model.layers if isinstance(v,nn.Linear)],layers):
            np.testing.assert_array_equal(layer.weight.detach().numpy(),w)
            np.testing.assert_array_equal(layer.bias.detach().numpy(),b)

    def test_prediction_matches_teacher_without_forward_rescaling(self):
        rng=np.random.default_rng(19)
        z=rng.normal(size=(31,80))+1j*rng.normal(size=(31,80))
        x=covariance_features(z);model=canonical_model()
        with torch.no_grad():out=model(torch.from_numpy(x)).numpy()
        np.testing.assert_allclose(out,predict(x),atol=1e-4,rtol=2e-5)

    def test_head_gradient_uses_original_meter_parameter_units(self):
        model=canonical_model(torch.float64)
        for p in model.layers[:-1].parameters():p.requires_grad_(False)
        rng=np.random.default_rng(7)
        x=torch.from_numpy(covariance_features(rng.normal(size=(13,80))+1j*rng.normal(size=(13,80)))).double()
        with torch.no_grad():h=model.layers[:-1]((x-model.input_offset)*model.input_gain).clone()
        target=torch.linspace(2.,26.,13,dtype=torch.float64)
        weights=torch.linspace(.3,1.7,13,dtype=torch.float64)
        output=model(x);loss=torch.mean(weights*((output-target)/30).square());loss.backward()
        expected_weight=((2/len(x)/900)*weights[:,None]*(output.detach()-target)[:,None]*h).sum(0,keepdim=True)
        expected_bias=(2/len(x)/900*weights*(output.detach()-target)).sum().reshape(1)
        torch.testing.assert_close(model.layers[-1].weight.grad,expected_weight,rtol=1e-12,atol=1e-12)
        torch.testing.assert_close(model.layers[-1].bias.grad,expected_bias,rtol=1e-12,atol=1e-12)


if __name__=='__main__':unittest.main()
