import unittest
import numpy as np
import torch

from ti_incremental_mlp import LoRAMLP,AdapterMLP,gaussian_diagonal_fisher,ewc_penalty
from audit_ti_finetune_implementation import canonical_model
from ti_sdk_nn import covariance_features


class TestIncrementalMLP(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1);torch.manual_seed(4)
        rng=np.random.default_rng(4)
        cls.x=torch.from_numpy(covariance_features(rng.normal(size=(16,80))+1j*rng.normal(size=(16,80))))

    def test_initial_lora_adapter_are_exact_original_teacher(self):
        teacher=canonical_model()(self.x)
        for model in [LoRAMLP(2),LoRAMLP(4),AdapterMLP(4),AdapterMLP(8)]:
            torch.testing.assert_close(model(self.x),teacher,rtol=0,atol=0)

    def test_expected_fisher_matches_individual_jacobians(self):
        model=canonical_model(torch.float64);x=self.x[:5].double();weights=torch.tensor([1.,3.,2.,4.,1.],dtype=x.dtype)
        fast=gaussian_diagonal_fisher(model,x,weights)
        actual={name:torch.zeros_like(p) for name,p in model.named_parameters()}
        for i in range(len(x)):
            grads=torch.autograd.grad(model(x[i:i+1])[0]/30,tuple(model.parameters()))
            for (name,_),g in zip(model.named_parameters(),grads):actual[name]+=g.square()*weights[i]/weights.sum()
        for name in fast:torch.testing.assert_close(fast[name],actual[name],rtol=2e-12,atol=2e-12)

    def test_ewc_zero_at_anchor_positive_after_change(self):
        model=canonical_model();anchor={n:p.detach().clone() for n,p in model.named_parameters()}
        fisher=gaussian_diagonal_fisher(model,self.x)
        self.assertEqual(float(ewc_penalty(model,anchor,fisher).detach()),0.)
        with torch.no_grad():model.layers[-1].bias.add_(1)
        self.assertGreater(float(ewc_penalty(model,anchor,fisher).detach()),0.)

    def test_lora_merge_preserves_predictions_and_original_parameters_freeze(self):
        model=LoRAMLP(2);base={n:p.detach().clone() for n,p in model.named_parameters() if not p.requires_grad}
        opt=torch.optim.Adam([p for p in model.parameters() if p.requires_grad],lr=1e-4)
        for _ in range(3):
            opt.zero_grad();(model(self.x)-3).square().mean().backward();opt.step()
        torch.testing.assert_close(model(self.x),model.merged()(self.x),rtol=2e-5,atol=5e-5)
        for n,p in model.named_parameters():
            if n in base:torch.testing.assert_close(p,base[n],rtol=0,atol=0)

    def test_adapter_cache_and_frozen_backbone(self):
        model=AdapterMLP(4);base={n:p.detach().clone() for n,p in model.base.named_parameters()}
        hidden=model.hidden(self.x).detach();opt=torch.optim.Adam([p for p in model.parameters() if p.requires_grad],lr=1e-4)
        opt.zero_grad();(model.from_hidden(hidden)-3).square().mean().backward();opt.step()
        torch.testing.assert_close(model.from_hidden(hidden),model(self.x),rtol=0,atol=0)
        for n,p in model.base.named_parameters():torch.testing.assert_close(p,base[n],rtol=0,atol=0)
        self.assertEqual(sum(p.numel() for p in model.parameters() if p.requires_grad),220)


if __name__=='__main__':unittest.main()
