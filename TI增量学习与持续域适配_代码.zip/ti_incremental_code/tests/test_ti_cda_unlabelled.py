import unittest
import numpy as np
import torch
from audit_ti_finetune_implementation import canonical_model
from experiment_ti_cda_unlabelled import adapt_features,select_sessions,data
from ti_sdk_nn import covariance_features


class TestUnlabelledCDA(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(1)
        rng=np.random.default_rng(72)
        cls.x=covariance_features(rng.normal(size=(32,80))+1j*rng.normal(size=(32,80)))

    def test_cotta_runs_without_source_data_or_target_labels(self):
        initial=canonical_model().state_dict()
        cfg=dict(method='CoTTA_reg',lr=3e-6,strength=1.)
        model,curve,_=adapt_features(initial,cfg,None,None,None,self.x,self.x*.999,self.x*1.001,
            np.r_[np.zeros(16,int),np.ones(16,int)],7,'forward')
        self.assertEqual(len(curve),2)
        self.assertTrue(torch.isfinite(model(torch.from_numpy(self.x))).all())
        self.assertTrue(torch.equal(model.input_gain,initial['input_gain']))

    def test_source_only_replay_does_not_depend_on_target_values(self):
        initial=canonical_model().state_dict();cfg=dict(method='source_replay',lr=3e-6,strength=0.)
        with torch.no_grad():y=canonical_model()(torch.from_numpy(self.x)).numpy()+1
        args=(initial,cfg,self.x,y,np.ones(32,np.float32))
        blocks=np.r_[np.zeros(16,int),np.ones(16,int)]
        a,_,_=adapt_features(*args,self.x,self.x,self.x,blocks,13,'forward')
        b,_,_=adapt_features(*args,self.x*.1,self.x*.2,self.x*.3,blocks,13,'forward')
        for n,p in a.state_dict().items():torch.testing.assert_close(p,b.state_dict()[n],rtol=0,atol=0)

    def test_split_uses_whole_sessions_disjoint_from_test(self):
        import pandas as pd
        sources=pd.read_csv(data.OUT/'sources.csv',keep_default_na=False)
        for scene in data.SCENES:
            cal,test=select_sessions(sources,scene)
            self.assertTrue(len(cal)>0 and len(test)>0)
            self.assertFalse(set(sources.session_id.iloc[cal])&set(sources.session_id.iloc[test]))
            self.assertFalse(set(sources.source_sha256.iloc[cal])&set(sources.source_sha256.iloc[test]))

    def test_repeated_steps_do_not_duplicate_target_replay_entries(self):
        initial=canonical_model().state_dict();cfg=dict(method='CORAL_replay',lr=3e-6,strength=.01,steps_per_batch=3)
        with torch.no_grad():y=canonical_model()(torch.from_numpy(self.x)).numpy()+1
        model,curve,_=adapt_features(initial,cfg,self.x,y,np.ones(32,np.float32),self.x,self.x,self.x,
            np.r_[np.zeros(16,int),np.ones(16,int)],17,'forward')
        self.assertEqual(len(curve),6)
        self.assertEqual(curve[-1]['memory_n'],32)


if __name__=='__main__':unittest.main()
