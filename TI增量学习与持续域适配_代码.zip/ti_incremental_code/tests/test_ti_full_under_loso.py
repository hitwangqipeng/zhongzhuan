import unittest
import numpy as np
import torch
from experiment_ti_full_under_loso import asymmetric_mse
from audit_ti_finetune_implementation import canonical_model
from ti_sdk_nn import covariance_features


class TestFullUnderLoss(unittest.TestCase):
    @classmethod
    def setUpClass(cls):torch.set_num_threads(1)

    def test_underestimation_has_five_times_loss_and_gradient(self):
        p=torch.tensor([2.,-2.],dtype=torch.float64,requires_grad=True)
        loss=asymmetric_mse(p,torch.zeros_like(p),torch.ones_like(p),4.)
        self.assertAlmostEqual(float(loss.detach()),12/900)
        loss.backward()
        self.assertAlmostEqual(float(abs(p.grad[1]/p.grad[0])),5.)

    def test_zero_penalty_is_standard_weighted_mse(self):
        p=torch.tensor([1.,-3.,2.]);y=torch.tensor([4.,-1.,2.]);w=torch.tensor([.5,1.,2.])
        torch.testing.assert_close(asymmetric_mse(p,y,w,0.),torch.mean(w*((p-y)/30).square()))

    def test_all_fc_layers_update_but_affine_buffers_do_not(self):
        model=canonical_model();before={k:v.clone() for k,v in model.state_dict().items()}
        self.assertEqual(sum(p.numel() for p in model.parameters() if p.requires_grad),3265)
        rng=np.random.default_rng(32);z=rng.normal(size=(64,80))+1j*rng.normal(size=(64,80))
        x=torch.from_numpy(covariance_features(z));out=model(x);target=out.detach()+1.
        opt=torch.optim.Adam(model.parameters(),lr=1e-6)
        asymmetric_mse(out,target,torch.ones_like(out),4.).backward();opt.step()
        after=model.state_dict()
        for layer in [0,2,4,6]:
            amount=sum(float(abs(after[f'layers.{layer}.{k}']-before[f'layers.{layer}.{k}']).sum()) for k in ['weight','bias'])
            self.assertGreater(amount,0)
        for k in ['input_offset','input_gain']:self.assertTrue(torch.equal(after[k],before[k]))


if __name__=='__main__':unittest.main()
