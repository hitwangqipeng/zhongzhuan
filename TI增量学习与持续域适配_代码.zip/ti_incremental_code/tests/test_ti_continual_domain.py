import unittest
import numpy as np
import torch
from ti_continual_domain import DomainReplay,coral_loss,reverse_gradient,ema_update,stochastic_restore


class TestContinualDomain(unittest.TestCase):
    def test_memory_budget_and_past_prediction_alignment(self):
        b=DomainReplay(30,7)
        for d in range(3):
            ids=np.arange(d*100,d*100+100)
            b.add(d,ids,ids.astype(np.float32)*.5)
            stored,pred=b.arrays();self.assertLessEqual(len(stored),30)
            np.testing.assert_array_equal(pred,stored*.5)
        self.assertEqual([len(v['ids']) for v in b.domains.values()],[10,10,10])

    def test_memory_rejects_duplicate_stored_observation(self):
        b=DomainReplay(30,1);b.add('a',np.arange(10),np.arange(10))
        with self.assertRaises(ValueError):b.add('a',np.arange(10),np.arange(10))

    def test_coral_zero_for_identical_covariance_and_backprop(self):
        x=torch.randn(15,24,requires_grad=True)
        torch.testing.assert_close(coral_loss(x,x),torch.tensor(0.))
        loss=coral_loss(x,x.detach()*2);self.assertGreater(float(loss.detach()),0.)
        loss.backward();self.assertGreater(float(x.grad.abs().sum()),0.)

    def test_domain_gradient_reversal(self):
        x=torch.tensor([1.,2.],requires_grad=True)
        reverse_gradient(x,.2).sum().backward()
        torch.testing.assert_close(x.grad,torch.tensor([-.2,-.2]))

    def test_teacher_ema_and_restore_endpoints(self):
        a=torch.nn.Linear(2,1);b=torch.nn.Linear(2,1)
        with torch.no_grad():
            for p in a.parameters():p.zero_()
            for p in b.parameters():p.fill_(2.)
        ema_update(a,b,.5)
        for p in a.parameters():torch.testing.assert_close(p,torch.ones_like(p))
        anchor={n:torch.zeros_like(p) for n,p in b.named_parameters()}
        stochastic_restore(b,anchor,0.,torch.Generator().manual_seed(7))
        for p in b.parameters():torch.testing.assert_close(p,torch.full_like(p,2.))
        stochastic_restore(b,anchor,1.,torch.Generator().manual_seed(7))
        for p in b.parameters():torch.testing.assert_close(p,torch.zeros_like(p))


if __name__=='__main__':unittest.main()
