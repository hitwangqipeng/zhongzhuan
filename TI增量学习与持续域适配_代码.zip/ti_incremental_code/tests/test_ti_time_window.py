import unittest
import numpy as np
from ti_time_window import compute_window,hist_window,apply_window,analyze_pdp,estimate_single_path_state


class TiTimeWindowTests(unittest.TestCase):
    def test_gaussian_shape_and_explicit_zero_state_bypass(self):
        w=compute_window(256,21)
        self.assertTrue(np.all(w[:22]==1))
        self.assertAlmostEqual(float(w[37]),np.exp(-.5),places=7)
        self.assertEqual(w[-1],1)
        self.assertLess(compute_window(256,0)[20],1)
        np.testing.assert_array_equal(hist_window(0),np.ones(256))

    def test_fft_size_ratio_changes_center(self):
        np.testing.assert_array_equal(hist_window(9,nfft=512,pdp_nfft=256),compute_window(512,20))
        np.testing.assert_array_equal(hist_window(9,nfft=128,pdp_nfft=256),compute_window(128,0))

    def test_isolated_spike_is_not_a_qualified_sdk_peak(self):
        p=np.full((1,256),.05,np.float32);p[0,40]=1
        self.assertFalse(analyze_pdp(p)['valid'][0])
        p[0,39]=.9
        self.assertTrue(analyze_pdp(p)['valid'][0])
        self.assertEqual(analyze_pdp(p)['first_crossing'][0],39)

    def test_negative_delay_maximum_disables_state(self):
        k=np.arange(80);z=np.exp(-2j*np.pi*k*190/256)[None,:]
        self.assertEqual(estimate_single_path_state(z)['peak_bin_sap'][0],0)

    def test_explicit_state_zero_round_trip_and_shared_complex_gain(self):
        rng=np.random.default_rng(200);z=rng.normal(size=(2,80))+1j*rng.normal(size=(2,80))
        np.testing.assert_allclose(apply_window(z,[0,0]),z,atol=1e-12)
        a=estimate_single_path_state(z)['peak_bin_sap']
        b=estimate_single_path_state(z*(2+3j))['peak_bin_sap']
        np.testing.assert_array_equal(a,b)


if __name__=='__main__':unittest.main()
