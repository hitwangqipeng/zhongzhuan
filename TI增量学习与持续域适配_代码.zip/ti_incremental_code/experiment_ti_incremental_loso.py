"""Single-path EWC-proxy/LwF/LoRA/Adapter, full labelled scene holdouts."""
from pathlib import Path
import argparse
import copy
import json
import sys
import time

import numpy as np
import pandas as pd
import torch
from threadpoolctl import threadpool_limits

import experiment_ti_finetune_all_loso as data
import experiment_ti_full_under_loso as prior
from experiment_ti_fc3_bias_p5 import validation_groups,gate_p5
from audit_ti_finetune_implementation import canonical_model
from ti_incremental_mlp import VERSION,AdapterMLP,LoRAMLP,make_model,gaussian_diagonal_fisher,ewc_penalty,load_incremental,predict_incremental_iq

BASE=Path(__file__).resolve().parent
OUT=BASE/'outputs/ti_incremental_loso_20261119'
SEEDS=(20261118,20261119)
FAMILIES=('ewc_proxy','lwf','lora','adapter')
EPOCHS=12
BATCH=4096
CONFIGS=[
    dict(id=f'ewc_l{v}',method='ewc_proxy',strength=float(v),lr=3e-6) for v in (1,10)
]+[
    dict(id=f'lwf_l{v}',method='lwf',strength=float(v),lr=3e-6) for v in (1,10)
]+[
    dict(id=f'lora_r{v}',method='lora',rank=v,lr=3e-5) for v in (2,4)
]+[
    dict(id=f'adapter_b{v}',method='adapter',bottleneck=v,lr=3e-5) for v in (4,8)
]
EXTRA_CONFIGS=[dict(id=f'ewc_l{v}',method='ewc_proxy',strength=float(v),lr=3e-6) for v in (1000,10000)]
ALL_CONFIGS=CONFIGS+EXTRA_CONFIGS


def write_json(path,value):
    Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


def run_folder(seed,scene,config,under=4.):
    return OUT/f'seed_{seed}'/f'leave_{scene}'/f"{config['id']}_under{under:g}"


def source_weights(sources,source_ids,sample_si):
    virtual=sources.copy();counts=np.bincount(sample_si,minlength=len(sources))
    virtual['n_paths']=counts
    return data.row_weights(virtual,source_ids,sample_si)


def prepare():
    OUT.mkdir(parents=True,exist_ok=True);(OUT/'fisher').mkdir(exist_ok=True)
    amendment=OUT/'config_grid_amendment.json'
    if not amendment.exists():
        write_json(amendment,dict(added_configs=EXTRA_CONFIGS,
            reason='Fixed source-only scale amendment from initial development run: lambda1/10 retention was weak; no held-scene errors used',
            old_trials_preserved=True,original_plan_unchanged=True,TI_old_task_Fisher_unavailable=True))
    else:assert json.loads(amendment.read_text(encoding='utf-8'))['added_configs']==EXTRA_CONFIGS
    plan=dict(version=VERSION,configs=CONFIGS,seeds=list(SEEDS),scenes=list(data.SCENES),epochs=EPOCHS,batch_size=BATCH,
        primary_under_extra=4.,primary_underestimation_squared_weight=5,
        loss='weighted ((e/30)^2+4*relu(-e/30)^2) + method retention term',
        ewc='source-train expected Gaussian diagonal Fisher of original f/30; unit noise variance, raw Fisher, no trace normalization; NOT TI old-task Fisher',
        lwf='weighted ((student-original_TI)/30)^2 on source training inputs',
        lora='all4 FC matrices, rank=min(config_rank,in,out), alpha=rank, original biases frozen, randomA/zeroB',
        adapter='residual24->b->24 ReLU bottleneck after frozen third hidden ReLU, zero up projection',
        optimizer='Adam, no weight decay; cosine LR to initial/10 over12 full passes',
        fisher_sampling='up to32 paths per SOURCE TRAIN file, file/nominal-distance/scene balanced weights, no labels used',
        hyperparameter_selection='per fold+seed, source validation balanced MAE; separate source grouped P5 admission policy; epoch0 included',
        no_under_ablation='only source-selected family/config among4methods+full_under5+frozen, matched hyperparameters',
        held_scene_used_for_fitting_or_selection=False,new_blind_test=False,path_fusion=False,shared_model_all_paths=True,
        source_dataset=str(data.OUT),source_dataset_sha256=data.sha(data.OUT/'dataset_protocol.json'),
        original_weights_sha256=data.sha(BASE/'outputs/ti_nn_reverse_20261117/ti_ffn_weights_raw.npz'),
        TI_original_training_data_or_Fisher_available=False)
    p=OUT/'experiment_plan.json'
    if p.exists():assert json.loads(p.read_text(encoding='utf-8'))==plan
    else:write_json(p,plan)
    write_json(OUT/'effective_experiment_plan.json',dict(version=VERSION,configs=ALL_CONFIGS,
        primary_trials=len(ALL_CONFIGS)*len(SEEDS)*len(data.SCENES),
        original_plan_sha256=data.sha(p),source_only_amendment_sha256=data.sha(amendment)))
    if (OUT/'feature_protocol.json').exists():
        spec=json.loads((OUT/'feature_protocol.json').read_text(encoding='utf-8'))
        for f,h in spec['artifact_sha256'].items():assert data.sha(OUT/f)==h
        return
    sources,x,coords,truth=data.load_data();model=canonical_model();model.eval()
    hidden=np.lib.format.open_memmap(OUT/'hidden24.partial.npy',mode='w+',dtype=np.float32,shape=(len(x),24))
    teacher=np.empty(len(x),np.float32)
    with torch.no_grad():
        for start in range(0,len(x),16384):
            xx=torch.from_numpy(np.array(x[start:start+16384],copy=True))
            h=model.layers[:-1]((xx-model.input_offset)*model.input_gain)
            hidden[start:start+len(xx)]=h.numpy();teacher[start:start+len(xx)]=model.layers[-1](h).squeeze(-1).numpy()
    hidden.flush();del hidden;(OUT/'hidden24.partial.npy').replace(OUT/'hidden24.npy');np.save(OUT/'teacher_m.npy',teacher)
    old=np.load(data.OUT/'frozen_predictions.npy',mmap_mode='r');difference=float(abs(teacher-old).max());assert difference<3e-4
    for scene in data.SCENES:
        ss,parts=prior.split_rows(sources,coords,scene);rng=np.random.default_rng(20261119+data.SCENES.index(scene));ids=[]
        for source in ss['train']:
            r=sources.iloc[source];ids.extend(rng.choice(np.arange(r.sample_start,r.sample_stop),min(32,int(r.n_paths)),replace=False).tolist())
        ids=np.asarray(ids,np.int64);weights=source_weights(sources,ss['train'],coords['source_index'][ids]);weights=weights/weights.sum()
        assert set(coords['source_index'][ids])<=set(ss['train'])
        assert not np.isin(ids,parts['test']).any() and not np.isin(ids,parts['validation']).any()
        fisher={name:torch.zeros_like(p,dtype=torch.float64) for name,p in model.named_parameters()}
        for start in range(0,len(ids),512):
            idx=ids[start:start+512];w=torch.from_numpy(weights[start:start+512].astype(np.float64))
            batch=gaussian_diagonal_fisher(model,torch.from_numpy(np.array(x[idx],copy=True)),w.float())
            for name,value in batch.items():fisher[name]+=value.double()*float(w.sum())
        fisher={name:value.float() for name,value in fisher.items()}
        assert all(torch.isfinite(v).all() and (v>=0).all() for v in fisher.values())
        anchor={name:p.detach().clone() for name,p in model.named_parameters()}
        torch.save(dict(anchor=anchor,fisher=fisher,protocol=dict(held_scene=scene,samples=len(ids),source_train_only=True,
            labels_used=False,regression_target_residuals_used=False,nominal_distance_metadata_used_for_balancing=True,
            normalized_output='meters/30',Gaussian_variance=1.,original_task_Fisher=False)),OUT/'fisher'/f'{scene}.pt')
        np.savez_compressed(OUT/'fisher'/f'{scene}_sample_ids.npz',sample_id=ids,weight=weights)
        print('FISHER',scene,len(ids),'trace',sum(float(v.sum()) for v in fisher.values()),flush=True)
    files=['hidden24.npy','teacher_m.npy',*[f'fisher/{s}.pt' for s in data.SCENES]]
    write_json(OUT/'feature_protocol.json',dict(version=VERSION,n=len(x),frozen_hidden_cache_only_for_adapter_training=True,
        original_numpy_teacher_max_difference_m=difference,preprocessing_unchanged=True,
        artifact_sha256={f:data.sha(OUT/f) for f in files}))
    print('PREPARED',len(x),'independent paths',flush=True)


def train_one(sources,x,coords,truth,teacher,hidden,seed,scene,config,under=4.):
    folder=run_folder(seed,scene,config,under);folder.mkdir(parents=True,exist_ok=True)
    if (folder/'protocol.json').exists():
        assert json.loads((folder/'protocol.json').read_text(encoding='utf-8'))['version']==VERSION
        return
    ss,parts=prior.split_rows(sources,coords,scene);tr,va,te=[parts[k] for k in ['train','validation','test']]
    vref,tref=prior.baseline(scene,va,te);si=coords['source_index'];groups=validation_groups(sources,coords,truth,va)
    weights=data.row_weights(sources,ss['train'],si[tr]);yy=torch.from_numpy(truth[tr].astype(np.float32));ww=torch.from_numpy(weights)
    torch.manual_seed(seed+100*data.SCENES.index(scene));rng=np.random.default_rng(seed+100*data.SCENES.index(scene))
    model=make_model(config);original=copy.deepcopy(model.state_dict());parameters=[p for p in model.parameters() if p.requires_grad]
    initial=data.predict_model(model,x,va);np.testing.assert_array_equal(initial,vref)
    score=data.validation_metrics(initial,truth[va],si[va],sources)[0]
    raw=(score,0,copy.deepcopy(original));gated=(score,0,copy.deepcopy(original));accepted=0
    optimizer=torch.optim.Adam(parameters,lr=config['lr'])
    retention=None
    if config['method']=='ewc_proxy':retention=torch.load(OUT/'fisher'/f'{scene}.pt',map_location='cpu',weights_only=True)
    curves=[dict(epoch=0,lr=config['lr'],train_data_loss=np.nan,train_keep_loss=np.nan,validation_mae_m=score,
        worst_source_p5_change_m=0.,P5_feasible=True)]
    start_time=time.perf_counter();cache_diff=0.
    print('FIT',seed,scene,config['id'],'under',under,'params',sum(p.numel() for p in parameters),flush=True)
    for epoch in range(1,EPOCHS+1):
        lr=config['lr']*(.1+.9*.5*(1+np.cos(np.pi*(epoch-1)/(EPOCHS-1))))
        optimizer.param_groups[0]['lr']=lr;model.train();order=rng.permutation(len(tr));total_data=0.;total_keep=0.
        for start in range(0,len(order),BATCH):
            local=order[start:start+BATCH];ids=tr[local];optimizer.zero_grad(set_to_none=True)
            if isinstance(model,AdapterMLP):
                hh=torch.from_numpy(np.array(hidden[ids],copy=True));pred=model.from_hidden(hh)
                if epoch==1 and start==0:
                    with torch.no_grad():
                        full=model(torch.from_numpy(np.array(x[ids],copy=True)))
                        cache_diff=float(abs(full-pred.detach()).max());assert cache_diff<3e-4
            else:pred=model(torch.from_numpy(np.array(x[ids],copy=True)))
            new_loss=prior.asymmetric_mse(pred,yy[local],ww[local],under)
            keep=torch.zeros((),dtype=pred.dtype)
            if config['method']=='ewc_proxy':keep=config['strength']*ewc_penalty(model,retention['anchor'],retention['fisher'])
            if config['method']=='lwf':
                old=torch.from_numpy(np.array(teacher[ids],copy=True));keep=config['strength']*torch.mean(ww[local]*((pred-old)/30).square())
            loss=new_loss+keep;assert torch.isfinite(loss)
            loss.backward();optimizer.step();total_data+=float(new_loss.detach())*len(local);total_keep+=float(keep.detach())*len(local)
        vp=data.predict_model(model,x,va);ok,worst,_=gate_p5(vp,truth[va],vref,groups)
        score=data.validation_metrics(vp,truth[va],si[va],sources)[0]
        if score<raw[0]-1e-6:raw=(score,epoch,copy.deepcopy(model.state_dict()))
        if ok:
            accepted+=1
            if score<gated[0]-1e-6:gated=(score,epoch,copy.deepcopy(model.state_dict()))
        curves.append(dict(epoch=epoch,lr=lr,train_data_loss=total_data/len(tr),train_keep_loss=total_keep/len(tr),
            validation_mae_m=score,worst_source_p5_change_m=worst,P5_feasible=ok))
        pd.DataFrame(curves).to_csv(folder/'learning_curve.csv',index=False)
        print('EPOCH',seed,scene,config['id'],under,epoch,'val',round(score,5),'P5',round(worst,5),ok,
            'seconds',round(time.perf_counter()-start_time,1),flush=True)
    final=model.state_dict();changed=[];frozen_changed=[];named=dict(model.named_parameters())
    for name,value in original.items():
        delta=float(abs(final[name]-value).max())
        if name in named and named[name].requires_grad:
            if delta>0:changed.append(name)
        elif delta>0:frozen_changed.append(name)
    assert changed and not frozen_changed
    protocol=dict(version=VERSION,dataset_version=data.VERSION,config=config,seed=seed,held_scene=scene,
        under_extra=under,underestimation_squared_weight=1+under,epochs=EPOCHS,batch_size=BATCH,
        raw_epoch=raw[1],raw_source_mae=raw[0],gated_epoch=gated[1],gated_source_mae=gated[0],P5_feasible_epochs=accepted,
        train_n=len(tr),validation_n=len(va),test_n=len(te),train_truth_max_m=float(truth[tr].max()),
        trainable_parameters=sum(p.numel() for p in parameters),original_meter_parameterization=True,
        trainable_parameter_tensors_changed=changed,frozen_parameters_and_buffers_unchanged=True,
        adapter_cache_max_difference_m=cache_diff,path_fusion=False,shared_model_all_paths=True,
        source_only_selection=True,held_scene_used_for_fitting_or_selection=False,
        EWC_is_old_task_Fisher=False if config['method']=='ewc_proxy' else None)
    predictions={}
    for kind,snapshot in [('raw',raw),('gated',gated)]:
        model.load_state_dict(snapshot[2]);vp=data.predict_model(model,x,va);tp=data.predict_model(model,x,te)
        ok,worst,details=gate_p5(vp,truth[va],vref,groups)
        if kind=='gated':assert ok
        exported=model.merged() if isinstance(model,LoRAMLP) and kind=='raw' else model
        check=te[np.unique(np.linspace(0,len(te)-1,128).astype(int))]
        error=float(abs(data.predict_model(model,x,check)-data.predict_model(exported,x,check)).max());assert error<3e-4
        saved=dict(protocol,checkpoint_epoch=snapshot[1],checkpoint_kind=kind,merged_lora=isinstance(model,LoRAMLP) and kind=='raw',
            source_P5_passed=ok,worst_source_p5_change_m=worst,merge_max_error_m=error)
        torch.save(dict(state_dict=exported.state_dict(),protocol=saved),folder/f'{kind}_model_meters.pt')
        if isinstance(model,LoRAMLP):
            torch.save(dict(state_dict=model.state_dict(),protocol=dict(saved,merged_lora=False,unmerged_training_state=True)),
                folder/f'{kind}_unmerged_training_state.pt')
        write_json(folder/f'{kind}_source_p5.json',details);predictions[kind+'_m']=tp
    np.savez_compressed(folder/'predictions.npz',sample_id=te,**predictions)
    write_json(folder/'protocol.json',protocol)
    print('COMPLETE',seed,scene,config['id'],under,'raw',raw[1],'gated',gated[1],flush=True)


def old_full_options(seed,scene,under):
    options=[]
    for lr in prior.LRS:
        folder=prior.run_folder(seed,scene,lr,under)
        p=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))
        options.append(dict(method='full_under5' if under else 'full_plain',config=dict(id=f'full_lr{lr:g}',method='full',lr=lr),
            score=p['raw_best_validation_mae_m'],epoch=p['raw_best_epoch'],folder=str(folder),kind='raw_best',old=True))
    return options


def source_policy_choice(seed,scene):
    choices=[]
    for config in ALL_CONFIGS:
        folder=run_folder(seed,scene,config);p=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))
        choices.append(dict(method=config['method'],config=config,score=p['raw_source_mae'],epoch=p['raw_epoch'],folder=str(folder),kind='raw',old=False))
    choices.extend(old_full_options(seed,scene,4.))
    return min(choices,key=lambda r:r['score'])


def train_seed(seed):
    sources,x,coords,truth=data.load_data();teacher=np.load(OUT/'teacher_m.npy',mmap_mode='r');hidden=np.load(OUT/'hidden24.npy',mmap_mode='r')
    for scene in data.SCENES:
        for config in ALL_CONFIGS:train_one(sources,x,coords,truth,teacher,hidden,seed,scene,config)
        choice=source_policy_choice(seed,scene)
        # Every raw candidate includes epoch0, so the winning score cannot be
        # worse than frozen. A tie at epoch0 explicitly selects frozen.
        if choice['epoch']==0:choice=dict(choice,method='frozen',config=dict(id='frozen',method='full'),old=True)
        write_json(OUT/f'seed_{seed}'/f'leave_{scene}'/'source_policy.json',choice)
        if not choice['old']:train_one(sources,x,coords,truth,teacher,hidden,seed,scene,choice['config'],under=0.)
    write_json(OUT/f'seed_{seed}'/'complete.json',dict(seed=seed,version=VERSION))


def ensure_extended_grid():
    """Finish the source-scale amendment after the original workers exit.

    Original running workers have the initial grid in memory. No directories
    are written concurrently: this is called by their parent only after both
    have returned. New workers skip completed trials and update source policy.
    """
    import subprocess
    seeds=[s for s in SEEDS if any(not (run_folder(s,scene,c)/'protocol.json').exists() for scene in data.SCENES for c in ALL_CONFIGS)]
    if not seeds:return
    print('EXTENDED_SOURCE_GRID',seeds,flush=True);processes=[];streams=[]
    try:
        for seed in seeds:
            stream=(BASE/f'tmp/ti_incremental_seed{seed}.log').open('a',encoding='utf-8');streams.append(stream)
            processes.append(subprocess.Popen([sys.executable,'-u','-X','utf8',str(Path(__file__).resolve()),'--stage','train','--seed',str(seed)],
                cwd=BASE,stdout=stream,stderr=subprocess.STDOUT,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0)))
        while any(p.poll() is None for p in processes):
            if any(p.poll() not in (None,0) for p in processes):raise RuntimeError('Extended source-grid training failed')
            time.sleep(2)
        assert all(p.returncode==0 for p in processes)
    finally:
        for stream in streams:stream.close()


def fisher_diagnostics():
    rows=[]
    for scene in data.SCENES:
        obj=torch.load(OUT/'fisher'/f'{scene}.pt',map_location='cpu',weights_only=True)
        for name,f in obj['fisher'].items():
            a=f.numpy().reshape(-1)
            rows.append(dict(held_scene=scene,parameter=name,n=len(a),trace=float(a.sum()),maximum=float(a.max()),
                zero_pct=float(100*np.mean(a==0)),samples=obj['protocol']['samples'],original_old_task_Fisher=False))
    pd.DataFrame(rows).to_csv(OUT/'fisher_diagnostics.csv',index=False,encoding='utf-8-sig')


def export_selection(choice,seed,scene,label):
    dest=OUT/f'seed_{seed}'/f'leave_{scene}'/f'{label}_selected.pt'
    if choice['folder'] is None:
        obj=dict(state_dict=canonical_model().state_dict(),protocol=dict(config=dict(method='full',id='frozen'),merged_lora=False,
            frozen_fallback=True,checkpoint_epoch=0))
    else:obj=torch.load(Path(choice['folder'])/f"{choice['kind']}_model_meters.pt",map_location='cpu',weights_only=True)
    obj['protocol']=dict(obj['protocol'],version=VERSION,dataset_version=data.VERSION,config=choice['config'],
        release_policy=label,seed=seed,held_scene=scene,path_fusion=False,shared_model_all_paths=True,source_only_selection=True)
    torch.save(obj,dest)
    return str(dest)


def scopes_for(scene,ids,sources,coords,truth):
    scopes=[('ALL',np.ones(len(ids),bool)),('true_gt15m',truth[ids]>15),('true_le15m',truth[ids]<=15)]
    if scene=='实车':
        cond=sources.condition.to_numpy()[coords['source_index'][ids]]
        scopes.extend([('LOS',cond=='LOS'),('NLOS',cond=='NLOS')])
    return scopes


def summarize():
    ensure_extended_grid()
    fisher_diagnostics()
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    plt.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','DejaVu Sans'];plt.rcParams['axes.unicode_minus']=False
    sources,x,coords,truth=data.load_data();si=coords['source_index'];scenes=sources.scene.to_numpy()[si]
    records=[];candidate_records=[];selections=[];checks=[];anchor_rows=[]
    for seed in SEEDS:
        methods=['frozen','full_plain','full_under5','source_policy','source_policy_no_under',
            *FAMILIES,*[m+'_P5' for m in FAMILIES]]
        oof={m:np.full(len(x),np.nan,np.float32) for m in methods}
        for scene in data.SCENES:
            _,parts=prior.split_rows(sources,coords,scene);va,te=parts['validation'],parts['test'];vref,tref=prior.baseline(scene,va,te)
            frozen_score=data.validation_metrics(vref,truth[va],si[va],sources)[0]
            frozen=dict(method='frozen',config=dict(method='full',id='frozen'),score=frozen_score,epoch=0,folder=None,kind='raw',old=False,pred=tref)
            oof['frozen'][te]=tref;groups=validation_groups(sources,coords,truth,va);options={f:{k:[frozen.copy()] for k in ['raw','gated']} for f in FAMILIES}
            for config in ALL_CONFIGS:
                folder=run_folder(seed,scene,config);p=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))
                with np.load(folder/'predictions.npz') as a:
                    np.testing.assert_array_equal(a['sample_id'],te);preds={k:a[k+'_m'] for k in ['raw','gated']}
                for kind in preds:
                    checkpoint=folder/f'{kind}_model_meters.pt';model,protocol=load_incremental(checkpoint)
                    local=np.unique(np.linspace(0,len(te)-1,128).astype(int));delta=float(abs(data.predict_model(model,x,te[local])-preds[kind][local]).max());assert delta<3e-4
                    if config['method']=='lora':
                        # The initial worker revision wrote export metadata to
                        # its unmerged audit file. Correct that label only;
                        # trained tensors and inference exports are unchanged.
                        audit_file=folder/f'{kind}_unmerged_training_state.pt'
                        audit=torch.load(audit_file,map_location='cpu',weights_only=True)
                        audit['protocol']=dict(audit['protocol'],merged_lora=False,unmerged_training_state=True)
                        torch.save(audit,audit_file)
                        unmerged,_=load_incremental(audit_file)
                        np.testing.assert_allclose(data.predict_model(unmerged,x,te[local]),data.predict_model(model,x,te[local]),atol=3e-4,rtol=1e-6)
                    if kind=='gated':
                        vp=data.predict_model(model,x,va);ok,worst,_=gate_p5(vp,truth[va],vref,groups);assert ok
                    else:worst=protocol['worst_source_p5_change_m']
                    checks.append(dict(seed=seed,scene=scene,config=config['id'],kind=kind,reload_error_m=delta,
                        source_P5_change_m=worst,frozen_unchanged=p['frozen_parameters_and_buffers_unchanged'],trainable_parameters=p['trainable_parameters']))
                    options[config['method']][kind].append(dict(method=config['method'],config=config,score=p[kind+'_source_mae'],
                        epoch=p[kind+'_epoch'],folder=str(folder),kind=kind,old=False,pred=preds[kind]))
                for scope,mask in scopes_for(scene,te,sources,coords,truth):
                    if mask.any():candidate_records.append(dict(seed=seed,scene=scene,scope=scope,config=config['id'],family=config['method'],
                        trainable_parameters=p['trainable_parameters'],source_validation_mae=p['raw_source_mae'],**data.metrics(preds['raw'][mask],truth[te][mask])))
            all_primary=[frozen.copy()]
            for family in FAMILIES:
                for kind in ['raw','gated']:
                    choice=min(options[family][kind],key=lambda a:a['score'])
                    label=family+('_P5' if kind=='gated' else '')
                    oof[label][te]=choice['pred'];checkpoint=export_selection(choice,seed,scene,label)
                    selections.append(dict(seed=seed,scene=scene,method=label,config=choice['config']['id'],lr=choice['config'].get('lr',0.),
                        epoch=choice['epoch'],source_mae=choice['score'],frozen_source_mae=frozen_score,checkpoint=checkpoint))
                    if kind=='raw':all_primary.append(choice)
            for under,label in [(0.,'full_plain'),(4.,'full_under5')]:
                old_options=old_full_options(seed,scene,under)
                for opt in old_options:
                    with np.load(Path(opt['folder'])/'predictions.npz') as a:
                        np.testing.assert_array_equal(a['sample_id'],te);opt['pred']=a['raw_best_m']
                choice=min([frozen.copy(),*old_options],key=lambda a:a['score']);oof[label][te]=choice['pred']
                if under:all_primary.append(choice)
            policy=min(all_primary,key=lambda a:a['score'])
            oof['source_policy'][te]=policy['pred'];export_selection(policy,seed,scene,'source_policy')
            choices_saved=json.loads((OUT/f'seed_{seed}'/f'leave_{scene}'/'source_policy.json').read_text(encoding='utf-8'))
            assert abs(policy['score']-choices_saved['score'])<1e-6
            if policy['folder'] is None:
                no_under=frozen.copy()
            elif policy['old']:
                no_under=next(q for q in old_full_options(seed,scene,0.) if q['config']['lr']==policy['config']['lr'])
                with np.load(Path(no_under['folder'])/'predictions.npz') as a:no_under['pred']=a['raw_best_m']
            else:
                folder=run_folder(seed,scene,policy['config'],0.);p=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))
                with np.load(folder/'predictions.npz') as a:
                    np.testing.assert_array_equal(a['sample_id'],te);pred=a['raw_m']
                no_under=dict(policy,folder=str(folder),score=p['raw_source_mae'],epoch=p['raw_epoch'],kind='raw',pred=pred)
            oof['source_policy_no_under'][te]=no_under['pred'];export_selection(no_under,seed,scene,'source_policy_no_under')
            for label,ch in [('source_policy',policy),('source_policy_no_under',no_under)]:
                selections.append(dict(seed=seed,scene=scene,method=label,config=ch['config']['id'],lr=ch['config'].get('lr',0.),
                    epoch=ch['epoch'],source_mae=ch['score'],frozen_source_mae=frozen_score,
                    checkpoint=str(OUT/f'seed_{seed}'/f'leave_{scene}'/f'{label}_selected.pt')))
        for method,pred in oof.items():
            assert np.isfinite(pred).all()
            for scene in ['ALL',*data.SCENES]:
                ids=np.arange(len(x)) if scene=='ALL' else np.flatnonzero(scenes==scene)
                for scope,mask in scopes_for(scene,ids,sources,coords,truth):
                    if mask.any():
                        ix=ids[mask];m=data.metrics(pred[ix],truth[ix]);reference=oof['frozen'][ix]
                        records.append(dict(seed=seed,scene=scene,scope=scope,method=method,
                            teacher_disagreement_mae_m=float(abs(pred[ix]-reference).mean()),down_from_teacher_over1m_pct=float(100*np.mean(pred[ix]<reference-1)),**m))
            car=np.flatnonzero(scenes=='实车')
            for anchor in sources[sources.scene.eq('实车')].anchor.unique():
                for condition in ['ALL','LOS','NLOS']:
                    mask=sources.anchor.to_numpy()[si[car]]==anchor
                    if condition!='ALL':mask&=sources.condition.to_numpy()[si[car]]==condition
                    ix=car[mask];anchor_rows.append(dict(seed=seed,anchor=anchor,condition=condition,method=method,**data.metrics(pred[ix],truth[ix])))
        np.savez_compressed(OUT/f'out_of_scene_seed_{seed}.npz',**{k+'_m':v for k,v in oof.items()})
    fields=['mae_m','error_p5_m','abs_error_p5_m','cep95_m','bias_m','under3_pct','over3_pct','teacher_disagreement_mae_m','down_from_teacher_over1m_pct']
    each=pd.DataFrame(records);each.to_csv(OUT/'metrics_each_seed.csv',index=False,encoding='utf-8-sig')
    avg=each.groupby(['scene','scope','method']).agg(n=('n','first'),**{f'{k}_{s}':(k,s) for k in fields for s in ['mean','std']}).reset_index()
    avg.to_csv(OUT/'metrics_two_seeds.csv',index=False,encoding='utf-8-sig')
    macro=each[each.scene.ne('ALL')&each.scope.eq('ALL')].groupby(['seed','method']).agg(scene_macro_mae_m=('mae_m','mean'),
        worst_scene_mae_m=('mae_m','max'),worst_scene_error_p5_m=('error_p5_m','min')).reset_index()
    macro.groupby('method').agg(**{f'{k}_{s}':(k,s) for k in ['scene_macro_mae_m','worst_scene_mae_m','worst_scene_error_p5_m'] for s in ['mean','std']}).reset_index().to_csv(OUT/'scene_macro_two_seeds.csv',index=False)
    candidates=pd.DataFrame(candidate_records);candidates.to_csv(OUT/'candidate_metrics_each_seed.csv',index=False,encoding='utf-8-sig')
    candidates[candidates.scope.eq('ALL')].groupby(['seed','config','family']).mae_m.mean().rename('scene_macro_mae_m').reset_index().groupby(['config','family']).scene_macro_mae_m.agg(['mean','std']).reset_index().to_csv(OUT/'candidate_macro_two_seeds.csv',index=False)
    anchors=pd.DataFrame(anchor_rows);anchors.groupby(['anchor','condition','method']).agg(n=('n','first'),**{f'{k}_{s}':(k,s) for k in fields[:7] for s in ['mean','std']}).reset_index().to_csv(OUT/'car_anchor_path_pooled_two_seeds.csv',index=False)
    # Identity is used only to stratify evaluation, never as a network feature.
    path_rows=[]
    for seed in SEEDS:
        with np.load(OUT/f'out_of_scene_seed_{seed}.npz') as a:
            car=np.flatnonzero(scenes=='实车')
            for key in a.files:
                pred=a[key]
                for anchor in sources[sources.scene.eq('实车')].anchor.unique():
                    for path in range(4):
                        ids=car[(sources.anchor.to_numpy()[si[car]]==anchor)&(coords['path'][car]==path)]
                        path_rows.append(dict(seed=seed,anchor=anchor,path=path,method=key[:-2],**data.metrics(pred[ids],truth[ids])))
    pd.DataFrame(path_rows).groupby(['anchor','path','method']).agg(n=('n','first'),**{f'{k}_{s}':(k,s) for k in fields[:7] for s in ['mean','std']}).reset_index().to_csv(OUT/'car_anchor_each_path_two_seeds.csv',index=False)
    pd.DataFrame(selections).to_csv(OUT/'source_only_selection.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(checks).to_csv(OUT/'model_reload_checks.csv',index=False)
    # End-to-end IQ replay: each selected method/P5 policy, scene and seed.
    iq_checks=[]
    for scene in data.SCENES:
        r=next(sources[sources.scene.eq(scene)].itertuples())
        if r.cache_file:
            with np.load(r.cache_file) as c:q=c['iq'][:8].astype(np.float64);z=q[:,:,0]+1j*q[:,:,1]
        else:
            rows,_=data._parse_log(Path(r.file),complete_four_paths=False);z=np.stack([a[5] for a in rows[:8]])
        ids=np.arange(r.sample_start,r.sample_start+len(z))
        for seed in SEEDS:
            for label in [*FAMILIES,*[m+'_P5' for m in FAMILIES],'source_policy','source_policy_no_under']:
                checkpoint=OUT/f'seed_{seed}'/f'leave_{scene}'/f'{label}_selected.pt'
                p=predict_incremental_iq(z,checkpoint);model,_=load_incremental(checkpoint)
                q=data.predict_model(model,x,ids);error=float(abs(p-q).max());assert error<3e-4
                iq_checks.append(dict(seed=seed,scene=scene,method=label,error_m=error))
    pd.DataFrame(iq_checks).to_csv(OUT/'raw_iq_replay.csv',index=False)
    write_json(OUT/'verification.json',dict(checkpoints_reloaded=len(checks),max_reload_error_m=max(r['reload_error_m'] for r in checks),
        raw_IQ_replays=len(iq_checks),max_raw_IQ_error_m=max(r['error_m'] for r in iq_checks),
        original_frozen_parameters_and_buffers_verified=True,source_scene_session_frame_isolation=True,
        EWC_original_old_task_Fisher_available=False,source_only_config_and_epoch_selection=True,
        all_primary_trials=len(ALL_CONFIGS)*len(SEEDS)*len(data.SCENES),path_fusion=False,shared_model_all_paths=True,
        unknown_scene_P5_guaranteed=False))
    fig,axes=plt.subplots(2,2,figsize=(12,7),constrained_layout=True)
    table=pd.DataFrame(selections)
    for ax,scene in zip(axes.flat,data.SCENES):
        for family,color in zip(FAMILIES,['#2563eb','#dc2626','#059669','#9333ea']):
            for seed,ls in zip(SEEDS,['-','--']):
                r=table[table.seed.eq(seed)&table.scene.eq(scene)&table.method.eq(family)].iloc[0]
                if r.epoch==0:continue
                cfg=next(c for c in ALL_CONFIGS if c['id']==r.config)
                curve=pd.read_csv(run_folder(seed,scene,cfg)/'learning_curve.csv')
                ax.plot(curve.epoch,curve.validation_mae_m,color=color,ls=ls,label=f'{family}, {r.config}, {seed}')
        ax.set_title(scene);ax.set_xlabel('Epoch');ax.set_ylabel('Source validation balanced MAE /m');ax.grid(alpha=.2);ax.legend(fontsize=6)
    fig.savefig(OUT/'source_validation_curves.png',dpi=150);plt.close(fig)
    write_report(avg,macro,table)
    print('SUMMARY\n'+avg[avg.scene.eq('实车')&avg.scope.eq('ALL')].to_string(index=False),flush=True)


def result_overview(avg,macro,selections):
    primary=['frozen','full_plain','full_under5',*FAMILIES]
    scores=macro[macro.method.isin(primary)].groupby('method').scene_macro_mae_m.mean()
    car=avg[avg.scene.eq('实车')&avg.scope.eq('ALL')&avg.method.isin(primary)]
    best=car.loc[car.mae_m_mean.idxmin()]
    far=avg[avg.scene.eq('实车')&avg.scope.eq('true_gt15m')&avg.method.eq(best.method)].iloc[0]
    ref=car[car.method.eq('full_under5')].iloc[0]
    gated=selections[selections.method.str.endswith('_P5')]
    overview=(f"按预先固定的来源验证选参流程，四场景等权MAE最低为{scores.idxmin()}：{scores.min():.4f}m；"
        f"实车MAE最低为{best.method}：{best.mae_m_mean:.4f}m，error P5 {best.error_p5_m_mean:.4f}m，CEP95 {best.cep95_m_mean:.4f}m。"
        "这是固定流程的留出结果排名，不依据该排名再次调参；不同指标未必由同一方法最优。\n\n"
        f"该实车MAE最低流程在>15m上的P5为{far.error_p5_m_mean:.4f}m，低估>3m比例{far.under3_pct_mean:.2f}%。"
        f"此前全量5倍惩罚基线实车MAE {ref.mae_m_mean:.4f}m、P5 {ref.error_p5_m_mean:.4f}m。"
        "需结合后续远距和LOS/NLOS表判断MAE收益是否伴随低估尾部退化。\n\n"
        f"来源分组P5准入共{len(gated)}次选择，其中{int((gated.epoch>0).sum())}次接受非零训练轮次，其余实际回退冻结TI。"
        "接受来源准入不构成未知场景P5保证；回退结果不能计为训练收益。EWC仅为来源输入Fisher代理，非TI旧任务原始Fisher。\n\n")
    def metric(scope,method):
        return avg[avg.scene.eq('实车')&avg.scope.eq(scope)&avg.method.eq(method)].iloc[0]
    a=metric('true_gt15m','adapter');f=metric('true_gt15m','frozen');l=metric('ALL','lwf');lf=metric('true_gt15m','lwf')
    safe=metric('ALL','adapter_P5');control=metric('ALL','source_policy_no_under')
    overview+=(f"MAE优先与防低估的结论不同：Adapter的远距低估>3m比例为{a.under3_pct_mean:.2f}%，冻结TI为{f.under3_pct_mean:.2f}%；"
        f"远距P5为{a.error_p5_m_mean:.4f}m，冻结TI为{f.error_p5_m_mean:.4f}m。"
        f"LwF来源MAE选择版本整体MAE {l.mae_m_mean:.4f}m、P5 {l.error_p5_m_mean:.4f}m，是较保守的折衷，"
        f"但远距P5仍为{lf.error_p5_m_mean:.4f}m，不能称为所有子集P5不退化。\n\n"
        f"通过来源P5准入的早期Adapter在实车MAE为{safe.mae_m_mean:.4f}m、P5 {safe.error_p5_m_mean:.4f}m；"
        "它保住了本次实车P5，但没有带来MAE收益。源域准入和目标域表现必须分别判断。\n\n"
        f"匹配方法/配置的无低估惩罚消融，实车MAE {control.mae_m_mean:.4f}m、P5 {control.error_p5_m_mean:.4f}m，"
        f"P5两种子标准差{control.error_p5_m_std:.4f}m。两次训练不足以证明低估惩罚在域外必然改善P5。"
        "场景变化、未覆盖距离与参数漂移同时存在，本实验不能将它们的影响完全分开归因。\n\n")
    return overview


def write_report(avg,macro,selections):
    report='# 单path增量微调：EWC代理、LwF、LoRA、Adapter四场景留一\n\n'
    report+=result_overview(avg,macro,selections)
    report+='沿用928份有可靠静态标签日志、1,690,110条path；实车116,005条，LOS59,322/NLOS56,683，3D真值。四场景整场景留一，各折来源训练/验证按原会话划分；path独立输入，共享权重，身份/锚点/场景不作为特征，未做多path融合。该队列已用于开发，不是新盲测。\n\n'
    report+='固定原TI时域窗→2MHz/L12前向平滑协方差→156维上三角L2→原输入仿射。四种方法从同一TI米制权重开始，不使用历史错误的FC4除30再forward乘30参数化。主实验新任务损失统一为mean(w*((e/30)^2+4*relu(-e/30)^2))，低估平方代价5倍。Adam无weight_decay，batch4096，12全量epoch，余弦LR至初始1/10，两个种子。来源场景/标称距离/文件等权。\n\n'
    report+='## 方法与可比性\n\n'
    report+='EWC代理：更新全部3265参数，加λ/2*sum(F*(theta-theta0)^2)。没有TI旧训练数据或旧Fisher，故F是每折来源训练输入分布上的原TI参数重要性代理，不能声称还原旧任务Fisher或测量了TI旧任务遗忘。假设归一化距离f/30服从单位方差Gaussian，F=E[(d(f/30)/dtheta)^2]；逐样本Jacobian平方，与批均值梯度平方不同，不用新数据标签或伪标签残差。每来源训练文件最多32条，按场景/距离/文件等权，验证与留出均不参与。λ=1/10初查保护项仅约数据项0.02/0.2%，在未查看留出误差前补λ1000/10000，记录在config_grid_amendment.json，原计划和弱保护试验保留。F与输出单位和噪声方差耦合，λ数值不能直接跨不同F归一化实现比较；逐层trace及零重要性比例见fisher_diagnostics.csv。\n\n'
    report+='LwF：更新全部3265参数，加λ*mean(w*((student-original_TI)/30)^2)，λ1/10，只用来源训练输入。teacher固定、无梯度。该约束不覆盖TI未知旧输入或实车留出折未见的远距分布。\n\n'
    report+='LoRA：4个FC矩阵均注入BA，alpha/r=1，rank2/4（末层输出1维所以有效rank1），原矩阵及bias冻结，可训练577/1129参数。A随机、B零，训练前严格等于原TI，LR3e-5。MAE选择版本合并成原3265参数架构，数值差核对后导出；P5选择版本保留必要的未合并结构以避免分位数门控受合并舍入影响。\n\n'
    report+='Adapter：固定全部原网络，在第三层24维ReLU后接h+up(ReLU(down(h)))，瓶颈4/8，可训练220/416参数，LR3e-5。up全零初始化，训练前严格等于原TI。训练可缓存固定24维hidden，但验证、测试与原始IQ重放使用完整前向；原骨干权重及仿射逐一检查不变。\n\n'
    report+='初始函数步长审计见effective_step_audit.csv：仅使用实车留出折的4096条来源训练样本，全量lr3e-6平均预测步长0.548mm；LoRA/Adapter lr3e-5平均0.306～0.713mm，属于同一量级，不能按名义LR直接推断参数化后的实际距离步长。该检查不代表完整学习率搜索，也不保证后续累计漂移相同。\n\n'
    report+='每个方法在各折/种子分别按来源验证平衡MAE选配置、轮次（含epoch0）；_P5另要求来源各场景/距离段/path的有符号P5不低于同组冻结TI，数值容差1e-6m，无合格改善回退。source_policy仅按来源验证从4方法、全量微调5倍惩罚与冻结TI中选择；source_policy_no_under对它做匹配配置的无低估惩罚消融。全量基线复用前轮相同数据/划分/12轮的正确米制结果。没有按留出误差回选配置或部署模型。\n\n'
    report+='## 每个留出场景\n\n|留出场景|方法|N|MAE|error P5|CEP95|\n|---|---|---|---|---|---|\n'
    primary=['frozen','full_plain','full_under5',*FAMILIES,'source_policy']
    for r in avg[avg.scene.ne('ALL')&avg.scope.eq('ALL')&avg.method.isin(primary)].itertuples():
        report+=f'|{r.scene}|{r.method}|{r.n}|{r.mae_m_mean:.4f}|{r.error_p5_m_mean:.4f}|{r.cep95_m_mean:.4f}|\n'
    report+='\n## 场景等权MAE\n\n此项先对4个留出场景的MAE等权平均，再对两个种子平均，避免数据较多的场景主导。不能把分位数按场景平均。\n\n|方法|场景等权MAE|\n|---|---|\n'
    for method,g in macro.groupby('method'):report+=f'|{method}|{g.scene_macro_mae_m.mean():.4f}|\n'
    report+='\n## 固定网格配置在实车上的诊断\n\n以下不按实车误差回选配置，完整展示已固定的网格。来源验证最优不等于实车最优，尤其关注强保护与弱保护的取舍。\n\n|配置|来源验证MAE|实车MAE|实车error P5|实车CEP95|>15m error P5|\n|---|---|---|---|---|---|\n'
    cand=pd.read_csv(OUT/'candidate_metrics_each_seed.csv')
    for config in ALL_CONFIGS:
        main=cand[cand.scene.eq('实车')&cand.scope.eq('ALL')&cand.config.eq(config['id'])]
        far=cand[cand.scene.eq('实车')&cand.scope.eq('true_gt15m')&cand.config.eq(config['id'])]
        report+=f"|{config['id']}|{main.source_validation_mae.mean():.4f}|{main.mae_m.mean():.4f}|{main.error_p5_m.mean():.4f}|{main.cep95_m.mean():.4f}|{far.error_p5_m.mean():.4f}|\n"
    for scope,title in [('ALL','实车全部单path'),('true_gt15m','实车真值>15m'),('LOS','实车LOS'),('NLOS','实车NLOS')]:
        report+=f'\n## {title}\n\n|方法|N|MAE|error P5|绝对P5|CEP95|低估>3m%|\n|---|---|---|---|---|---|---|\n'
        for r in avg[avg.scene.eq('实车')&avg.scope.eq(scope)].itertuples():
            report+=f'|{r.method}|{r.n}|{r.mae_m_mean:.4f}|{r.error_p5_m_mean:.4f}|{r.abs_error_p5_m_mean:.4f}|{r.cep95_m_mean:.4f}|{r.under3_pct_mean:.2f}|\n'
    report+='\n单位米；e=预测−真值，error P5=Q05(e)，绝对P5=Q05(|e|)，CEP95=Q95(|e|)。两种子各自算指标再平均，N不重复。实车留出时来源真值仅1～15m，远距仍属于外推，来源P5合格无未知场景保证。旧任务数据不可得，本实验衡量我方留出数据的泛化，不是完整顺序多任务遗忘基准。主表不扣0.94m、不截零；此前固定校准冻结实车对照MAE4.0913、P5−2.6282、CEP95 10.8322m。\n\n'
    report+='全部配置的结果见candidate_metrics_each_seed.csv；配置场景等权MAE见candidate_macro_two_seeds.csv。实际选择和回退见source_only_selection.csv；每锚点/path见car_anchor_each_path_two_seeds.csv；teacher_disagreement记录我方输入上的预测变化，不能当作TI旧任务精度。实际模型重加载和IQ重放检查数量及最大误差见verification.json。\n\n'
    report+='推理：ti_incremental_mlp.predict_incremental_iq(combined_calibrated_IQ80, checkpoint)，每条path一个米值。每折<family>_selected.pt为来源MAE选择，<family>_P5_selected.pt为来源P5准入，可能冻结回退。source_policy_selected.pt为来源选择流程的模型。\n\n![来源验证曲线](source_validation_curves.png)\n\n'
    report+='方法原文：[EWC](https://arxiv.org/abs/1612.00796)、[LwF](https://arxiv.org/abs/1606.09282)、[LoRA](https://arxiv.org/abs/2106.09685)、[Adapter](https://arxiv.org/abs/1902.00751)。Gaussian回归Fisher、TI模型适配和实验超参数为本实验实现选择，不声称原论文或TI原训练配方。\n'
    (OUT/'report.md').write_text(report,encoding='utf-8')


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--stage',choices=['prepare','train','report','all'],default='all')
    parser.add_argument('--seed',type=int,choices=SEEDS,action='append');args=parser.parse_args()
    sys.stdout.reconfigure(encoding='utf-8');torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    if args.stage in ['prepare','all']:prepare()
    if args.stage in ['train','all']:
        for seed in args.seed or SEEDS:train_seed(seed)
    if args.stage in ['report','all']:summarize()


if __name__=='__main__':
    with threadpool_limits(limits=1):main()
