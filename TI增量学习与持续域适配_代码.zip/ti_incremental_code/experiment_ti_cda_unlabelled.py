"""Continual unlabeled calibration on sessions disjoint from final test.

All methods start from the same three-source full-FT checkpoint. Calibration
sessions arrive in blocks; their labels are not passed to the adaptation API.
CoTTA is an explicitly documented scalar-regression consistency adaptation.
"""
from pathlib import Path
import argparse,copy,json,re,sys,time
import numpy as np
import pandas as pd
import torch
from torch.nn import functional as F
from threadpoolctl import threadpool_limits

import experiment_ti_finetune_all_loso as data
import experiment_ti_full_under_loso as prior
from experiment_ti_fc3_bias_p5 import validation_groups,gate_p5
from audit_ti_finetune_implementation import canonical_model
from ti_time_window import preprocess_single_path
from ti_sdk_nn import covariance_features
from ti_continual_domain import DomainReplay,hidden24,coral_loss,DomainDiscriminator,reverse_gradient,ema_update,stochastic_restore

BASE=Path(__file__).resolve().parent
OUT=BASE/'outputs/ti_cda_20261119'
UOUT=OUT/'unlabelled'
SEEDS=(20261118,20261119)
SOURCE_MEMORY=4096
TARGET_MEMORY=2048
CAL_PER_FILE=256
BATCH=256
VERSION='continual_unlabelled_session_calibration_regression_v1'
CONFIGS=[dict(id='source_replay',method='source_replay',lr=3e-6,strength=0.)]+[
    dict(id=f'{method}_a{a:g}',method=method,lr=3e-6,strength=a)
    for method in ['CORAL','CORAL_replay','DANN_replay'] for a in (.01,.1)
]+[dict(id=f'CoTTA_reg_lr{lr:g}',method='CoTTA_reg',lr=lr,strength=1.) for lr in (3e-6,1e-5)]
STRONG_CONFIGS=[dict(id=f'{method}_budget10',method=method,lr=1e-4,
    strength=0. if method=='source_replay' else 1. if method=='CoTTA_reg' else .01,steps_per_batch=10)
    for method in ['source_replay','CORAL','CORAL_replay','DANN_replay','CoTTA_reg']]
ALL_CONFIGS=CONFIGS+STRONG_CONFIGS


def write_json(path,value):Path(path).write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')


def select_sessions(sources,held):
    rng=np.random.default_rng(20261119+97*data.SCENES.index(held));cal=[]
    for _,g in sources[sources.scene.eq(held)].groupby('stratum',sort=True):
        sessions=np.array(sorted(g.session_id.unique()));n=max(1,len(sessions)//4)
        assert len(sessions)>1;n=min(n,len(sessions)-1)
        cal.extend(rng.choice(sessions,n,replace=False).tolist())
    mask=sources.scene.eq(held);cal_source=np.flatnonzero(mask&sources.session_id.isin(cal));test_source=np.flatnonzero(mask&~sources.session_id.isin(cal))
    assert not set(sources.session_id.iloc[cal_source])&set(sources.session_id.iloc[test_source])
    return cal_source,test_source


def balanced_source_memory(sources,source_ids,seed):
    rng=np.random.default_rng(seed);pieces=[];seen=sources.iloc[source_ids]
    domains=sorted(seen.scene.unique());quota=SOURCE_MEMORY//len(domains)
    for domain in domains:
        group=seen[seen.scene.eq(domain)];base,extra=divmod(quota,len(group))
        plus=set(rng.choice(group.index.to_numpy(),extra,replace=False))
        for r in group.itertuples():
            n=min(int(r.n_paths),base+int(r.Index in plus))
            pieces.extend(rng.choice(np.arange(r.sample_start,r.sample_stop),n,replace=False).tolist())
    return np.array(pieces,np.int64)


def prepare():
    UOUT.mkdir(parents=True,exist_ok=True)
    plan=dict(version=VERSION,configs=CONFIGS,seeds=list(SEEDS),orders=['forward','reverse'],
        initial='same prior full_under5 source-only-selected model per held scene and seed',
        target_calibration='whole sessions, one quarter per stratum rounded down with minimum1; fixed split seed, independent final test sessions',
        target_numeric_labels_used_for_training_or_selection=False,calibration_paths_per_file=CAL_PER_FILE,
        source_memory=SOURCE_MEMORY,target_memory=TARGET_MEMORY,batch=BATCH,target_passes=1,
        continual_stream='known acquisition-session blocks, file order and reverse block order; not a continuous driving log',
        source_task_loss='same5x underestimation normalized meter MSE',
        alignment='24D hidden, fixed initial-source-memory mean/std for loss only; CORAL covariance loss or DANN gradient reversal',
        replay='source labelled memory, optional past-target arrival-prediction MSE; target labels absent',
        CoTTA_reg='2 noise-augmented teacher views, MSE/30 regression consistency, EMA0.999, stochastic source-weight restoration0.01; NO classification entropy/confidence gate/BN adaptation',
        weak_IQ_noise_rms_fraction=.01,epochs_or_configs_not_selected_with_target_labels=True,
        source_guard='final model vs adaptation-initial model on original source validation grouped P5, numerical tolerance1e-6; else initial model',
        held_domain_inputs_used=True,held_test_inputs_used_for_adaptation=False,
        strict_zero_shot_LOSO=False,regression_adaptations_not_original_classification_benchmark_reproduction=True)
    p=UOUT/'experiment_plan.json'
    if p.exists():assert json.loads(p.read_text(encoding='utf-8'))==plan
    else:write_json(p,plan)
    if (UOUT/'dataset_protocol.json').exists():return
    sources,x,coords,truth=data.load_data();si=coords['source_index'];all_cal=[];plans={}
    for held in data.SCENES:
        cal_sources,test_sources=select_sessions(sources,held);rng=np.random.default_rng(20261119+data.SCENES.index(held))
        ids=[]
        for k in cal_sources:
            r=sources.iloc[k];ids.extend(sorted(rng.choice(np.arange(r.sample_start,r.sample_stop),min(CAL_PER_FILE,int(r.n_paths)),replace=False).tolist()))
        ids=np.array(ids,np.int64);test=np.flatnonzero(np.isin(si,test_sources))
        ss,parts=prior.split_rows(sources,coords,held);memory=balanced_source_memory(sources,ss['train'],20261119+data.SCENES.index(held))
        assert not np.intersect1d(ids,test).size and not np.intersect1d(memory,np.r_[ids,test]).size
        assert set(si[memory])<=set(ss['train'])
        assert not set(coords['frame_id'][ids])&set(coords['frame_id'][test])
        virtual=sources.copy();virtual['n_paths']=np.bincount(si[memory],minlength=len(sources))
        weights=data.row_weights(virtual,np.unique(si[memory]),si[memory])
        block_names=sources.session_id.to_numpy()[si[ids]];names=list(dict.fromkeys(block_names.tolist()))
        # Boundaries follow acquisition sessions. Ordering uses file names, not
        # numeric reference distance and not target accuracy.
        names.sort(key=lambda name:min(sources.loc[sources.session_id.eq(name),'file']))
        blocks=np.array([names.index(name) for name in block_names],np.int32)
        np.savez_compressed(UOUT/f'partition_{held}.npz',calibration_ids=ids,test_ids=test,source_memory_ids=memory,
            source_memory_truth_m=truth[memory].astype(np.float32),source_memory_weights=weights,block=blocks)
        record=dict(calibration_source_ids=cal_sources.tolist(),test_source_ids=test_sources.tolist(),
            calibration_session_ids=sorted(sources.session_id.iloc[cal_sources].unique().tolist()),
            test_session_ids=sorted(sources.session_id.iloc[test_sources].unique().tolist()),
            block_names=names,n_calibration_paths=len(ids),n_test_paths=len(test),n_source_memory=len(memory),target_truth_loaded_by_adaptation=False)
        write_json(UOUT/f'partition_{held}.json',record);plans[held]=record;all_cal.extend(ids.tolist())
    pool=np.array(sorted(set(all_cal)),np.int64);np.save(UOUT/'augmented_global_ids.npy',pool)
    views=[np.lib.format.open_memmap(UOUT/f'weak{v}.partial.npy',mode='w+',dtype=np.float32,shape=(len(pool),156)) for v in (1,2)]
    source_audits=[];rng=np.random.default_rng(20261119);started=time.perf_counter()
    for k,r in enumerate(sources.itertuples()):
        pos=np.flatnonzero(si[pool]==r.source_index)
        if not len(pos):continue
        assert data.sha(r.file)==r.source_sha256
        if r.cache_file:
            assert data.sha(r.cache_file)==r.cache_sha256
            with np.load(r.cache_file) as c:q=c['iq'].astype(np.float64);z=q[:,:,0]+1j*q[:,:,1]
        else:
            rows,audit=data._parse_log(Path(r.file),complete_four_paths=False)
            assert audit['sha256']==r.source_sha256;z=np.stack([a[5] for a in rows])
        local=pool[pos]-r.sample_start;z=z[local]
        # Original frontend equivalence before noise; no truth-dependent view.
        original=covariance_features(preprocess_single_path(z));delta=float(abs(original-x[pool[pos]]).max());assert delta<3e-6
        rms=np.sqrt(np.mean(abs(z)**2,axis=1))
        for v,view in enumerate(views):
            noise=(rng.normal(size=z.shape)+1j*rng.normal(size=z.shape))*(.01/np.sqrt(2))*rms[:,None]
            view[pos]=covariance_features(preprocess_single_path(z+noise))
        source_audits.append(dict(source_index=r.source_index,n=len(pos),frontend_max_difference=delta))
        if len(source_audits)%24==0:print('CAL_AUGMENT',len(source_audits),'paths',sum(a['n'] for a in source_audits),'seconds',round(time.perf_counter()-started,1),flush=True)
    for v,view in enumerate(views,1):view.flush();del view
    del views
    for v in (1,2):(UOUT/f'weak{v}.partial.npy').replace(UOUT/f'weak{v}.npy')
    pd.DataFrame(source_audits).to_csv(UOUT/'calibration_IQ_audit.csv',index=False)
    write_json(UOUT/'dataset_protocol.json',dict(version=VERSION,n_calibration_paths=len(pool),partitions=plans,
        target_labels_not_saved_in_partitions=True,source_memory_labels_from_source_train_only=True,
        source_session_and_physical_frame_test_isolation=True,calibration_files_hash_verified=True,
        augmentation_never_uses_numeric_distance=True,weak_noise_fraction=.01,
        artifact_sha256={f:data.sha(UOUT/f) for f in ['augmented_global_ids.npy','weak1.npy','weak2.npy']}))
    print('CDA_PREPARED',len(pool),'calibration paths',flush=True)


def adapt_features(initial_state,config,source_x,source_y,source_w,target_x,weak1,weak2,blocks,seed,order_name):
    """Label firewall: target truth/test features are not arguments."""
    torch.manual_seed(seed);model=canonical_model();model.load_state_dict(initial_state)
    anchor={n:p.detach().clone() for n,p in model.named_parameters()};initial_buffers={n:b.clone() for n,b in model.named_buffers()}
    teacher=copy.deepcopy(model)
    for p in teacher.parameters():p.requires_grad_(False)
    optimizer=torch.optim.Adam(model.parameters(),lr=config['lr'])
    source_rng=np.random.default_rng(seed+1);replay_rng=np.random.default_rng(seed+2)
    restore_rng=torch.Generator().manual_seed(seed+3);memory=DomainReplay(TARGET_MEMORY,seed+4)
    discriminator=DomainDiscriminator();d_optimizer=torch.optim.Adam(discriminator.parameters(),lr=1e-3)
    if config['method']!='CoTTA_reg':
        with torch.no_grad():
            h=hidden24(model,torch.from_numpy(source_x));w=torch.from_numpy(source_w)
            mean=(h*w[:,None]).sum(0)/w.sum();variance=((h-mean).square()*w[:,None]).sum(0)/w.sum();scale=torch.sqrt(variance+1e-4)
    names=sorted(np.unique(blocks).tolist())
    if order_name=='reverse':names.reverse()
    repeats=config.get('steps_per_batch',1)
    total_steps=sum(int(np.ceil(np.sum(blocks==name)/BATCH)) for name in names)*repeats;steps=0;curves=[]
    for block in names:
        current=np.flatnonzero(blocks==block)
        for start in range(0,len(current),BATCH):
            ids=current[start:start+BATCH];tx=torch.from_numpy(np.array(target_x[ids],copy=True))
            for repeat in range(repeats):
                optimizer.zero_grad(set_to_none=True);d_optimizer.zero_grad(set_to_none=True)
                keep=torch.zeros(());alignment=torch.zeros(());source_loss=torch.zeros(())
                if config['method']=='CoTTA_reg':
                    with torch.no_grad():
                        pseudo=(teacher(torch.from_numpy(np.array(weak1[ids],copy=True)))+teacher(torch.from_numpy(np.array(weak2[ids],copy=True))))/2
                    loss=((model(tx)-pseudo)/30).square().mean()
                    loss.backward();optimizer.step();ema_update(teacher,model,.999);stochastic_restore(model,anchor,.01,restore_rng)
                else:
                    selected=source_rng.choice(len(source_x),min(BATCH,len(source_x)),replace=False)
                    sx=torch.from_numpy(source_x[selected]);sy=torch.from_numpy(source_y[selected]);sw=torch.from_numpy(source_w[selected])
                    sh=hidden24(model,sx);pred=model.layers[-1](sh).squeeze(-1)
                    source_loss=prior.asymmetric_mse(pred,sy,sw,4.);loss=source_loss
                    if config['method']!='source_replay':
                        th=hidden24(model,tx);target_prediction=model.layers[-1](th).squeeze(-1)
                        if config['method'].startswith('CORAL') and min(len(sh),len(th))>=2:
                            alignment=config['strength']*coral_loss((sh-mean)/scale,(th-mean)/scale)
                        if config['method']=='DANN_replay':
                            progress=steps/max(1,total_steps-1);factor=config['strength']*(2/(1+np.exp(-10*progress))-1)
                            feature=torch.cat([(sh-mean)/scale,(th-mean)/scale]);label=torch.cat([torch.zeros(len(sh)),torch.ones(len(th))])
                            logits=discriminator(reverse_gradient(feature,factor))
                            alignment=.5*(F.binary_cross_entropy_with_logits(logits[:len(sh)],label[:len(sh)])+
                                F.binary_cross_entropy_with_logits(logits[len(sh):],label[len(sh):]))
                        loss=loss+alignment
                        if config['method'] in ('CORAL_replay','DANN_replay'):
                            past,logits=memory.sample(BATCH,replay_rng)
                            if len(past):keep=((model(torch.from_numpy(np.array(target_x[past],copy=True)))-torch.from_numpy(logits))/30).square().mean();loss=loss+keep
                            if repeat==0:memory.add(int(block),ids,target_prediction.detach().numpy())
                    assert torch.isfinite(loss);loss.backward();optimizer.step()
                    if config['method']=='DANN_replay':d_optimizer.step()
                assert torch.isfinite(loss);steps+=1
                curves.append(dict(step=steps,block=int(block),repeat=repeat,loss=float(loss.detach()),source_loss=float(source_loss.detach()),
                    alignment_loss=float(alignment.detach()),target_replay_loss=float(keep.detach()),memory_n=len(memory.arrays()[0])))
        # Current calibration observations have been consumed exactly once.
    for name,b in model.named_buffers():assert torch.equal(b,initial_buffers[name])
    result=teacher if config['method']=='CoTTA_reg' else model
    return result,curves,model.state_dict()


def train_seed(seed):
    sources,x,coords,truth=data.load_data();pool=np.load(UOUT/'augmented_global_ids.npy',mmap_mode='r')
    weak=[np.load(UOUT/f'weak{v}.npy',mmap_mode='r') for v in (1,2)]
    for held in data.SCENES:
        with np.load(UOUT/f'partition_{held}.npz') as a:partition={k:a[k] for k in a.files}
        cal,te,mem=partition['calibration_ids'],partition['test_ids'],partition['source_memory_ids']
        _,parts=prior.split_rows(sources,coords,held);va=parts['validation'];si=coords['source_index'];groups=validation_groups(sources,coords,truth,va)
        options=[]
        for lr in prior.LRS:
            folder=prior.run_folder(seed,held,lr,4.);p=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))
            options.append((p['raw_best_validation_mae_m'],folder))
        initial_folder=min(options,key=lambda z:z[0])[1]
        initial_obj=torch.load(initial_folder/'raw_best_model_meters.pt',map_location='cpu',weights_only=True)
        initial=canonical_model();initial.load_state_dict(initial_obj['state_dict']);vref=data.predict_model(initial,x,va);tref=data.predict_model(initial,x,te)
        target_x=np.array(x[cal],copy=True);source_x=np.array(x[mem],copy=True);pos=np.searchsorted(pool,cal)
        np.testing.assert_array_equal(pool[pos],cal);views=[np.array(v[pos],copy=True) for v in weak]
        root=UOUT/f'seed_{seed}'/f'leave_{held}';root.mkdir(parents=True,exist_ok=True)
        np.savez_compressed(root/'initial_predictions.npz',sample_id=te,initial_m=tref)
        for order in ('forward','reverse'):
            for config in ALL_CONFIGS:
                folder=root/order/config['id'];folder.mkdir(parents=True,exist_ok=True)
                if (folder/'protocol.json').exists():continue
                started=time.perf_counter();run_seed=seed+100*data.SCENES.index(held)
                print('ADAPT',seed,held,order,config['id'],len(cal),flush=True)
                source_free=config['method']=='CoTTA_reg'
                model,curves,student=adapt_features(initial_obj['state_dict'],config,None if source_free else source_x,
                    None if source_free else partition['source_memory_truth_m'],None if source_free else partition['source_memory_weights'],
                    target_x,views[0],views[1],partition['block'],run_seed,order)
                vp=data.predict_model(model,x,va);tp=data.predict_model(model,x,te);passed,worst,changes=gate_p5(vp,truth[va],vref,groups)
                protocol=dict(version=VERSION,dataset_version=data.VERSION,config=config,seed=seed,held_scene=held,order=order,
                    initial_checkpoint=str(initial_folder/'raw_best_model_meters.pt'),initial_selected_using_source_validation_only=True,
                    target_calibration_paths=len(cal),target_test_paths=len(te),source_memory_paths=0 if source_free else len(mem),steps=len(curves),
                    target_calibration_labels_used=False,target_test_features_or_labels_used_for_adaptation=False,
                    final_checkpoint_fixed=True,source_guard_passed=passed,worst_source_P5_change_m=worst,
                    source_validation_mae_m=data.validation_metrics(vp,truth[va],si[va],sources)[0],
                    initial_source_validation_mae_m=data.validation_metrics(vref,truth[va],si[va],sources)[0],
                    path_fusion=False,shared_model_all_paths=True,output_unit='meters',seconds=time.perf_counter()-started,
                    original_buffers_fixed=True,algorithm_is_regression_variant=True,
                    is_zero_shot_LOSO=False)
                torch.save(dict(state_dict=model.state_dict(),protocol=protocol),folder/'model_meters.pt')
                torch.save(dict(state_dict=model.state_dict() if passed else initial_obj['state_dict'],
                    protocol=dict(protocol,source_guarded=True,guard_fallback_to_initial=not passed)),folder/'guarded_model_meters.pt')
                if config['method']=='CoTTA_reg':torch.save(dict(state_dict=student,protocol=protocol),folder/'student_audit.pt')
                np.savez_compressed(folder/'predictions.npz',sample_id=te,raw_m=tp,guarded_m=tp if passed else tref)
                pd.DataFrame(curves).to_csv(folder/'adaptation_curve.csv',index=False);write_json(folder/'source_P5_change.json',changes)
                write_json(folder/'protocol.json',protocol)
                print('COMPLETE_ADAPT',seed,held,order,config['id'],'guard',passed,'seconds',round(protocol['seconds'],1),flush=True)
    write_json(UOUT/f'seed_{seed}_complete.json',dict(seed=seed,version=VERSION))


def main():
    p=argparse.ArgumentParser();p.add_argument('--stage',choices=['prepare','train'],required=True);p.add_argument('--seed',type=int,choices=SEEDS)
    args=p.parse_args();sys.stdout.reconfigure(encoding='utf-8');torch.set_num_threads(1);torch.set_num_interop_threads(1);torch.use_deterministic_algorithms(True)
    if args.stage=='prepare':prepare()
    else:
        if args.seed is None:raise ValueError('Choose one disjoint seed worker')
        train_seed(args.seed)


if __name__=='__main__':
    with threadpool_limits(limits=1):main()
