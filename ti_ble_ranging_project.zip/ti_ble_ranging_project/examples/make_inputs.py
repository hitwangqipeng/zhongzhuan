"""Generate SYNTHETIC input-format examples only; this does not run inference."""
from pathlib import Path
import numpy as np

ROOT = Path(__file__).resolve().parent
frequency = np.arange(80, dtype=np.float64)*1e6
truth = np.array([5., 10., 20., 30.])
event = np.array(["synthetic_0", "synthetic_1", "synthetic_2", "synthetic_3"])
path = np.zeros(4, dtype=np.int32)
phase = 2*np.pi*truth[:, None]*frequency[None, :]/299792458
a = np.exp(-1j*phase)
b = np.exp(-1j*phase)
order = np.array([2, 0, 3, 1])
common = dict(truth_m=truth, anchor=np.array(["synthetic"]*4), condition=np.array(["SYNTHETIC"]*4))
np.savez(ROOT/"single.npz", iq=a, frequency_hz=frequency, event_id=event, path_id=path, **common)
np.savez(ROOT/"combined.npz", iq=a*b, frequency_hz=frequency, event_id=event, path_id=path, **common)
np.savez(ROOT/"paired.npz", iq_a=a, iq_b=b[order, ::-1], event_id_a=event, event_id_b=event[order],
         path_id_a=path, path_id_b=path[order], frequency_hz_a=frequency, frequency_hz_b=frequency[::-1], **common)
print("Synthetic format examples written to", ROOT)
