"""Explicit combined / two-endpoint / reciprocal-single-side input cases."""
from dataclasses import dataclass
from pathlib import Path
from collections import Counter
import hashlib
import json
import re
import numpy as np
from .frontend import decode_iq, sort_tones, combine_paired_iq, apply_phase_bias

ASSETS = Path(__file__).resolve().parent / "assets"
HEAD = re.compile(rb'key:(\d+),path:(\d+),\[iq_data\](\d+),(\d+),(\d+),')
POINT = re.compile(rb'\[(\d+)\]:(-?\d+);(-?\d+),(-?\d+)')


@dataclass
class InputBatch:
    iq: np.ndarray
    metadata: list
    truth_m: np.ndarray
    audit: dict


def _path(value, base):
    p = Path(value)
    return p if p.is_absolute() else base / p


def _column(data, name, n, default):
    a = np.asarray(data[name]) if name in data else np.asarray(default)
    if a.ndim == 0:
        return np.repeat(a, n)
    if a.shape != (n,):
        raise ValueError(f"{name} must be scalar or have one value per A/input row")
    return a


def _calibrate(z, data, phase, rows, order, original_n):
    status = phase.get("status")
    if status in ["already_applied", "uncalibrated"]:
        return z
    if status != "apply_combined_bias":
        raise ValueError("Declare phase_calibration.status: already_applied / apply_combined_bias / uncalibrated")
    key = phase.get("bias_key", "combined_phase_bias_rad")
    if key not in data:
        raise ValueError(f"Missing known combined phase-bias array: {key}")
    bias = np.asarray(data[key], float)
    if bias.shape == (80,):
        bias = np.broadcast_to(bias, (original_n, 80))
    if bias.shape != (original_n, 80):
        raise ValueError("Combined phase bias must be80 or N_A x80 radians, in A/input tone order")
    bias = np.take_along_axis(bias[rows], order, axis=1)
    return apply_phase_bias(z, bias)


def _load_npz(config, base):
    spec = config["input"]
    path = _path(spec["path"], base)
    with np.load(path, allow_pickle=False) as archive:
        data = {key: archive[key] for key in archive.files}
    kind = spec["kind"]
    if kind == "paired_npz":
        if "iq" in data:
            raise ValueError("paired_npz must contain iq_a/iq_b; do not pass already-combined iq")
        a = decode_iq(data["iq_a"], spec.get("encoding_a", "iq"), spec["convention_a"])
        b = decode_iq(data["iq_b"], spec.get("encoding_b", "iq"), spec["convention_b"])
        fa = data.get("frequency_hz_a", data.get("frequency_hz"))
        fb = data.get("frequency_hz_b", data.get("frequency_hz"))
        z, pairing = combine_paired_iq(a, b, data["event_id_a"], data["event_id_b"],
            data["path_id_a"], data["path_id_b"], fa, fb, spec.get("unmatched_policy", "error"))
        n = len(a)
        rows, order = pairing["a_rows"], pairing["a_tone_order"]
        event, path_id = pairing["event_id"], pairing["path_id"]
        audit = {k: v for k, v in pairing.items() if k not in ["a_rows", "b_rows", "a_tone_order", "event_id", "path_id"]}
        audit["two_way_operation"] = "I+jQ canonical A times B, without conjugating B"
    elif kind in ["combined_npz", "single_npz"]:
        if "iq_a" in data or "iq_b" in data:
            raise ValueError("Use paired_npz for two endpoint arrays")
        original = decode_iq(data["iq"], spec.get("encoding", "iq"), spec["convention"])
        z, _, order = sort_tones(original, data["frequency_hz"])
        n = len(z); rows = np.arange(n)
        event = _column(data, "event_id", n, "").astype(str)
        event = np.array([value if value else f"row_{i}" for i, value in enumerate(event)])
        path_id = _column(data, "path_id", n, 0).astype(str)
        audit = {"input_rows": n, "matched_rows": n}
        if kind == "single_npz":
            if spec.get("adapter") != "reciprocal_square":
                raise ValueError("Original TI weights require two-way phase. Explicitly choose single-side adapter=reciprocal_square")
            # Assumption H_forward == H_reverse after convention/calibration.
            # This is an adapter, not a recovered real reverse-end measurement.
            z = z*z
            audit.update(single_side_adapter="reciprocal_square", true_reverse_endpoint_available=False,
                         assumption="reciprocal identical endpoint response", single_side_quality_certified=False)
    else:
        raise ValueError("Unknown NPZ input kind")
    phase = config.get("phase_calibration", {})
    z = _calibrate(z, data, phase, rows, order, n)
    truth = _column(data, "truth_m", n, np.nan).astype(float)[rows]
    if np.isinf(truth).any() or np.any(truth[np.isfinite(truth)] < 0):
        raise ValueError("truth_m must be nonnegative distance or NaN for unavailable reference")
    anchor = _column(data, "anchor", n, "").astype(str)[rows]
    condition = _column(data, "condition", n, "").astype(str)[rows]
    metadata = [dict(event_id=str(event[i]), path=str(path_id[i]), anchor=str(anchor[i]), condition=str(condition[i]),
                     source_file=str(path.resolve()), source_line="") for i in range(len(z))]
    audit.update(input_kind=kind, input_file=str(path.resolve()), input_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
                 phase_state=phase["status"], no_reference_used_for_preprocessing=True)
    return InputBatch(z, metadata, truth, audit)


def _parse_log(path, complete_four_paths=True):
    records = []; seen = set(); previous = None; epoch = 0; audit = Counter()
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for number, line in enumerate(stream, 1):
            digest.update(line)
            if b"[iq_data]" not in line:
                continue
            audit["iq_lines"] += 1
            h = HEAD.search(line)
            if h is None:
                audit["bad_header"] += 1; continue
            key, antenna, iqkey, side, ts = map(int, h.groups())
            points = POINT.findall(line[h.end():])
            if key != iqkey or len(points) != 80 or [int(p[0]) for p in points] != list(range(80)) or POINT.sub(b"", line[h.end():]).strip(b";. \r\n"):
                audit["bad_structure"] += 1; continue
            z = np.array([complex(int(p[2]), int(p[3])) for p in points])
            if not np.any(z):
                audit["all_zero"] += 1; continue
            if max(np.max(abs(z.real)), np.max(abs(z.imag))) > 32767:
                audit["out_of_range"] += 1; continue
            if previous is not None and ts < previous:
                epoch += 1
            previous = ts
            uid = (epoch, key, ts, antenna)
            if uid in seen:
                audit["duplicates"] += 1; continue
            seen.add(uid)
            records.append((epoch, key, ts, antenna, number, z))
            audit["valid_path_records"] += 1
    if complete_four_paths:
        groups = {}
        for row in records:
            groups.setdefault(row[:3], []).append(row)
        selected = []
        for group in groups.values():
            if len(group) == 4 and {r[3] for r in group} == {0, 1, 2, 3}:
                selected.extend(sorted(group, key=lambda r: r[3]))
        records = selected
    audit["selected_path_records"] = len(records)
    audit["selected_frames"] = len({r[:3] for r in records})
    return records, dict(audit, source_file=str(path.resolve()), sha256=digest.hexdigest())


def _load_logs(config, base):
    spec = config["input"]
    if config.get("phase_calibration", {}).get("status") != "already_applied":
        raise ValueError("Legacy combined-log adapter requires phase status already_applied; use NPZ for explicit phase bias")
    target = _path(spec["path"], base)
    files = sorted(target.rglob("*.log")) if spec["kind"] == "combined_log_directory" else [target]
    geometry_path = _path(spec["geometry_file"], base) if "geometry_file" in spec else ASSETS / "car_geometry.json"
    geometry = json.loads(geometry_path.read_text(encoding="utf-8"))["anchors"]
    unknown_policy = spec.get("unknown_anchor_policy", "inference_only")
    if unknown_policy not in ["skip", "inference_only", "error"]:
        raise ValueError("unknown_anchor_policy must be skip, inference_only or error")
    all_iq = []; metadata = []; truths = []; source_audit = []
    for path in files:
        match = re.search(r"\]\[(master|slave\d+)\]", path.name)
        anchor = str(spec.get("anchor", match.group(1) if match else ""))
        if anchor not in geometry and unknown_policy == "skip":
            source_audit.append(dict(source_file=str(path.resolve()), skipped=True, reason="no confirmed3D geometry", anchor=anchor)); continue
        if anchor not in geometry and unknown_policy == "error":
            raise ValueError(f"Unknown anchor geometry: {anchor}")
        found = re.search(r"定点(\d+(?:\.\d+)?)M", path.parent.name, flags=re.IGNORECASE)
        nominal = spec.get("nominal_m", float(found.group(1)) if found else None)
        condition = "NLOS" if "NLOS" in path.parts else "LOS" if "LOS" in path.parts else ""
        rows, audit = _parse_log(path, spec.get("complete_four_paths_only", True))
        audit.update(anchor=anchor, condition=condition, skipped=False)
        source_audit.append(audit)
        if not rows:
            continue
        reference = np.nan
        if anchor in geometry and nominal is not None:
            a, b, h = geometry[anchor]
            reference = float(np.sqrt((float(nominal)+a)**2+b*b+h*h))
        all_iq.append(np.stack([r[5] for r in rows]))
        for epoch, key, ts, antenna, number, _ in rows:
            metadata.append(dict(event_id=f"{path.resolve()}|{epoch}:{key}:{ts}", path=str(antenna),
                anchor=anchor, condition=condition, source_file=str(path.resolve()), source_line=number))
            truths.append(reference)
    if not all_iq:
        raise ValueError("No valid IQ records selected")
    return InputBatch(np.concatenate(all_iq), metadata, np.asarray(truths),
        dict(input_kind=spec["kind"], input_stage="already two-way combined, already phase calibrated",
             selected_rows=len(metadata), files_seen=len(files), sources=source_audit,
             geometry=str(geometry_path.resolve()), unknown_anchor_policy=unknown_policy))


def load_case(config_file):
    path = Path(config_file).resolve()
    config = json.loads(path.read_text(encoding="utf-8"))
    kind = config["input"]["kind"]
    if kind in ["combined_npz", "paired_npz", "single_npz"]:
        batch = _load_npz(config, path.parent)
    elif kind in ["combined_log", "combined_log_directory"]:
        batch = _load_logs(config, path.parent)
    else:
        raise ValueError("Unsupported input kind")
    return config, batch
