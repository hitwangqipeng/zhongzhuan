"""Explicit IQ conventions, event/frequency pairing, and audited TI adapter."""
import numpy as np

L = 12
COL = np.repeat(np.arange(L), np.arange(1, L+1))
ROW = np.concatenate([np.arange(j+1) for j in range(L)])


def decode_iq(value, encoding="iq", convention="i_plus_jq"):
    a = np.asarray(value)
    if encoding == "ti_tone_u32":
        if a.dtype.kind not in "ui" or a.ndim != 2 or np.any(a < 0) or np.any(a > 0xffffffff):
            raise ValueError("TI tones must be an unsigned32-bit N x tones integer array")
        word = a.astype(np.uint32)
        real = (word & 0xfff).astype(np.int32)
        imag = ((word >> 12) & 0xfff).astype(np.int32)
        real = np.where(real >= 2048, real-4096, real)
        imag = np.where(imag >= 2048, imag-4096, imag)
        z = real.astype(float) + 1j*imag.astype(float)
    elif encoding == "iq":
        if a.ndim == 3 and a.shape[-1] == 2 and a.dtype.kind in "iuf":
            z = a[..., 0].astype(float) + 1j*a[..., 1].astype(float)
        elif a.ndim == 2 and a.dtype.kind == "c":
            z = a.astype(np.complex128)
        else:
            raise ValueError("IQ must be complex N x80 or real N x80 x2 (I,Q)")
    else:
        raise ValueError("Unknown IQ encoding")
    if z.shape[1] != 80 or not np.isfinite(z).all() or len(z) == 0:
        raise ValueError("Expected nonempty, finite IQ with80 tones per row")
    if np.any(np.mean(abs(z)**2, axis=1) <= 0):
        raise ValueError("All-zero IQ rows have undefined normalized covariance")
    if convention == "i_minus_jq":
        z = z.conj()
    elif convention != "i_plus_jq":
        raise ValueError("Declare IQ convention: i_plus_jq or i_minus_jq")
    return z


def frequency_matrix(frequency_hz, n):
    f = np.asarray(frequency_hz, np.float64)
    if f.shape == (80,):
        f = np.broadcast_to(f, (n, 80))
    if f.shape != (n, 80) or not np.isfinite(f).all():
        raise ValueError("frequency_hz must be80 values or N x80 finite values")
    return f


def sort_tones(z, frequency_hz):
    f = frequency_matrix(frequency_hz, len(z))
    order = np.argsort(f, axis=1, kind="stable")
    f = np.take_along_axis(f, order, axis=1)
    if not np.allclose(np.diff(f, axis=1), 1e6, rtol=0, atol=1.):
        raise ValueError("Original-model adapter requires80 unique consecutive1MHz tones; no implicit interpolation")
    return np.take_along_axis(z, order, axis=1), f, order


def _ids(values, n, label):
    a = np.asarray(values)
    if a.shape != (n,) or a.dtype.kind not in "iuUS":
        raise ValueError(f"{label} must contain one integer/string ID per row")
    result = a.astype(str)
    if np.any(result == ""):
        raise ValueError(f"Empty {label}")
    return result


def combine_paired_iq(iq_a, iq_b, event_id_a, event_id_b, path_id_a, path_id_b,
                      frequency_hz_a, frequency_hz_b, unmatched_policy="error"):
    """Match event+normalized path, sort matching tones, multiply A*B.

    Inputs must have already been converted to canonical I+jQ. Conjugating B
    here would cancel reciprocal propagation phase and is NOT the two-way rule.
    """
    a = np.asarray(iq_a, np.complex128)
    b = np.asarray(iq_b, np.complex128)
    if a.ndim != 2 or b.ndim != 2 or a.shape[1] != 80 or b.shape[1] != 80:
        raise ValueError("Both endpoints require N x80 complex IQ")
    ea, eb = _ids(event_id_a, len(a), "event_id_a"), _ids(event_id_b, len(b), "event_id_b")
    pa, pb = _ids(path_id_a, len(a), "path_id_a"), _ids(path_id_b, len(b), "path_id_b")
    ka, kb = list(zip(ea, pa)), list(zip(eb, pb))
    if len(set(ka)) != len(ka) or len(set(kb)) != len(kb):
        raise ValueError("Duplicate event/path keys; include session/epoch in event_id")
    mapping = {key: i for i, key in enumerate(kb)}
    missing_a = [key for key in ka if key not in mapping]
    keys_a = set(ka)
    missing_b = [key for key in kb if key not in keys_a]
    if unmatched_policy not in ["error", "drop"]:
        raise ValueError("unmatched_policy must be error or drop")
    if (missing_a or missing_b) and unmatched_policy == "error":
        raise ValueError(f"Unmatched measurements: A-only={len(missing_a)}, B-only={len(missing_b)}")
    ia = np.array([i for i, key in enumerate(ka) if key in mapping], dtype=int)
    ib = np.array([mapping[ka[i]] for i in ia], dtype=int)
    if not len(ia):
        raise ValueError("No matched endpoint measurements")
    fa = frequency_matrix(frequency_hz_a, len(a))[ia]
    fb = frequency_matrix(frequency_hz_b, len(b))[ib]
    aa, fa, oa = sort_tones(a[ia], fa)
    bb, fb, _ = sort_tones(b[ib], fb)
    if not np.allclose(fa, fb, rtol=0, atol=1.):
        raise ValueError("Endpoints do not refer to the same physical tone frequencies")
    z = aa * bb
    if not np.isfinite(z).all() or np.any(np.mean(abs(z)**2, axis=1) <= 0):
        raise ValueError("Invalid or all-zero combined IQ")
    return z, dict(a_rows=ia, b_rows=ib, a_tone_order=oa, event_id=ea[ia], path_id=pa[ia],
                   input_a_rows=len(a), input_b_rows=len(b), matched_rows=len(ia),
                   dropped_a_rows=len(missing_a), dropped_b_rows=len(missing_b))


def apply_phase_bias(z, bias_rad):
    bias = np.asarray(bias_rad, float)
    if bias.shape == (80,):
        bias = np.broadcast_to(bias, z.shape)
    if bias.shape != z.shape or not np.isfinite(bias).all():
        raise ValueError("Combined phase bias must be80 or N x80 finite radians")
    return z * np.exp(-1j*bias)


def covariance_features(z):
    z = np.asarray(z, np.complex128)
    if z.ndim != 2 or z.shape[1] != 80 or not np.isfinite(z).all():
        raise ValueError("Expected finite N x80 combined IQ")
    energy = np.mean(abs(z)**2, axis=1)
    if np.any(energy <= 0):
        raise ValueError("All-zero IQ row")
    z = (z / np.sqrt(energy)[:, None]).astype(np.complex64)
    r = np.zeros((len(z), L, L), np.complex64)
    for parity in [0, 1]:
        x = np.lib.stride_tricks.sliding_window_view(z[:, parity::2], L, axis=1)
        r += x.transpose(0, 2, 1) @ x.conj() / x.shape[1]
    u = r[:, ROW, COL]
    u /= np.linalg.norm(u, axis=1)[:, None]
    result = np.empty((len(z), 156), np.float32)
    result[:, ::2] = u.real
    result[:, 1::2] = u.imag
    return result


def sdk_time_window(z):
    """Audited fresh single-path SDK correlogram/state and Gaussian window."""
    power = (abs(np.fft.ifft(z, 256, axis=1))**2).astype(np.float32)
    padded = np.concatenate([power[:, -6:], power[:, :-1]], axis=1)
    smooth = np.zeros_like(power)
    for i in range(256):
        value = padded[:, i].copy()
        for j in range(1, min(i, 3)+1):
            value += padded[:, i-j]
        smooth[:, i] = value * np.float32(.25)
    maximum = smooth.max(axis=1)
    argmax = smooth.argmax(axis=1)
    noise_sum = np.zeros(len(z), np.float32)
    for i in range(144, 248):
        noise_sum += smooth[:, i]
    noise = noise_sum / np.float32(104)
    threshold = np.maximum(noise*np.float32(15.848932266235352), maximum*np.float32(.015848930925130844))
    above = smooth[:, 1:127] > threshold[:, None]
    first = np.where(above.any(axis=1), above.argmax(axis=1)+1, 0)
    peaks = (smooth[:, 1:127] > smooth[:, :126]) & (smooth[:, 1:127] > smooth[:, 2:128])
    peaks &= smooth[:, :126] > threshold[:, None]
    valid = (argmax < 128) & peaks.any(axis=1) & (first > 3)
    state = np.where(valid, first-4, 0).astype(np.int32)
    t = np.arange(128, dtype=np.float32) / np.float32(16)
    gaussian = np.exp((t*t*np.float32(-.5)).astype(np.float32)).astype(np.float32)
    windows = np.empty((len(z), 256), np.float32)
    for i, peak in enumerate(state):
        if peak == 0:
            windows[i] = 1
        else:
            center = int(peak)+1
            windows[i, :center] = 1
            windows[i, center:128] = gaussian[:128-center]
            windows[i, 128:] = gaussian[::-1]
    transformed = np.fft.fft(np.fft.ifft(z, 256, axis=1)*windows, 256, axis=1)[:, :80]
    return transformed, state
