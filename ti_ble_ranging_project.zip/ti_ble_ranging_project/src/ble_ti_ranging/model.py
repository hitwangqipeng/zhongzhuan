"""Original TI156->12->36->24->1 weights; NumPy-only, no training."""
from pathlib import Path
import hashlib
import json
import numpy as np

ASSETS = Path(__file__).resolve().parent / "assets"


class FrozenTiModel:
    def __init__(self, weights=None, manifest=None):
        path = ASSETS / "ti_original_weights.npz" if weights is None else Path(weights)
        spec_path = ASSETS / "model_manifest.json" if manifest is None else Path(manifest)
        self.manifest = json.loads(spec_path.read_text(encoding="utf-8"))
        self.sha256 = hashlib.sha256(path.read_bytes()).hexdigest()
        if self.sha256 != self.manifest["canonical_weights_sha256"]:
            raise ValueError("Weight checksum does not match the original-model manifest")
        with np.load(path, allow_pickle=False) as archive:
            self.offset = archive["offset"].astype(np.float32)
            self.gain = archive["gain"].astype(np.float32)
            self.layers = [(archive[f"fc{i}_W"].astype(np.float32), archive[f"fc{i}_b"].astype(np.float32))
                           for i in range(1, 5)]
        dimensions = [156, 12, 36, 24, 1]
        for i, (w, b) in enumerate(self.layers):
            if w.shape != (dimensions[i+1], dimensions[i]) or b.shape != (dimensions[i+1],):
                raise ValueError("Unexpected TI weight dimensions")
        if self.offset.shape != (156,) or self.gain.shape != (156,):
            raise ValueError("Unexpected TI affine dimensions")
        for array in [self.offset, self.gain, *[v for pair in self.layers for v in pair]]:
            if not np.isfinite(array).all():
                raise ValueError("Nonfinite model parameters")
            array.setflags(write=False)

    def predict(self, features):
        x = np.asarray(features, np.float32)
        if x.ndim != 2 or x.shape[1] != 156 or not np.isfinite(x).all():
            raise ValueError("TI original model requires finite N x156 features")
        h = (x - self.offset) * self.gain
        for i, (w, b) in enumerate(self.layers):
            h = h @ w.T + b
            if i < 3:
                h = np.maximum(h, 0)
        # Original predictor is already in meters: no x30, no SDK offset here.
        result = h[:, 0]
        if not np.isfinite(result).all():
            raise ValueError("Nonfinite model output")
        return result
