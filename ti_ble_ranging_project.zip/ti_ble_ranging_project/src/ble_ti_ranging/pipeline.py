"""Batch inference on already-prepared, canonical combined IQ."""
import numpy as np
from .frontend import covariance_features, sdk_time_window
from .model import FrozenTiModel


def infer_iq(iq, modes=("none", "sdk"), distance_correction_m=0., batch_size=512, model=None):
    z = np.asarray(iq, np.complex128)
    if z.ndim != 2 or z.shape[1] != 80 or len(z) == 0 or not np.isfinite(z).all():
        raise ValueError("Expected finite nonempty N x80 combined IQ")
    modes = list(modes)
    if not modes or len(set(modes)) != len(modes) or any(v not in ["none", "sdk"] for v in modes):
        raise ValueError("modes must contain none and/or sdk, without duplicates")
    if not np.isfinite(distance_correction_m) or batch_size < 1:
        raise ValueError("Invalid distance correction or batch size")
    model = FrozenTiModel() if model is None else model
    result = {}
    for mode in modes:
        raw = np.empty(len(z), np.float32)
        states = np.zeros(len(z), np.int32)
        for start in range(0, len(z), batch_size):
            chunk = z[start:start+batch_size]
            if mode == "sdk":
                chunk, state = sdk_time_window(chunk)
                states[start:start+len(chunk)] = state
            raw[start:start+len(chunk)] = model.predict(covariance_features(chunk))
        result[f"raw_model_{mode}_m"] = raw
        result[f"distance_{mode}_m"] = raw.astype(float)-float(distance_correction_m)
        if mode == "sdk":
            result["peak_bin_sap"] = states
    return result


def error_metrics(prediction, truth):
    prediction, truth = np.asarray(prediction, float), np.asarray(truth, float)
    keep = np.isfinite(prediction) & np.isfinite(truth)
    n = int(keep.sum())
    base = dict(n_input=len(truth), n_evaluated=n, missing_reference_n=int((~np.isfinite(truth)).sum()))
    if not n:
        return dict(base, mae_m="", error_p5_m="", abs_error_p5_m="", cep95_m="", bias_m="", under3_pct="")
    e = prediction[keep]-truth[keep]
    return dict(base, mae_m=float(abs(e).mean()), error_p5_m=float(np.quantile(e, .05)),
        abs_error_p5_m=float(np.quantile(abs(e), .05)), cep95_m=float(np.quantile(abs(e), .95)),
        bias_m=float(e.mean()), under3_pct=float(100*np.mean(e < -3)))
