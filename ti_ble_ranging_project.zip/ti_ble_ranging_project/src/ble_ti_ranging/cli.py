import argparse
import csv
import gzip
import json
from pathlib import Path
import sys
import numpy as np
from .inputs import load_case
from .model import FrozenTiModel
from .pipeline import infer_iq, error_metrics


def _write_csv(path, records):
    records = list(records)
    if not records:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader(); writer.writerows(records)


def run(config_file, output_dir, correction_override=None):
    config, batch = load_case(config_file)
    settings = config.get("inference", {})
    modes = settings.get("windows", ["none", "sdk"])
    correction = float(settings.get("distance_correction_m", 0.)) if correction_override is None else correction_override
    model = FrozenTiModel()
    predictions = infer_iq(batch.iq, modes=modes, distance_correction_m=correction,
                           batch_size=int(settings.get("batch_size", 512)), model=model)
    output = Path(output_dir).resolve(); output.mkdir(parents=True, exist_ok=True)
    fields = ["sample_id", "event_id", "path", "anchor", "condition", "source_file", "source_line", "truth_m", *predictions]
    fields += [f"error_{mode}_m" for mode in modes]
    with gzip.open(output / "predictions.csv.gz", "wt", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=fields); writer.writeheader()
        for i, meta in enumerate(batch.metadata):
            ref = float(batch.truth_m[i]); known = bool(np.isfinite(ref))
            row = dict(sample_id=i, **meta, truth_m=ref if known else "")
            for key, value in predictions.items():
                row[key] = value[i].item()
            for mode in modes:
                row[f"error_{mode}_m"] = float(predictions[f"distance_{mode}_m"][i])-ref if known else ""
            writer.writerow(row)
    groups = [("ALL", np.arange(len(batch.iq)))]
    for field in ["condition", "anchor", "path"]:
        names = np.array([str(row[field]) for row in batch.metadata])
        for name in sorted(set(names)-{""}):
            groups.append((f"{field}:{name}", np.flatnonzero(names == name)))
    pairs = [(str(row["condition"]), str(row["anchor"]), str(row["path"])) for row in batch.metadata]
    for condition, anchor, path in sorted(set(pairs)):
        if anchor:
            ix = np.array([i for i, key in enumerate(pairs) if key == (condition, anchor, path)])
            groups.append((f"condition:{condition}/anchor:{anchor}/path:{path}", ix))
    metrics = []
    for label, ix in groups:
        for mode in modes:
            for stage, key in [("raw_model", f"raw_model_{mode}_m"), ("calibrated", f"distance_{mode}_m")]:
                metrics.append(dict(group=label, window=mode, stage=stage,
                    **error_metrics(predictions[key][ix], batch.truth_m[ix])))
    _write_csv(output / "metrics.csv", metrics)
    _write_csv(output / "overall_metrics.csv", [r for r in metrics if r["group"] == "ALL"])
    protocol = dict(project_version="1.0.0", config=json.loads(Path(config_file).read_text(encoding="utf-8")),
        n_input_rows=len(batch.iq), n_reference_rows=int(np.isfinite(batch.truth_m).sum()),
        model_sha256=model.sha256, model_manifest=model.manifest, input_audit=batch.audit,
        windows=modes, distance_correction_m=correction, negative_output_clipping=False,
        training_or_finetuning=False, true_distance_is_model_input=False,
        current_release_new_data_validation_executed=False,
        single_side_quality_certified=False)
    (output / "run_protocol.json").write_text(json.dumps(protocol, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"Output: {output}")
    for row in metrics:
        if row["group"] == "ALL":
            print(json.dumps(row, ensure_ascii=False))
    return output


def main():
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    parser = argparse.ArgumentParser(description="Original TI BLE ranging weights: combined / paired / reciprocal-single-side IQ")
    parser.add_argument("--config", required=True, help="Case JSON; input paths are relative to its directory")
    parser.add_argument("--output", required=True, help="Output directory")
    parser.add_argument("--correction-m", type=float, default=None, help="Override amount subtracted from every NN output")
    args = parser.parse_args()
    try:
        run(args.config, args.output, args.correction_m)
    except (ValueError, KeyError, FileNotFoundError) as exc:
        parser.exit(2, f"Input/configuration error: {exc}\n")
