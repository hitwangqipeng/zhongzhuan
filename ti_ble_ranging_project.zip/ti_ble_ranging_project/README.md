# TI BLE 测距推理 project

独立Python工程，使用已经还原的TI SDK 9.23.00.27原始预训练权重。运行时仅依赖NumPy，不依赖上级Ranging工程、TI SDK、PyTorch、Pandas或ARM仿真器。

**预处理核对：NN协方差和固定仿射已包含，但不是完整TI双端测距链路。** 时域窗来自Hist分支的单path、无历史适配；双端RPL/TQI处理、缺失频点恢复和跨子事件相位拼接未完整移植。逐项清单见[预处理覆盖说明](docs/TI_PREPROCESSING_COVERAGE.md)。

按本次要求，不再新增数据验证或执行本project的推理/回归测试。这里提供流程和代码；不据此声称当前单侧IQ的质量已经得到实测确认。

## 输入case

|case|入口|适用输入|进入协方差前的处理|
|---|---|---|---|
|已双向合成|`combined_npz`|N×80复数IQ|直接使用，不重复合成|
|两端尚未合成|`paired_npz`|A、B两端各自IQ及事件/path/频率|配对并逐频点计算A×B，不取B共轭|
|仅有单侧|`single_npz`|单侧N×80复数IQ|显式互易平方适配H×H|
|当前实车日志|`combined_log` / `combined_log_directory`|已合成并校准的现有.log|按已有日志契约读取，不再次平方或合成|

**单侧模式的使用前提：** `reciprocal_square`假设反向信道与正向信道在相位约定/校准后相同，用H×H近似双向合成。这不是从单侧数据还原出的真实对端测量，也不是TI原模型直接接收单程IQ的证明。已有双端IQ时应优先使用`paired_npz`；已有合成IQ使用`combined_npz`。本次没有为单侧新case给出实车精度结论。

## 完整推理流程

```mermaid
flowchart TD
    A[已合成IQ] --> D[统一I+jQ及80点1MHz频率网格]
    B[两端未合成IQ] --> B1[事件与path配对 / 频点对齐 / A乘B]
    C[单侧IQ] --> C1[显式互易假设 / H乘H]
    B1 --> D
    C1 --> D
    D --> E[按配置保留相位校准状态或减去已知组合相位偏差]
    E --> F[可选SDK状态时域窗：256点IFFT / 乘窗 / FFT]
    F --> G[奇偶频点2组 / 组内2MHz / L12空间平滑]
    G --> H[78复数上三角整体L2 / 实虚交错156维]
    H --> I[原SDK固定offset与gain]
    I --> J[原权重156→12→36→24→1]
    J --> K[原NN米输出]
    K --> L[可配置距离修正：预测减0.94m等]
    L --> M[可用参考距离时统计MAE / error P5 / CEP95]
```

相位校准与距离减0.94m是两个独立步骤。原NN输出已经是米，不乘30，不自动扣9m，不自动截零。已核对的SDK `distanceOffsetNN=-0.8m`属于另一个调用分支，本project不自动叠加该Adaptive节点修正。

## 启动

已有NumPy的Python环境可直接运行，无需安装本包。新环境先运行：

```powershell
python -m pip install -r requirements.txt
```

先生成**合成格式示例**（只生成输入，不代表真实采集的单侧/双侧数据）：

```powershell
python examples/make_inputs.py
```

单侧入口：

```powershell
python run.py --config examples/single.json --output runs/single
```

尚未合成的两端IQ：

```powershell
python run.py --config examples/paired.json --output runs/paired
```

已合成IQ：

```powershell
python run.py --config examples/combined.json --output runs/combined
```

当前实车日志，保留原先4个有3D几何参数的锚点、同时输出无窗/有窗结果，并减0.94m：

```powershell
python run.py --config configs/realcar_094.json --output runs/realcar
```

更换电脑后修改配置中的日志目录。数据路径相对于配置文件目录解释；输出路径相对于当前运行目录解释。

临时覆盖距离修正值：

```powershell
python run.py --config examples/single.json --output runs/single_094 --correction-m 0.94
```

需要安装为命令行工具时可选择`python -m pip install -e .`，之后使用`ti-ble-range --config ... --output ...`。

## 输出

- `predictions.csv.gz`：逐path预测，包含原NN输出`raw_model_none_m` / `raw_model_sdk_m`，减去配置修正值后的`distance_none_m` / `distance_sdk_m`，以及可用真值和误差。`none`表示无时域窗，`sdk`表示SDK状态时域窗。
- `overall_metrics.csv`：每个窗口方案在原NN输出和距离修正后两个阶段的总体指标。
- `metrics.csv`：另按condition、anchor、path及condition×anchor×path分组。所有path使用同一个模型，没有融合。
- `run_protocol.json`：输入阶段、配对丢失数、相位状态、模型哈希、距离修正和样本覆盖口径。

误差定义为e=预测−参考距离；MAE=mean|e|，error P5=e的P5，CEP95=|e|的P95。没有参考距离的记录仍推理，但不计算对应误差。元数据和真值不进入网络。

## 当前实车配置的范围

配置`realcar_094.json`使用assets中已确认的3D几何表：master、slave1、slave2、slave4。默认跳过没有已确认几何参数的slave3，因此沿用此前64份日志、113,928条完整帧path记录的选择口径。

将`unknown_anchor_policy`改为`inference_only`可以输出未知锚点的预测；这些记录没有3D真值时不计入误差。不得为slave3猜测几何参数。四path完整帧筛选由`complete_four_paths_only`明确控制；NPZ输入不要求四path齐全。

## 文件结构

```text
run.py                         命令行入口
pyproject.toml                 可选安装入口
src/ble_ti_ranging/inputs.py    case读取、配对及已有日志适配
src/ble_ti_ranging/frontend.py  合成、相位、SDK时域窗、协方差
src/ble_ti_ranging/model.py     原权重固定MLP
src/ble_ti_ranging/pipeline.py  批量推理及误差指标
src/ble_ti_ranging/cli.py       运行、CSV及协议文件输出
src/ble_ti_ranging/assets/      随工程提供的模型和几何数据
examples/                      三种输入的配置和合成输入生成器
configs/realcar_094.json        当前实车配置
docs/INPUT_FORMAT.md           接口字段和相位约定
```

模型使用2MHz分组、L12、156维输入。保留80点日志适配，未完整复制TI75信道、SAP多path/历史融合或全部双端Tone/TQI/RPL处理；不代表官方固件完整性能或芯片逐位等价。新单侧case没有新增实测验证。
