# TI预处理覆盖核对

核对日期：2026-11-18。对象：TI F3 SDK 9.23.00.27 GCC m33f测距库和本project当前源代码。本次仅核对已有代码与SDK证据，没有重新跑实车数据、推理或测试。

结论：本project包含原NN的主要协方差特征构造、固定输入仿射，以及可选的单path时域窗适配。它没有包含完整TI双端前处理，也没有复制完整的多path/历史Adaptive流程。

## 已包含与适配内容

|环节|当前实现|范围|
|---|---|---|
|I/Q读取与约定转换|`frontend.decode_iq`|复数、I/Q二元数组，或TI打包字中的12位有符号I/Q；不处理完整CS子事件或TQI质量规则|
|双端配对和合成|`frontend.combine_paired_iq`|按事件和归一化path配对、物理频点排序后A×B；只覆盖组合量构造，不等于完整`writeTone2APU`|
|已知相位偏差校正|`inputs._calibrate` / `frontend.apply_phase_bias`|仅在显式提供组合相位偏差时乘exp(-j*bias)；`already_applied`和`uncalibrated`均不估计新偏差|
|时域加窗再回频域|`frontend.sdk_time_window`|256点IFFT→窗→FFT→取前80点，`windows`包含`sdk`时执行；`none`为无窗对照|
|窗状态估计|同上|当前单path、无历史：功率谱、6点环绕前缀、4点因果平均、噪声/峰判定得到状态；状态0旁路|
|时域窗形|同上|非零状态按state+1生成平台及sigma=16点Gaussian衰减；保留已核对的默认窗分支，未实现所有可配置窗分支|
|频点分组和空间平滑|`frontend.covariance_features`|80点按奇偶分为两组40点，组内2MHz，L=12，每组29个重叠窗口，xx^H；FB关闭|
|上三角打包|同上|按列取78个复数，保留对角虚部位置|
|协方差特征归一化|同上|对78个复数整体做L2归一化，再交错实部/虚部为156维；不是完整矩阵Frobenius归一化|
|固定inferFilLayer仿射|`model.FrozenTiModel.predict`|使用原SDK固定offset和gain计算(x-offset)*gain，没有逐帧重新估计均值和方差|
|原网络|同上|156→12→36→24→1，原始权重，三个ReLU，线性米输出|

协方差前还做了一次本帧公共能量归一化，以改善数值范围。SDK NN此处的归一化枚举为None；对于本project单path、随后上三角L2归一化的流程，该公共缩放在理想代数下会消掉，但浮点运算顺序并不完全相同，不能据此声称芯片逐位一致。

## 尚未完整包含

|TI环节|本project现状|影响|
|---|---|---|
|原生CS事件、信道映射及最多75位置网格|使用连续80点、1MHz日志网格；排序后要求完整，不做隐式插值|不是TI原生72有效信道/75位置的输入接口|
|跨子事件相位拼接`stitchSubevents`|未实现|已校准日志沿用已有状态；单侧原始输入不会自动获得TI拼接校正|
|`writeTone2APU`完整双端Tone/TQI规则|仅实现I/Q解码与A×B等接口适配|打包I/Q解析不代表质量处理已包含|
|`scalePCTRPL`|未实现|未依据Reference Power Level执行TI逐频点缩放；本帧公共能量归一化不能替代它|
|`recoverPCT`及gap插值|未实现|不恢复缺失频点；输入不是完整连续80点时直接报错|
|`improvePCT2W`|未实现|未移植SDK这一后续双端处理步骤，不宣称已有同等抗干扰能力|
|公开NN SAP的多path协方差汇总|未实现|按用户要求，每个path独立推理、共享网络；与先平均协方差再推理不同|
|Hist SNR条件、历史缓存和PDP时间IIR|未完整实现|时域窗仅适配当前单path、无历史状态；没有执行完整`minSNRNN=9`历史特征分支|
|完整Adaptive及应用时间滤波|未实现|不含NN/MUSIC自适应输出和应用Slew Rate/MA2等滤波|

## 两个容易混淆的地方

1. **时域窗存在，不代表完整TI NN调用链已复制。** SDK公开NN SAP提取器是逐path预处理、计算并汇总协方差；本project的可选窗参考Hist相关实现，适配到80点单path。不能描述为TI公开NN SAP每帧固定执行的同一套流程。
2. **单侧H×H是本project的互易假设适配。** 它不是TI双端A×B的实测替代，也不恢复两端振荡器/硬件相位误差抵消。`phase_calibration.status="already_applied"`只是输入声明，不会替用户完成相位校准或证明该声明成立。

原NN米输出不自动叠加Adaptive分支的`distanceOffsetNN=-0.8m`。实车配置中的减0.94m为此前用户指定的输出校准，与IQ相位校准、RPL缩放、缺失频点恢复均为不同步骤。

## 核对依据

SDK本地头文件：`external/ti_f3_sdk_9_23_00_27/extracted/simplelink_lowpower_f3_sdk_9_23_00_27/source/ti/ble/app_util/cs_ranging/include/BleCsRanging.h`。

父工程已保存的SDK反汇编：`outputs/ti_nn_analysis_20261118/evidence/BleCsRangingProcess.c.obj.txt`中的`preprocessPCT`调用顺序为`writeTone2APU → scalePCTRPL → recoverPCT → improvePCT2W`；`BleCsRangingNet.c.obj.txt`的`extractFeatureSAP`包含多path协方差汇总。完整背景见父工程`outputs/ti_nn_analysis_20261118/TI_F3_SDK_9_23_NN测距技术分析.md`。

此前时域窗核对记录：`outputs/ti_time_window_audit_20261118/verification.json`，范围明确为单path、无历史、80点适配，非完整Adaptive或芯片数值等价。本project没有在本次重新执行这些核对。
