# 输入格式

## 1. 已合成NPZ

必需字段：

|字段|形状|含义|
|---|---|---|
|iq|N×80复数，或N×80×2实数|已合成的IQ；最后一维为I、Q|
|frequency_hz|80或N×80|频率，Hz；可用已确认共同网格的相对频率|

配置`input.kind=combined_npz`，`input.convention=i_plus_jq`。若文件按I−jQ表达，显式指定`i_minus_jq`以转换到统一约定。

## 2. 未双向合成的双端NPZ

|字段|形状|含义|
|---|---|---|
|iq_a、iq_b|N_A×80及N_B×80复数，或对应I/Q实数对|两个方向的IQ|
|event_id_a、event_id_b|N_A及N_B|同一CS测量事件的共同ID|
|path_id_a、path_id_b|N_A及N_B|已经映射到同一个双端天线配置的path ID|
|frequency_hz_a、frequency_hz_b|80或各自N×80|各端实际频点|

若两端确定共用同一网格，也可只提供`frequency_hz`。配对按event_id+path_id，不按行号或两个设备各自的本地时间戳。ID应包含session/epoch，避免计数器回绕后重复。不能直接将两个设备各自的天线本地索引当成同一个path。

先分别按频率排序，检查两端相同，再计算：

```text
z_two_way[k] = z_a[k] * z_b[k]
```

这里不对B取共轭；端点IQ表示法转换中的共轭只用于统一I±jQ约定。原TI权重需要双程相位，A×conj(B)可能抵消需要的传播相位。

默认`unmatched_policy=error`，遇到缺失配对时报错。显式改成`drop`时只使用交集，并在输出协议记录两端丢失记录数。频点必须完整、唯一、连续1MHz，不做隐式插值。

## 3. 单侧NPZ

字段与已合成NPZ相同，但`iq`是单程IQ。配置必须显式声明：

```json
{
  "input": {
    "kind": "single_npz",
    "path": "single.npz",
    "convention": "i_plus_jq",
    "adapter": "reciprocal_square"
  },
  "phase_calibration": {"status": "already_applied"}
}
```

此处先做H×H，再接入原TI权重。适用前提是正反向信道互易且端点响应差异已经处理。软件不会把单侧输入质量标为已验证，也不会将构造的第二路称为真实对端数据。

## IQ数值编码

默认`encoding=iq`接受复数或I/Q数对。若是TI原始Tone的32位打包字，使用`encoding=ti_tone_u32`（双端配置分别为`encoding_a`、`encoding_b`）：低12位为有符号I，接下来的12位为有符号Q。高位质量信息不参与IQ乘法；此解码不等于实现全部TI TQI/RPL处理。

## 相位校准状态

必须明确选择：

|status|处理|
|---|---|
|already_applied|不重复校准|
|apply_combined_bias|按已知bias计算z×exp(−j×bias)|
|uncalibrated|显式进行未校准输入推理，状态保留在输出协议|

`apply_combined_bias`默认读取NPZ的`combined_phase_bias_rad`。形状为80或N_A×80，单位rad，与A/输入端原始频点顺序一致；配对排序时同时重排。它是**合成后的总相位偏差**：双端分别为φ_a、φ_b时应使用φ_a+φ_b；单侧平方适配时应使用两倍的单程相位偏差。不得用当前测试距离拟合该数组再报告独立精度。

相位校准若已去掉固定硬件时延，后续是否仍应减0.94m需按该标定定义决定。project不自动推断两者关系。示例默认距离修正0；当前实车配置单独设为0.94m。

## 可选参考距离和元数据

`truth_m`、`anchor`、`condition`可为每输入/A端一行的数组，或可广播标量；`truth_m`应为3D斜距，未知用NaN。已合成/单侧输入还可提供`event_id`、`path_id`。双端的真值和元数据按A端行顺序提供，配对后随A端行一起重排。

没有truth_m也可以预测。真值仅用于最后统计，不参与配对、时域窗定位、特征或网络。

## 原有.log适配

该入口明确面向已合成并相位校准的80点日志，按已有key/path/iq_data行格式读取。它不将该.log格式的两条记录自动猜测为两个方向。未知厂商的双端日志，应先导出为上述明确字段的NPZ，不能凭相近时间强行配对。
