"""Generate one fixed shared scene per profile, with time-ordered 2x2 frames.

python generate_ble_mimo.py --scenario all --frames 16 --grid legacy80
"""
import argparse
from dataclasses import asdict
import json
from pathlib import Path

import numpy as np

from ble_channel_models import ChannelConfig, MeasurementConfig, SCENARIOS, tone_grid
from ble_mimo_channel import PAIRS, LOConfig, linear_arrays, ground_arrays, make_mimo_scene, make_schedule, make_lo_trace, measure_mimo
from ble_literature_channels import LITERATURE_SCENARIOS, add_channel_arguments, configured_channel


def _json_default(x):
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, complex):
        return dict(real=x.real, imag=x.imag)
    if isinstance(x, np.generic):
        return x.item()
    raise TypeError(type(x).__name__)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=(*SCENARIOS, "all", "literature"), default="all")
    parser.add_argument("--grid", choices=("legacy80", "ble72"), default="legacy80")
    parser.add_argument("--frames", type=int, default=16)
    parser.add_argument("--distance-m", type=float, default=8)
    parser.add_argument("--spacing-a-m", type=float, default=.05)
    parser.add_argument("--spacing-b-m", type=float, default=.05)
    parser.add_argument("--velocity-b-mps", type=float, nargs=3, default=[0, 0, 0])
    parser.add_argument("--layout", choices=("tone_major", "pair_major"), default="tone_major")
    parser.add_argument("--slot-us", type=float, default=20)
    parser.add_argument("--turn-us", type=float, default=40)
    parser.add_argument("--tone-gap-us", type=float, default=20)
    parser.add_argument("--frame-period-ms", type=float, default=50)
    parser.add_argument("--shuffle-tones", action="store_true")
    parser.add_argument("--shuffle-pairs", action="store_true")
    parser.add_argument("--snr-db", type=float, default=30)
    parser.add_argument("--snr-reference", choices=("unblocked","received"), default="unblocked")
    parser.add_argument("--phase-noise-std-deg", type=float, default=0.)
    add_channel_arguments(parser)
    parser.add_argument("--cfo-hz", type=float, default=0)
    parser.add_argument("--wiener-std", type=float, default=0)
    parser.add_argument("--seed", type=int, default=20261120)
    parser.add_argument("--output", type=Path, default=Path("outputs/ble_mimo_examples"))
    args = parser.parse_args()
    if args.frames < 1:
        parser.error("frames must be positive")
    if not np.isfinite(args.frame_period_ms) or args.frame_period_ms <= 0:
        parser.error("frame period must be positive")
    f = tone_grid(args.grid)
    schedules = [make_schedule(len(f), slot_s=args.slot_us*1e-6, turn_s=args.turn_us*1e-6,
                               tone_gap_s=args.tone_gap_us*1e-6, frame_start_s=n*args.frame_period_ms*.001,
                               layout=args.layout, random_tones=args.shuffle_tones,
                               random_pairs=args.shuffle_pairs, seed=args.seed+n) for n in range(args.frames)]
    if schedules[0].metadata["duration_s"] > args.frame_period_ms*.001:
        parser.error("frame period must cover the entire schedule; increase --frame-period-ms")
    lo = LOConfig(residual_cfo_hz=args.cfo_hz, wiener_std_rad_per_sqrt_s=args.wiener_std)
    # Shared trace preserves LO evolution across frames as well as across pairs.
    trace = make_lo_trace(schedules, lo, seed=args.seed+10)
    cfg_meas = MeasurementConfig(snr_db=args.snr_db, snr_reference=args.snr_reference,
                                 phase_noise_std_deg=args.phase_noise_std_deg)
    args.output.mkdir(parents=True, exist_ok=True)
    names = SCENARIOS if args.scenario == "all" else LITERATURE_SCENARIOS if args.scenario == "literature" else (args.scenario,)
    for name in names:
        a,b = (ground_arrays(args.distance_m,args.spacing_a_m,args.spacing_b_m,args.tx_height_m,args.rx_height_m)
               if name == "two_ray_ground" else linear_arrays(args.distance_m,args.spacing_a_m,args.spacing_b_m))
        b.velocity_mps = np.array(args.velocity_b_mps)
        config = configured_channel(args, name, args.distance_m)
        scene = make_mimo_scene(config, a, b, seed=args.seed)
        observations = [measure_mimo(scene, f, s, cfg_meas, lo, seed=args.seed+100+n, lo_trace=trace)
                        for n, s in enumerate(schedules)]
        iq = np.array([m.combined_iq for m in observations])
        forward = np.array([m.iq_forward for m in observations])
        reverse = np.array([m.iq_reverse for m in observations])
        truth = np.array([m.pair_truth_m for m in observations])
        center = np.array([m.center_truth_m for m in observations])
        mask = np.array([m.valid_mask for m in observations])
        target = args.output / f"{name}_mimo.npz"
        np.savez_compressed(target, iq=iq, iq_forward=forward, iq_reverse=reverse,
                            clean_forward=np.array([m.clean_forward for m in observations]),
                            clean_reverse=np.array([m.clean_reverse for m in observations]),
                            valid_mask=mask, frequency_hz=f, pair_indices=PAIRS,
                            pair_truth_m=truth, center_truth_m=center,
                            time_forward_s=np.array([s.time_forward_s for s in schedules]),
                            time_reverse_s=np.array([s.time_reverse_s for s in schedules]),
                            tone_order=np.array([s.tone_order for s in schedules]),
                            pair_order=np.array([s.pair_order for s in schedules]))
        common = dict(frequency_hz=f, truth_m=truth.mean(axis=2).reshape(-1),
                      condition=np.full(args.frames*4, name))
        event = np.repeat(np.arange(args.frames), 4)
        path = np.tile(np.arange(4), args.frames)
        np.savez_compressed(args.output/f"{name}_combined.npz", iq=iq.reshape(-1, len(f)),
                            event_id=event, path_id=path, **common)
        np.savez_compressed(args.output/f"{name}_paired.npz", iq_a=forward.reshape(-1, len(f)),
                            iq_b=reverse.reshape(-1, len(f)), event_id_a=event, event_id_b=event,
                            path_id_a=path, path_id_b=path, **common)
        if args.grid == "legacy80":
            for kind in ("combined", "paired"):
                spec = dict(kind=f"{kind}_npz", path=f"{name}_{kind}.npz")
                spec.update(dict(convention="i_plus_jq") if kind == "combined" else
                            dict(convention_a="i_plus_jq", convention_b="i_plus_jq", unmatched_policy="error"))
                ti = dict(input=spec, phase_calibration=dict(status="already_applied"),
                          inference=dict(windows=["none", "sdk"], distance_correction_m=0.0, batch_size=512))
                (args.output/f"{name}_{kind}_ti.json").write_text(json.dumps(ti, indent=2), encoding="utf-8")
        protocol = dict(channel=asdict(config), model_metadata=scene.metadata,
                        array_a=asdict(scene.array_a), array_b=asdict(scene.array_b),
                        rays=[asdict(r) for r in scene.rays], screen=asdict(scene.screen) if scene.screen else None,
                        schedule_defaults=schedules[0].metadata, measurement=asdict(cfg_meas), lo=asdict(lo),
                        seed=args.seed, frames=args.frames, shared_scene_all_frames=True,
                        common_LO_trace_all_frames=True, physical_pair_order=PAIRS,
                        calibrated_to_measured_array_geometry=False,
                        truth_definition="pair_truth_m per tone midpoint; flat TI truth is its mean over tones",
                        within_frame_motion_requires_per_tone_truth=True)
        target.with_suffix(".json").write_text(json.dumps(protocol, indent=2, default=_json_default), encoding="utf-8")
        print(target)


if __name__ == "__main__":
    main()
