"""Generate reproducible IQ data for all scenarios; no model training.

python generate_ble_channels.py --grid legacy80 --samples 100 --output outputs/channel_models
"""
import argparse
from dataclasses import asdict
import json
from pathlib import Path

import numpy as np

from ble_channel_models import ChannelConfig, MeasurementConfig, SCENARIOS, make_channel, measure, tone_grid
from ble_literature_channels import LITERATURE_SCENARIOS, add_channel_arguments, configured_channel


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=(*SCENARIOS, "all", "literature"), default="all")
    parser.add_argument("--grid", choices=("ble72", "legacy80"), default="legacy80")
    parser.add_argument("--samples", type=int, default=100)
    parser.add_argument("--distance-min", type=float, default=1.0)
    parser.add_argument("--distance-max", type=float, default=25.0)
    parser.add_argument("--snr-db", type=float, default=30.0)
    parser.add_argument("--snr-reference", choices=("unblocked","received"), default="unblocked")
    parser.add_argument("--phase-noise-std-deg", type=float, default=0.)
    add_channel_arguments(parser)
    parser.add_argument("--seed", type=int, default=20261120)
    parser.add_argument("--output", type=Path, default=Path("outputs/channel_models"))
    args = parser.parse_args()
    if args.samples <= 0 or not (np.isfinite(args.distance_min) and np.isfinite(args.distance_max) and 0 < args.distance_min <= args.distance_max):
        parser.error("samples must be positive and 0 < distance-min <= distance-max")
    rng = np.random.default_rng(args.seed)
    args.output.mkdir(parents=True, exist_ok=True)
    f = tone_grid(args.grid)
    measurement_cfg = MeasurementConfig(snr_db=args.snr_db, snr_reference=args.snr_reference,
                                        phase_noise_std_deg=args.phase_noise_std_deg)
    scenarios = SCENARIOS if args.scenario == "all" else LITERATURE_SCENARIOS if args.scenario == "literature" else (args.scenario,)
    for scenario in scenarios:
        distances = rng.uniform(args.distance_min, args.distance_max, args.samples)
        iq, iq_a, iq_b, clean, masks, seeds = [], [], [], [], [], []
        for distance in distances:
            channel_seed, measurement_seed = map(int, rng.integers(0, 2**32, 2))
            channel = make_channel(configured_channel(args, scenario, float(distance)), f, seed=channel_seed)
            observed = measure(channel, measurement_cfg, seed=measurement_seed)
            iq.append(observed.combined_iq)
            iq_a.append(observed.iq_a)
            iq_b.append(observed.iq_b)
            clean.append(channel.h)
            masks.append(observed.valid_mask)
            seeds.append((channel_seed, measurement_seed))
        target = args.output / f"{scenario}.npz"
        # combined_npz uses iq; paired_npz should use only iq_a/iq_b from a
        # separately selected archive, because the existing loader rejects
        # archives that mix combined and paired representations.
        np.savez_compressed(target, iq=np.asarray(iq), single_h=np.asarray(clean),
                            frequency_hz=f, truth_m=distances, valid_mask=np.asarray(masks),
                            condition=np.full(args.samples, scenario), seeds=np.asarray(seeds, dtype=np.uint64))
        np.savez_compressed(args.output / f"{scenario}_paired.npz", iq_a=np.asarray(iq_a), iq_b=np.asarray(iq_b),
                            frequency_hz=f, truth_m=distances,
                            event_id_a=np.arange(args.samples), event_id_b=np.arange(args.samples),
                            path_id_a=np.zeros(args.samples, int), path_id_b=np.zeros(args.samples, int),
                            valid_mask=np.asarray(masks), condition=np.full(args.samples, scenario))
        protocol = dict(channel_defaults=asdict(configured_channel(args, scenario)),
                        measurement=asdict(measurement_cfg), seed=args.seed, grid=args.grid,
                        samples=args.samples, distance_range_m=[args.distance_min, args.distance_max],
                        two_way_operation="Y_A * Y_B (no conjugation)", calibrated_to_measurements=False,
                        fitted_to_user_data=False, last_realization_metadata=channel.metadata)
        target.with_suffix(".json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
        if args.grid == "legacy80":
            for paired in (False, True):
                stem = f"{scenario}_paired" if paired else scenario
                spec = dict(kind="paired_npz" if paired else "combined_npz", path=f"{stem}.npz")
                if paired:
                    spec.update(convention_a="i_plus_jq", convention_b="i_plus_jq", unmatched_policy="error")
                else:
                    spec.update(convention="i_plus_jq")
                ti_config = dict(input=spec, phase_calibration=dict(status="already_applied"),
                                 inference=dict(windows=["none", "sdk"], distance_correction_m=0.0, batch_size=512))
                (args.output / f"{stem}_ti.json").write_text(json.dumps(ti_config, indent=2), encoding="utf-8")
        print(target)


if __name__ == "__main__":
    main()
