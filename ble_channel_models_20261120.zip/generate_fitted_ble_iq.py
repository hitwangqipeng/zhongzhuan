"""Generate reusable IQ from the exported effective LOS/NLOS channel profiles.

python generate_fitted_ble_iq.py --profiles outputs/ble_realcar_channel_fit_20261120/recommended_effective_profiles.json --condition NLOS
"""
import argparse
import json
from pathlib import Path
import numpy as np

from ble_channel_models import MeasurementConfig,tone_grid
from ble_channel_fit import load_fitted_scene
from ble_mimo_channel import PAIRS,make_schedule,measure_mimo


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--profiles",type=Path,required=True)
    p.add_argument("--condition",choices=("LOS","NLOS"),default="NLOS")
    p.add_argument("--scenes",type=int,default=16)
    p.add_argument("--frames-per-scene",type=int,default=4)
    p.add_argument("--distance-min",type=float,default=3)
    p.add_argument("--distance-max",type=float,default=30)
    p.add_argument("--include-range-offset",action="store_true")
    p.add_argument("--seed",type=int,default=20261120)
    p.add_argument("--output",type=Path,default=Path("outputs/ble_fitted_iq"))
    args=p.parse_args()
    if min(args.scenes,args.frames_per_scene)<1 or not 0<args.distance_min<=args.distance_max:
        p.error("invalid sample counts or distance range")
    args.output.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(args.seed)
    distances=rng.uniform(args.distance_min,args.distance_max,args.scenes)
    f=tone_grid("legacy80")
    schedules=[make_schedule(80,frame_start_s=.05*n,random_tones=True,random_pairs=True,seed=args.seed+n)
               for n in range(args.frames_per_scene)]
    combined=[];forward=[];reverse=[];truth=[]
    for i,d in enumerate(distances):
        scene,profile=load_fitted_scene(args.profiles,args.condition,float(d),seed=args.seed+100*i,
                                        include_effective_range_offset=args.include_range_offset)
        observations=[measure_mimo(scene,f,s,MeasurementConfig(snr_db=profile["parameters"]["snr_db"],
                                   phase_noise_std_deg=profile["parameters"].get("phase_noise_std_deg",0)),
                                   seed=args.seed+100*i+n+1) for n,s in enumerate(schedules)]
        combined.append([o.combined_iq for o in observations])
        forward.append([o.iq_forward for o in observations])
        reverse.append([o.iq_reverse for o in observations])
        truth.append([o.pair_truth_m for o in observations])
    target=args.output/f"fitted_{args.condition}.npz"
    np.savez_compressed(target,iq=np.array(combined),iq_forward=np.array(forward),iq_reverse=np.array(reverse),
                        pair_truth_m=np.array(truth),center_truth_m=distances,frequency_hz=f,pair_indices=PAIRS,
                        time_forward_s=np.array([s.time_forward_s for s in schedules]),
                        time_reverse_s=np.array([s.time_reverse_s for s in schedules]))
    flat=target.with_name(f"fitted_{args.condition}_combined.npz")
    count=args.scenes*args.frames_per_scene
    np.savez_compressed(flat,iq=np.array(combined).reshape(-1,80),frequency_hz=f,
                        truth_m=np.array(truth).mean(axis=-1).reshape(-1),
                        event_id=np.repeat(np.arange(count),4),path_id=np.tile(np.arange(4),count),
                        condition=np.full(count*4,args.condition))
    ti=dict(input=dict(kind="combined_npz",path=flat.name,convention="i_plus_jq"),
            phase_calibration=dict(status="already_applied"),
            inference=dict(windows=["none","sdk"],distance_correction_m=0.,batch_size=512))
    target.with_name(f"fitted_{args.condition}_ti.json").write_text(json.dumps(ti,indent=2),encoding="utf-8")
    protocol=dict(profile_file=str(args.profiles.resolve()),profile=profile,seed=args.seed,
                  scenes=args.scenes,frames_per_scene=args.frames_per_scene,
                  include_effective_range_offset=args.include_range_offset,
                  raw_measured_IQ_used=False,physical_geometry_identified=False,
                  shape="scene x frame x four antenna pairs x 80 tones",
                  times="schedule timestamps repeat for independent scenes")
    target.with_suffix(".json").write_text(json.dumps(protocol,indent=2),encoding="utf-8")
    print(target)


if __name__=="__main__":main()
