"""Illustrative numerical plots, not measured-data validation or new fitting."""
import argparse
import csv
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

from ble_channel_models import C, ChannelConfig, make_channel, tone_grid, to_cir
from ble_literature_channels import LITERATURE_SCENARIOS, exponential_profile, tgn_profile


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output",type=Path,default=Path("outputs/ble_literature_validation_20261123"))
    parser.add_argument("--seed",type=int,default=42)
    args=parser.parse_args()
    args.output.mkdir(parents=True,exist_ok=True)
    f=tone_grid("legacy80")
    channels={name:make_channel(ChannelConfig(scenario=name),f,seed=args.seed)
              for name in LITERATURE_SCENARIOS}
    fig,axs=plt.subplots(2,2,figsize=(13,9),constrained_layout=True)
    for key in "bcdef":
        t,p,*_=tgn_profile(key)
        axs[0,0].plot(t,10*np.log10(p),".-",label=f"TGn {key.upper()}")
    t,p=exponential_profile()
    axs[0,0].plot(t,10*np.log10(p),"--",label="Exponential, decay=50 ns")
    axs[0,0].set(xlabel="One-way excess delay (ns)",ylabel="Expected tap power (dB)",
                 title="Tabulated / exponential SISO PDPs")
    axs[0,0].legend(fontsize=8,ncol=2)

    meta=channels["sv_2p4ghz"].metadata
    t=np.asarray(meta["excess_delay_ns"])
    p=np.asarray(meta["expected_tap_power"])
    ids=np.asarray(meta["cluster_ids"])
    for cluster in np.unique(ids):
        use=ids==cluster
        axs[0,1].vlines(t[use],-65,10*np.log10(p[use]),color=plt.get_cmap("tab10")(int(cluster)%10),
                       label=f"Cluster {cluster}")
    axs[0,1].set(xlabel="One-way excess delay (ns)",ylabel="Conditional expected ray power (dB)",
                 ylim=(-65,0),title="Measured-parameter S-V: one sampled arrival pattern")
    axs[0,1].legend(fontsize=8,ncol=2)

    d=np.geomspace(1,400,900)
    fc=2.454e9
    ground=[]
    for distance in d:
        ch=make_channel(ChannelConfig(scenario="two_ray_ground",distance_m=float(distance)),[fc,fc+1])
        ground.append(ch.h[0])
    friis=C/(4*np.pi*fc*d)
    axs[1,0].plot(d,20*np.log10(friis),"--",label="Free space")
    axs[1,0].plot(d,20*np.log10(np.maximum(np.abs(ground)*friis,1e-15)),label="Ground two-ray")
    axs[1,0].set(xlabel="Direct/slant distance (m)",ylabel="Isotropic channel power gain (dB)",
                 title="Illustration at 2454 MHz, heights 1 m, epsilon_r=2.5")
    axs[1,0].legend(fontsize=8)

    for name in ("exponential_pdp","sv_2p4ghz","tgn_d","two_ray_ground"):
        ch=channels[name]
        axis,cir=to_cir(f,ch.h**2,nfft=2048)
        magnitude=abs(cir)
        axs[1,1].plot(axis,20*np.log10(np.maximum(magnitude/magnitude.max(),1e-5)),label=name)
    axs[1,1].set(xlabel="Two-way range axis (m)",ylabel="Normalized CIR magnitude (dB)",
                 xlim=(0,60),ylim=(-50,1),title="One clean combined-IQ realization, true range 8 m")
    axs[1,1].axvline(8,color="black",linestyle=":",linewidth=1)
    axs[1,1].legend(fontsize=8)
    for ax in axs.flat: ax.grid(alpha=.25)
    fig.suptitle("BLE-band literature channels: illustrative simulations, not measurements",fontsize=14)
    fig.savefig(args.output/"literature_channel_overview.png",dpi=160)
    plt.close(fig)
    rows=[]
    for name,ch in channels.items():
        rows.append(dict(scenario=name,taps=len(ch.taps),
            nominal_nlos_rms_ds_ns=ch.metadata.get("nominal_nlos_rms_delay_spread_ns"),
            actual_expected_pdp_rms_ds_ns=ch.metadata.get("rms_delay_spread_ns"),
            source_url=ch.metadata["source_url"],fitted_to_user_data=False))
    with (args.output/"model_inventory.csv").open("w",encoding="utf-8",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]))
        writer.writeheader();writer.writerows(rows)
    (args.output/"example_model_metadata.json").write_text(
        json.dumps({name:ch.metadata for name,ch in channels.items()},indent=2,allow_nan=False),encoding="utf-8")
    print(args.output)


if __name__ == "__main__": main()
