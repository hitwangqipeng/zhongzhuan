import unittest
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import numpy as np
from numpy.testing import assert_allclose

from ble_channel_fit import (FAMILIES,FEATURES,parameter_space,decode_parameters,draw_ensemble,
                             ensemble_field,ensemble_scene,iq_features,simulate_features,feature_scales,crps_by_file)
from fit_ble_realcar import folds_for_distances
from ble_channel_fit import load_fitted_scene


class FitTests(unittest.TestCase):
    def test_fast_generator_matches_physical_mimo_scene(self):
        f=2.4e9+np.arange(80)*1e6
        for family in FAMILIES:
            with self.subTest(family=family):
                p=decode_parameters(family,np.full(len(parameter_space(family)),.5))
                e=draw_ensemble(family,p,n=3,seed=4)
                fast=ensemble_field(e,f)
                for i in range(3):
                    assert_allclose(fast[i],ensemble_scene(e,i).response(f),atol=2e-11)

    def test_features_invariant_to_global_gain_phase_and_integer_cir_shift(self):
        rng=np.random.default_rng(4)
        z=rng.normal(size=(3,4,80))+1j*rng.normal(size=(3,4,80))
        f0=iq_features(z)
        z1=z*3*np.exp(1.3j)*np.exp(-2j*np.pi*np.arange(80)*3/512)
        f1=iq_features(z1)
        assert_allclose(f0[:,:11],f1[:,:11],atol=2e-12)

    def test_crps_proper_for_degenerate_perfect_prediction(self):
        x=np.ones((4,len(FEATURES)))
        scales=feature_scales(x)
        assert_allclose(crps_by_file(x,x,scales),0,atol=1e-12)
        self.assertTrue(np.all(crps_by_file(x+1,x,scales)>0))

    def test_distance_groups_never_split(self):
        distances=[1,3,5,7,10,15,20,25]
        folds=folds_for_distances(distances)
        self.assertEqual(sorted(v for fold in folds for v in fold),distances)
        for i in range(4):
            for j in range(i+1,4):
                self.assertFalse(folds[i]&folds[j])

    def test_simulation_finite_reproducible_and_four_path_product(self):
        p=decode_parameters("exponential_diffuse",np.full(5,.5))
        a=simulate_features("exponential_diffuse",p,n=8,seed=7)
        b=simulate_features("exponential_diffuse",p,n=8,seed=7)
        assert_allclose(a,b,atol=0,rtol=0)
        self.assertEqual(a.shape,(8,len(FEATURES)))
        self.assertTrue(np.isfinite(a).all())

    def test_phase_only_impairment_changes_cir_without_changing_envelope(self):
        p=decode_parameters("two_ray",np.full(5,.5))
        p["snr_db"]=np.inf
        a=simulate_features("two_ray",p,n=8,seed=7)
        p["phase_noise_std_deg"]=20
        b=simulate_features("two_ray_phase",p,n=8,seed=7)
        assert_allclose(a[:,:3],b[:,:3],atol=2e-13)
        self.assertGreater(b[:,7].mean(),a[:,7].mean())

    def test_effective_offset_is_hardware_phase_not_changed_geometry(self):
        p=decode_parameters("two_ray",np.full(5,.5))
        profile={"NLOS":dict(family="two_ray",parameters=p,effective_range_offset_m=3.)}
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/"profiles.json";path.write_text(json.dumps(profile))
            a,_=load_fitted_scene(path,"NLOS",8,seed=3)
            b,_=load_fitted_scene(path,"NLOS",8,seed=3,include_effective_range_offset=True)
            f=2.4e9+np.arange(80)*1e6
            assert_allclose(b.response(f),a.response(f)*np.exp(-2j*np.pi*f*3/299792458),atol=2e-12)
            assert_allclose(a.array_a.positions_m,b.array_a.positions_m)
            assert_allclose(a.array_b.positions_m,b.array_b.positions_m)

    def test_exported_profile_generator_end_to_end(self):
        family="two_ray_phase"
        p=decode_parameters(family,np.full(len(parameter_space(family)),.5))
        profile={"NLOS":dict(family=family,parameters=p,effective_range_offset_m=2.)}
        root=Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as tmp:
            path=Path(tmp)/"profiles.json";path.write_text(json.dumps(profile))
            subprocess.run([sys.executable,str(root/"generate_fitted_ble_iq.py"),"--profiles",str(path),
                            "--condition","NLOS","--scenes","2","--frames-per-scene","2","--output",tmp],
                           check=True,capture_output=True)
            with np.load(Path(tmp)/"fitted_NLOS.npz") as z:
                self.assertEqual(z["iq"].shape,(2,2,4,80))
                assert_allclose(z["iq"],z["iq_forward"]*z["iq_reverse"])
            with np.load(Path(tmp)/"fitted_NLOS_combined.npz") as z:
                self.assertEqual(z["iq"].shape,(16,80))
                self.assertEqual(z["truth_m"].shape,(16,))


if __name__=="__main__":unittest.main()
