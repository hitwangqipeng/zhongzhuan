"""Physics checks and export integration; python -m unittest discover -s tests -p test_ble_channel_models.py."""
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np
from numpy.testing import assert_allclose

from ble_channel_models import (C, SCENARIOS, ChannelConfig, MeasurementConfig, Tap,
                                knife_edge_coefficient, make_channel, measure, to_cir, tone_grid)


class ChannelTests(unittest.TestCase):
    def test_fresnel_limits(self):
        assert_allclose(knife_edge_coefficient(0), .5)
        self.assertLess(abs(knife_edge_coefficient(100)), .004)
        self.assertLess(abs(knife_edge_coefficient(-100) - 1), .004)

    def test_direct_two_way_phase_slope(self):
        ch = make_channel(ChannelConfig(distance_m=7.25), tone_grid("legacy80"))
        m = measure(ch, MeasurementConfig(snr_db=np.inf), seed=1)
        assert_allclose(m.combined_iq, np.exp(-4j * np.pi * ch.frequency_hz * 7.25 / C), atol=1e-12)
        slope = np.polyfit(ch.frequency_hz - ch.frequency_hz[0], np.unwrap(np.angle(m.combined_iq)), 1)[0]
        self.assertAlmostEqual(-slope * C / (4 * np.pi), 7.25, places=10)

    def test_multipath_retains_cross_terms(self):
        ch = make_channel(ChannelConfig(scenario="static_multipath"))
        a, b = (tap.response(ch.frequency_hz) for tap in ch.taps)
        m = measure(ch, MeasurementConfig(snr_db=np.inf), seed=3)
        assert_allclose(m.combined_iq, a*a + 2*a*b + b*b, atol=1e-12)
        self.assertGreater(np.linalg.norm(m.combined_iq - (a*a + b*b)), 1)

    def test_diffraction_has_no_double_extra_delay(self):
        f = tone_grid()
        d, excess = 8.0, .1
        tap = Tap(d + excess, .9, "edge", excess)
        expected = .9 * knife_edge_coefficient(np.sqrt(4 * excess * f / C)) * np.exp(-2j * np.pi * f * d / C)
        assert_allclose(tap.response(f), expected, atol=2e-13)

    def test_knife_edge_magnitude_decreases_in_shadow(self):
        magnitude = abs(knife_edge_coefficient(np.linspace(0, 10, 101)))
        self.assertTrue(np.all(np.diff(magnitude) < 0))

    def test_blockage_is_not_normalized_away(self):
        for scenario in ("human_blockage", "car_blockage"):
            with self.subTest(scenario=scenario):
                ch = make_channel(ChannelConfig(scenario=scenario))
                self.assertLess(np.mean(abs(ch.h)**2), .5)
                self.assertTrue(ch.metadata["blocked"])
                self.assertTrue(all(t.length_m >= ch.distance_m for t in ch.taps))

    def test_outside_obstacle_recovers_direct(self):
        for scenario in ("human_blockage", "car_blockage"):
            ch = make_channel(ChannelConfig(scenario=scenario, lateral_offset_m=3))
            ideal = make_channel(ChannelConfig())
            assert_allclose(ch.h, ideal.h)
            self.assertFalse(ch.metadata["blocked"])

    def test_garage_can_have_no_direct(self):
        cfg = ChannelConfig(scenario="garage", garage_direct_present=False)
        ch = make_channel(cfg, seed=4)
        self.assertTrue(all(t.length_m > cfg.distance_m for t in ch.taps))
        self.assertFalse(any(t.label == "direct" for t in ch.taps))

    def test_reproducibility(self):
        cfg = ChannelConfig(scenario="garage")
        a, b, c = (make_channel(cfg, seed=s) for s in (1, 1, 2))
        assert_allclose(a.h, b.h, atol=0, rtol=0)
        self.assertGreater(np.linalg.norm(a.h - c.h), 1)
        x, y = (measure(a, seed=2) for _ in range(2))
        assert_allclose(x.combined_iq, y.combined_iq, atol=0, rtol=0)
        self.assertFalse(np.array_equal(x.iq_a, x.iq_b))

    def test_noise_reference_preserves_blockage_snr_loss(self):
        clear = make_channel(ChannelConfig())
        blocked = make_channel(ChannelConfig(scenario="car_blockage"))
        a, b = measure(clear, seed=8), measure(blocked, seed=8)
        self.assertEqual(a.noise_power_per_endpoint, b.noise_power_per_endpoint)
        received = measure(blocked, MeasurementConfig(snr_reference="received"), seed=8)
        self.assertLess(received.noise_power_per_endpoint, b.noise_power_per_endpoint)

    def test_awgn_power(self):
        ch = make_channel(ChannelConfig())
        residual = np.concatenate([measure(ch, seed=i).iq_a - ch.h for i in range(300)])
        self.assertAlmostEqual(np.mean(abs(residual)**2) / .001, 1.0, delta=.025)

    def test_sparse_grid_cir_preserves_range(self):
        for grid in ("ble72", "legacy80"):
            with self.subTest(grid=grid):
                ch = make_channel(ChannelConfig(distance_m=9), tone_grid(grid))
                distance, cir = to_cir(ch.frequency_hz, ch.h**2, nfft=4096)
                self.assertLess(abs(distance[np.argmax(abs(cir))] - 9), distance[1] / 2 + 1e-8)
                single_distance, single_cir = to_cir(ch.frequency_hz, ch.h, nfft=4096, round_trip=False)
                self.assertLess(abs(single_distance[np.argmax(abs(single_cir))] - 9), single_distance[1] / 2 + 1e-8)

    def test_missing_tones_explicit_mask(self):
        ch = make_channel(ChannelConfig())
        m = measure(ch, MeasurementConfig(missing_probability=.3), seed=5)
        self.assertGreater(m.valid_mask.sum(), 0)
        self.assertLess(m.valid_mask.sum(), len(ch.h))
        assert_allclose(m.combined_iq[~m.valid_mask], 0)
        assert_allclose(m.combined_iq, m.iq_a * m.iq_b)

    def test_validation(self):
        bad = [ChannelConfig(distance_m=-1), ChannelConfig(scenario="unknown"),
               ChannelConfig(scenario="human_blockage", obstacle_fraction=1),
               ChannelConfig(scenario="car_blockage", car_width_m=-1),
               ChannelConfig(scenario="garage", garage_decay_ns=0)]
        for cfg in bad:
            with self.assertRaises(ValueError):
                make_channel(cfg)
        with self.assertRaises(ValueError):
            to_cir([2.4e9, 2.4005e9], [1, 1])
        with self.assertRaises(ValueError):
            measure(make_channel(ChannelConfig()), MeasurementConfig(snr_db=np.nan))

    def test_export_and_existing_ti_loader(self):
        root = Path(__file__).resolve().parents[1]
        if not (root / "ti_ble_ranging_project" / "src").is_dir():
            self.skipTest("TI integration requires the existing Ranging/ti_ble_ranging_project")
        with tempfile.TemporaryDirectory() as tmp:
            subprocess.run([sys.executable, str(root / "generate_ble_channels.py"), "--samples", "3",
                            "--grid", "legacy80", "--output", tmp], check=True, capture_output=True)
            sys.path.insert(0, str(root / "ti_ble_ranging_project" / "src"))
            try:
                from ble_ti_ranging.inputs import load_case
                for scenario in SCENARIOS:
                    _, combined = load_case(Path(tmp) / f"{scenario}_ti.json")
                    _, paired = load_case(Path(tmp) / f"{scenario}_paired_ti.json")
                    self.assertEqual(combined.iq.shape, (3, 80))
                    assert_allclose(combined.iq, paired.iq)
                    assert_allclose(combined.truth_m, paired.truth_m)
            finally:
                sys.path.pop(0)


if __name__ == "__main__":
    unittest.main()
