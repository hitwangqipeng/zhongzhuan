"""Numerical/ensemble oracles for literature channels, no measured-data fitting."""
from dataclasses import replace
from pathlib import Path
import json
import subprocess
import sys
import tempfile
import unittest

import numpy as np
from numpy.testing import assert_allclose

from ble_channel_models import C, ChannelConfig, MeasurementConfig, SCENARIOS, make_channel, measure, tone_grid
from ble_literature_channels import (GroundReflection, LITERATURE_SCENARIOS, TGN_TABLES,
                                     exponential_profile, sv_profile, tgn_profile, profile_moments)
from ble_mimo_channel import (AntennaArray, MIMOScene, Ray, PAIRS, ground_arrays, linear_arrays,
                              make_mimo_scene, make_schedule, measure_mimo)


class LiteratureTests(unittest.TestCase):
    def setUp(self):
        self.f = tone_grid("legacy80")

    def test_published_tgn_tables_and_linear_overlap(self):
        # Independent transcription: B, Appendix C printed page 35. In
        # particular tap 20 ns combines TWO clusters, not one selected row.
        t,p,db,ds,k = tgn_profile("b")
        a = np.array([0.,-5.4,-10.8,-16.2,-21.7,-np.inf,-np.inf,-np.inf,-np.inf])
        b = np.array([-np.inf,-np.inf,-3.2,-6.3,-9.4,-12.5,-15.6,-18.7,-21.8])
        oracle = 10**(a/10)+10**(b/10)
        assert_allclose(p,oracle/oracle.sum(),rtol=1e-14)
        assert_allclose(t,np.arange(9)*10)
        for key,ntaps,nclusters,end,nominal in zip("bcdef",[9,14,18,18,18],[2,2,3,4,6],
                                                 [80,200,390,730,1050],[15,30,50,100,150]):
            t,p,db,ds,k = tgn_profile(key)
            self.assertEqual(len(t),ntaps)
            self.assertEqual(db.shape,(nclusters,ntaps))
            self.assertEqual(t[-1],end)
            self.assertEqual(ds,nominal)
            self.assertAlmostEqual(p.sum(),1.)
            self.assertTrue(np.all(p>0))
            self.assertLess(abs(profile_moments(t,p)["rms_delay_spread_ns"]-nominal),4.)
        # Nonzero starts verified from original table column coordinates.
        self.assertTrue(np.isneginf(tgn_profile("d")[2][1,:10]).all())
        self.assertTrue(np.isneginf(tgn_profile("f")[2][-1,:16]).all())

    def test_exponential_pdp_power_not_amplitude_decay(self):
        t,p = exponential_profile(50,5,40)
        assert_allclose(p[1:]/p[:-1],np.exp(-.1),rtol=1e-14)
        self.assertAlmostEqual(p.sum(),1.)
        self.assertLess(abs(profile_moments(t,p)["rms_delay_spread_ns"]-50),.3)

    def test_ensemble_tap_powers_no_sample_agc(self):
        for name in ("exponential_pdp","tgn_d"):
            cfg = ChannelConfig(scenario=name)
            channels = [make_channel(cfg,self.f,seed=i) for i in range(1400)]
            gains = np.array([[t.gain for t in ch.taps] for ch in channels])
            expected = np.array(channels[0].metadata["expected_tap_power"])
            assert_allclose(np.mean(abs(gains)**2,axis=0),expected,rtol=.12,atol=.0001)
            self.assertGreater(np.std(np.sum(abs(gains)**2,axis=1)),.1)
            # A frequency-domain ensemble average has total expected power one.
            self.assertAlmostEqual(float(np.mean([abs(ch.h)**2 for ch in channels])),1.,delta=.05)

    def test_tgn_los_k_is_first_tap_and_added_before_normalizing(self):
        cfg = ChannelConfig(scenario="tgn_d",tgn_los=True)
        channels = [make_channel(cfg,self.f,seed=i) for i in range(1800)]
        g = np.array([[tap.gain for tap in ch.taps] for ch in channels])
        m = channels[0].metadata
        deterministic = np.sqrt(m["specular_expected_power"])
        self.assertAlmostEqual(g[:,0].mean().real,deterministic,delta=.02)
        self.assertAlmostEqual(g[:,0].mean().imag,0.,delta=.02)
        p0 = m["diffuse_expected_power"][0]
        self.assertAlmostEqual(m["specular_expected_power"]/p0,10**(.3))
        self.assertAlmostEqual(float(np.mean(abs(g[:,0]-deterministic)**2)),p0,delta=.01)
        assert_allclose(np.mean(abs(g[:,1:])**2,axis=0),m["diffuse_expected_power"][1:],rtol=.12)
        self.assertLess(abs(g[:,1:].mean()),.01)

    def test_sv_arrivals_and_power_law(self):
        counts=[]
        survival=[]
        first_ray_gaps=[]
        for seed in range(900):
            t,p,ids,clusters = sv_profile(np.random.default_rng(seed))
            counts.append(len(clusters))
            survival.append(len(clusters)==1 or clusters[1]>130.)
            c0=t[ids==0]
            if len(c0)>1:
                first_ray_gaps.append(c0[1])
            self.assertEqual(t[0],0.)
            self.assertTrue(np.all(np.diff(t)>=0))
            self.assertLessEqual(t[-1],400.)
            raw=np.exp(-clusters[ids]/35.6-(t-clusters[ids])/36.5)
            assert_allclose(p,raw/raw.sum(),rtol=1e-13)
        self.assertAlmostEqual(np.mean(counts),1+400/130,delta=.22)
        self.assertAlmostEqual(np.mean(survival),np.exp(-1),delta=.05)
        self.assertAlmostEqual(np.mean(first_ray_gaps),7.,delta=.65)

    def test_fresnel_limits_brewster_and_passivity(self):
        root=np.sqrt(2.5)
        v,h = GroundReflection(),GroundReflection(polarization="horizontal")
        assert_allclose(v.coefficient(self.f,1),(root-1)/(root+1),atol=1e-14)
        assert_allclose(h.coefficient(self.f,1),-(root-1)/(root+1),atol=1e-14)
        assert_allclose(v.coefficient(self.f,0),-1.,atol=1e-14)
        assert_allclose(v.coefficient(self.f,1/np.sqrt(3.5)),0.,atol=1e-14)
        assert_allclose(GroundReflection(1.).coefficient(self.f,0),0.)
        for pol in ("vertical","horizontal"):
            r=GroundReflection(4.2,.015,pol).coefficient(self.f,np.linspace(0,1,len(self.f)))
            self.assertTrue(np.isfinite(r).all())
            self.assertTrue(np.all(abs(r)<=1+1e-12))

    def test_two_ray_complex_geometry_oracle_and_far_distance_law(self):
        cfg=ChannelConfig(scenario="two_ray_ground",distance_m=8.,tx_height_m=.7,rx_height_m=1.2)
        ch=make_channel(cfg,self.f)
        length=np.sqrt(8**2+4*.7*1.2)
        coeff=GroundReflection().coefficient(self.f,1.9/length)
        oracle=np.exp(-2j*np.pi*self.f*8/C)+coeff*8/length*np.exp(-2j*np.pi*self.f*length/C)
        assert_allclose(ch.h,oracle,atol=1e-13)
        powers=[]
        for d in (2000.,4000.):
            h=make_channel(replace(cfg,distance_m=d),self.f).h
            powers.append(float(np.mean(abs(h/d)**2)))
        self.assertAlmostEqual(powers[0]/powers[1],16.,delta=.12)

    def test_scalar_and_coincident_mimo_agree_for_every_new_profile(self):
        for name in LITERATURE_SCENARIOS:
            for onset in (0.,8.) if name=="sv_2p4ghz" else (0.,):
                cfg=ChannelConfig(scenario=name,excess_onset_ns=onset)
                a,b=ground_arrays(8,0,0) if name=="two_ray_ground" else linear_arrays(8,0,0)
                scene=make_mimo_scene(cfg,a,b,seed=21)
                scalar=make_channel(cfg,self.f,seed=21)
                assert_allclose(scene.response(self.f),np.tile(scalar.h,(4,1)),atol=3e-11)

    def test_ground_reflection_is_recomputed_at_each_tdm_time(self):
        cfg=ChannelConfig(scenario="two_ray_ground")
        a,b=ground_arrays(8,.04,.06)
        b.velocity_mps=np.array([.7,.1,.2])
        scene=make_mimo_scene(cfg,a,b)
        times=np.tile(np.linspace(0,.02,len(self.f)),(4,1))
        got=scene.response(self.f,times)
        for q,(i,j) in enumerate(PAIRS):
            aa=a.at(i,times[q]); bb=b.at(j,times[q])
            direct=np.linalg.norm(bb-aa,axis=1)
            reflected=np.sqrt(np.sum((aa[:,:2]-bb[:,:2])**2,axis=1)+(aa[:,2]+bb[:,2])**2)
            r=GroundReflection().coefficient(self.f,(aa[:,2]+bb[:,2])/reflected)
            expected=8/direct*np.exp(-2j*np.pi*self.f*direct/C)+r*8/reflected*np.exp(-2j*np.pi*self.f*reflected/C)
            assert_allclose(got[q],expected,atol=2e-12)

    def test_reciprocal_square_excess_delay_and_seed(self):
        for name in LITERATURE_SCENARIOS:
            cfg=ChannelConfig(scenario=name)
            ch=make_channel(cfg,self.f,seed=12)
            assert_allclose(ch.h,make_channel(cfg,self.f,seed=12).h,atol=0,rtol=0)
            iq=measure(ch,MeasurementConfig(snr_db=np.inf),seed=1)
            assert_allclose(iq.combined_iq,ch.h**2,atol=1e-13)
            if name != "two_ray_ground":
                shifted=make_channel(replace(cfg,excess_onset_ns=7.),self.f,seed=12)
                assert_allclose(shifted.h,ch.h*np.exp(-2j*np.pi*self.f*7e-9),atol=5e-12)
                self.assertEqual(shifted.distance_m,ch.distance_m)
        # Newly added fields must not change old scene generation.
        for name in ("free_space","static_multipath","human_blockage","car_blockage","garage"):
            cfg=ChannelConfig(scenario=name)
            assert_allclose(make_channel(cfg,self.f,seed=12).h,
                            make_channel(replace(cfg,exp_decay_ns=80),self.f,seed=12).h,atol=0,rtol=0)

    def test_invalid_model_parameters_and_heights(self):
        invalid=[ChannelConfig(scenario="sv_2p4ghz",sv_ray_interval_ns=0),
                 ChannelConfig(scenario="exponential_pdp",exp_step_ns=-1),
                 ChannelConfig(scenario="tgn_b",tgn_los="yes"),
                 ChannelConfig(scenario="tgn_c",excess_onset_ns=-1),
                 ChannelConfig(scenario="two_ray_ground",distance_m=.1,tx_height_m=2),
                 ChannelConfig(scenario="two_ray_ground",ground_relative_permittivity=.5)]
        for cfg in invalid:
            with self.assertRaises(ValueError): make_channel(cfg,self.f)
        with self.assertRaises(ValueError):
            make_mimo_scene(ChannelConfig(scenario="two_ray_ground"),*linear_arrays(8))
        with self.assertRaises(ValueError):
            GroundReflection(polarization="unknown").coefficient(self.f,.5)
        with self.assertRaises(ValueError):
            exponential_profile(50,1e-8)

    def test_metadata_exportable_as_strict_json(self):
        for name in LITERATURE_SCENARIOS:
            ch=make_channel(ChannelConfig(scenario=name),self.f,seed=1)
            json.dumps(ch.metadata,allow_nan=False)
            self.assertFalse(ch.metadata["fitted_to_user_data"])
            self.assertTrue(ch.metadata["source_url"].startswith("https://"))

    def test_cli_exports_literature_and_tdm_ground_and_existing_loader(self):
        root=Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as tmp:
            target=Path(tmp)
            subprocess.run([sys.executable,str(root/"generate_ble_channels.py"),"--scenario","literature",
                            "--samples","2","--output",str(target/"scalar")],check=True,capture_output=True)
            subprocess.run([sys.executable,str(root/"generate_ble_mimo.py"),"--scenario","two_ray_ground",
                            "--frames","2","--tx-height-m",".7","--rx-height-m","1.2",
                            "--output",str(target/"mimo")],check=True,capture_output=True)
            for name in LITERATURE_SCENARIOS:
                with np.load(target/"scalar"/f"{name}.npz") as z:
                    self.assertEqual(z["iq"].shape,(2,80))
                    self.assertTrue(np.isfinite(z["iq"]).all())
            with np.load(target/"mimo"/"two_ray_ground_mimo.npz") as z:
                self.assertEqual(z["iq"].shape,(2,4,80))
                assert_allclose(z["iq"],z["iq_forward"]*z["iq_reverse"])
            if (root/"ti_ble_ranging_project/src").is_dir():
                sys.path.insert(0,str(root/"ti_ble_ranging_project/src"))
                try:
                    from ble_ti_ranging.inputs import load_case
                    for name in LITERATURE_SCENARIOS:
                        _,combined=load_case(target/"scalar"/f"{name}_ti.json")
                        _,paired=load_case(target/"scalar"/f"{name}_paired_ti.json")
                        assert_allclose(combined.iq,paired.iq)
                    _,combined=load_case(target/"mimo"/"two_ray_ground_combined_ti.json")
                    self.assertEqual(combined.iq.shape,(8,80))
                finally: sys.path.pop(0)


if __name__ == "__main__":
    unittest.main()
