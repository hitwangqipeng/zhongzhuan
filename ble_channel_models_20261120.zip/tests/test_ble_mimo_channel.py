from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

import numpy as np
from numpy.testing import assert_allclose
from scipy.special import j0

from ble_channel_models import C, ChannelConfig, MeasurementConfig, make_channel, tone_grid
from ble_mimo_channel import (AntennaArray, Ray, MIMOScene, TDMSchedule, LOConfig, PAIRS,
                              linear_arrays, make_mimo_scene, make_schedule, make_lo_trace, measure_mimo)
from analyze_ble_mimo_iq import complete_frames, spectral_similarity


class MIMOTests(unittest.TestCase):
    def setUp(self):
        self.f = tone_grid("legacy80")
        self.no_noise = MeasurementConfig(snr_db=np.inf)

    def test_exact_free_space_lengths(self):
        a, b = linear_arrays(8, .04, .07)
        scene = MIMOScene(a, b)
        expected = []
        for i, j in PAIRS:
            length = np.linalg.norm(b.positions_m[j]-a.positions_m[i])
            expected.append(8/length * np.exp(-2j*np.pi*self.f*length/C))
        assert_allclose(scene.response(self.f), expected, atol=1e-12)

    def test_coincident_antennas_recover_all_scalar_profiles(self):
        for name in ("free_space", "static_multipath", "garage", "human_blockage", "car_blockage"):
            with self.subTest(name=name):
                cfg = ChannelConfig(scenario=name)
                a, b = linear_arrays(8, 0, 0)
                scene = make_mimo_scene(cfg, a, b, seed=18)
                ref = make_channel(cfg, self.f, seed=18)
                assert_allclose(scene.response(self.f), np.tile(ref.h, (4, 1)), atol=3e-12)

    def test_explicit_scatterer_polyline(self):
        a, b = linear_arrays(8)
        vertex = np.array([[2., 1., 1.], [6., 2., .5]])
        scene = MIMOScene(a, b, [Ray(gain=.7j, vertices_m=vertex)])
        length = np.linalg.norm(a.positions_m[0]-vertex[0])+np.linalg.norm(vertex[1]-vertex[0])+np.linalg.norm(vertex[-1]-b.positions_m[1])
        assert_allclose(scene.response(self.f)[1], .7j*8/length*np.exp(-2j*np.pi*self.f*length/C), atol=1e-12)

    def test_spatial_continuity_and_fading(self):
        cfg = ChannelConfig(scenario="garage")
        a0, b0 = linear_arrays(8, 0, 0)
        h0 = make_mimo_scene(cfg, a0, b0, seed=3).response(self.f)
        a1, b1 = linear_arrays(8, 1e-8, 1e-8)
        h1 = make_mimo_scene(cfg, a1, b1, seed=3).response(self.f)
        assert_allclose(h0, h1, atol=3e-6)
        a2, b2 = linear_arrays(8, .05, .05)
        h2 = make_mimo_scene(cfg, a2, b2, seed=3).response(self.f)
        self.assertGreater(np.linalg.norm(h2[0]-h2[1]), .1)

    def test_isotropic_2d_spatial_correlation_j0_limit(self):
        # Independent published analytical oracle: isotropic azimuth field
        # has rho(delta)=J0(2*pi*delta/lambda). Use distant point scatterers.
        fc, spacing = 2.44e9, .03
        a, b = linear_arrays(8, 0, spacing)
        fields = []
        for phi in np.linspace(0, 2*np.pi, 256, endpoint=False):
            q = np.array([8+1000*np.cos(phi), 1000*np.sin(phi), 0])
            h = MIMOScene(a, b, [Ray(vertices_m=[q])]).response([fc])
            fields.append(h[:2, 0])
        fields = np.array(fields)
        rho = np.mean(fields[:, 0]*fields[:, 1].conj()) / np.sqrt(np.mean(abs(fields[:, 0])**2)*np.mean(abs(fields[:, 1])**2))
        self.assertAlmostEqual(rho.real, j0(2*np.pi*fc*spacing/C), delta=.002)
        self.assertAlmostEqual(rho.imag, 0, delta=.002)

    def test_static_reciprocal_square_and_cross_terms(self):
        scene = make_mimo_scene(ChannelConfig(scenario="static_multipath"), seed=4)
        obs = measure_mimo(scene, self.f, measurement=self.no_noise)
        assert_allclose(obs.combined_iq, scene.response(self.f)**2, atol=1e-12)

    def test_thermal_noise_independent_for_coincident_pairs(self):
        a, b = linear_arrays(8, 0, 0)
        scene = MIMOScene(a, b)
        obs = measure_mimo(scene, self.f, seed=1)
        n = obs.iq_forward-obs.clean_forward
        self.assertFalse(np.array_equal(n[0], n[1]))
        self.assertFalse(np.array_equal(obs.iq_forward, obs.iq_reverse))
        assert_allclose(obs.combined_iq, obs.iq_forward*obs.iq_reverse)

    def test_constant_differential_lo_phase_cancels(self):
        scene = make_mimo_scene(ChannelConfig())
        obs = measure_mimo(scene, self.f, measurement=self.no_noise, lo=LOConfig(initial_phase_rad=1.37))
        assert_allclose(obs.combined_iq, scene.response(self.f)**2, atol=1e-12)

    def test_cfo_residual_uses_forward_reverse_time_difference(self):
        scene = make_mimo_scene(ChannelConfig())
        schedule = make_schedule(len(self.f), random_tones=True, random_pairs=True, seed=5)
        obs = measure_mimo(scene, self.f, schedule, self.no_noise, LOConfig(residual_cfo_hz=113))
        expected = scene.response(self.f)**2*np.exp(2j*np.pi*113*(schedule.time_forward_s-schedule.time_reverse_s))
        assert_allclose(obs.combined_iq, expected, atol=2e-12)

    def test_synchronous_lo_cancels_even_with_wiener_phase(self):
        scene = make_mimo_scene(ChannelConfig())
        schedule = make_schedule(len(self.f))
        schedule.time_reverse_s[:] = schedule.time_forward_s
        obs = measure_mimo(scene, self.f, schedule, self.no_noise,
                           LOConfig(residual_cfo_hz=12, wiener_std_rad_per_sqrt_s=8), seed=9)
        assert_allclose(obs.combined_iq, scene.response(self.f)**2, atol=1e-12)

    def test_moving_geometry_gives_doppler_once(self):
        a, b = linear_arrays(8, 0, 0)
        b.velocity_mps = [1., 0., 0.]
        scene = MIMOScene(a, b)
        dt = .001
        ratio = scene.response(self.f, dt)/scene.response(self.f, 0)
        expected = 8/(8+dt)*np.exp(-2j*np.pi*self.f*dt/C)
        assert_allclose(ratio, np.tile(expected, (4, 1)), atol=3e-13)

    def test_moving_reflector_geometric_phase(self):
        a, b = linear_arrays(8)
        ray = Ray(vertices_m=[[3., 1., 0.]], velocity_mps=[0., 1., 0.])
        scene = MIMOScene(a, b, [ray])
        dt = .01
        p = np.array([3., 1.+dt, 0.])
        length = np.linalg.norm(a.positions_m[0]-p)+np.linalg.norm(p-b.positions_m[0])
        assert_allclose(scene.response(self.f, dt)[0], 8/length*np.exp(-2j*np.pi*self.f*length/C), atol=1e-12)

    def test_hardware_group_delay_two_way(self):
        a, b = linear_arrays(8, 0, 0)
        b.delay_ns = [0., 2.]
        scene = MIMOScene(a, b)
        m = measure_mimo(scene, self.f, measurement=self.no_noise)
        assert_allclose(m.combined_iq[1]/m.combined_iq[0], np.exp(-4j*np.pi*self.f*2e-9), atol=1e-12)

    def test_screen_is_world_fixed_and_can_block_only_some_pairs(self):
        a, b = linear_arrays(8, .6, .6)
        scene = make_mimo_scene(ChannelConfig(scenario="human_blockage", human_width_m=.45), a, b)
        power = np.mean(abs(scene.response(self.f))**2, axis=1)
        self.assertAlmostEqual(power[0], 1., places=10)
        self.assertAlmostEqual(power[3], 1., places=10)
        self.assertLess(power[1], .5)
        self.assertLess(power[2], .5)

    def test_schedule_order_and_nonoverlap(self):
        s = make_schedule(8, random_tones=True, random_pairs=True, seed=91)
        self.assertFalse(np.array_equal(s.tone_order, np.arange(8)))
        for k in range(8):
            np.testing.assert_array_equal(np.argsort(s.time_forward_s[:, k]), s.pair_order[k])
            np.testing.assert_array_equal(np.argsort(s.time_reverse_s[:, k]), s.pair_order[k])
        all_time = np.sort(np.r_[s.time_forward_s.ravel(), s.time_reverse_s.ravel()])
        self.assertTrue(np.all(np.diff(all_time) >= 20e-6-1e-15))

    def test_shared_lo_trace_across_frames(self):
        scene = make_mimo_scene(ChannelConfig())
        schedules = [make_schedule(80, frame_start_s=t) for t in (0, .05)]
        trace = make_lo_trace(schedules, LOConfig(wiener_std_rad_per_sqrt_s=3), seed=2)
        for s in schedules:
            x = measure_mimo(scene, self.f, s, self.no_noise, lo_trace=trace, seed=1)
            y = measure_mimo(scene, self.f, s, self.no_noise, lo_trace=trace, seed=2)
            assert_allclose(x.combined_iq, y.combined_iq)
            assert_allclose(x.lo_phase_forward, trace.at(s.time_forward_s))

    def test_validation(self):
        with self.assertRaises(ValueError):
            make_schedule(80, slot_s=-1)
        with self.assertRaises(ValueError):
            make_schedule(80, layout="pair_major", random_pairs=True)
        with self.assertRaises(ValueError):
            MIMOScene(AntennaArray([[0, 0, 0]]), AntennaArray([[1, 0, 0]]))
        with self.assertRaises(ValueError):
            make_mimo_scene(ChannelConfig(distance_m=8), *linear_arrays(10))

    def test_frame_grouping_rejects_duplicates_and_incomplete_frames(self):
        z = np.ones((12, 80), complex)
        key = np.repeat([[0, 1, 10], [0, 2, 20], [0, 3, 30]], 4, axis=0)
        paths = [0, 1, 2, 3, 0, 1, 2, 2, 0, 1, 2, 4]
        frames, ids, info = complete_frames(z, key, paths)
        self.assertEqual(frames.shape, (1, 4, 80))
        self.assertEqual(info["rejected_duplicate_frames"], 1)
        assert_allclose(ids, [[0, 1, 10]])

    def test_spectral_similarity_is_phase_invariant(self):
        z = np.exp(1j*np.arange(80)*.1)*(1+np.arange(80)*.01)
        coherence, amplitude = spectral_similarity(z, z*3*np.exp(1.7j))
        self.assertAlmostEqual(coherence, 1)
        self.assertAlmostEqual(amplitude, 1)

    def test_generator_exports_canonical_pairs_and_ti_input(self):
        root = Path(__file__).resolve().parents[1]
        with tempfile.TemporaryDirectory() as tmp:
            subprocess.run([sys.executable, str(root/"generate_ble_mimo.py"), "--scenario", "garage",
                            "--frames", "2", "--output", tmp], check=True, capture_output=True)
            with np.load(Path(tmp)/"garage_mimo.npz") as z:
                self.assertEqual(z["iq"].shape, (2, 4, 80))
                assert_allclose(z["iq"], z["iq_forward"]*z["iq_reverse"])
                np.testing.assert_array_equal(z["pair_indices"], PAIRS)
            if (root/"ti_ble_ranging_project/src").is_dir():
                sys.path.insert(0, str(root/"ti_ble_ranging_project/src"))
                try:
                    from ble_ti_ranging.inputs import load_case
                    _, c = load_case(Path(tmp)/"garage_combined_ti.json")
                    _, p = load_case(Path(tmp)/"garage_paired_ti.json")
                    self.assertEqual(c.iq.shape, (8, 80))
                    assert_allclose(c.iq, p.iq)
                finally:
                    sys.path.pop(0)


if __name__ == "__main__":
    unittest.main()
