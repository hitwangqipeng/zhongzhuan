"""Frequency-domain BLE PBR channels; NumPy + SciPy, no training required.

Architecture reference: https://arxiv.org/abs/2608.17497 (Section II).
All propagation lengths here are ONE WAY. Reciprocal PBR is H * H, never
H * conj(H). Human/car/garage are configurable engineering extensions,
not models or fitted parameters published in that paper. Screen diffraction
uses scalar Fresnel knife edges, NOT a dielectric-cylinder/full UTD solver.
Literature-backed scenarios and parameter provenance: BLE_LITERATURE_CHANNELS.md.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Literal

import numpy as np
from scipy.special import fresnel

from ble_literature_channels import GroundReflection, LITERATURE_SCENARIOS, literature_taps

C = 299_792_458.0
LEGACY_SCENARIOS = ("free_space", "static_multipath", "human_blockage", "car_blockage", "garage")
SCENARIOS = LEGACY_SCENARIOS + LITERATURE_SCENARIOS


def _positive(value, name, allow_zero=False):
    if not np.isfinite(value) or (value < 0 if allow_zero else value <= 0):
        raise ValueError(f"{name} must be finite and {'nonnegative' if allow_zero else 'positive'}")


def tone_grid(kind: str = "ble72") -> np.ndarray:
    """Ascending frequencies. legacy80 is the existing TI project's dense grid.

    ble72 follows the paper's 2402..2480 MHz minus indices 0,1,23,24,25,77,78.
    Supply explicit frequencies to simulate a different firmware channel map.
    """
    if kind == "ble72":
        indices = np.setdiff1d(np.arange(79), [0, 1, 23, 24, 25, 77, 78])
        return 2.402e9 + indices * 1e6
    if kind == "legacy80":
        return 2.400e9 + np.arange(80) * 1e6
    raise ValueError("grid must be ble72 or legacy80")


def knife_edge_coefficient(v) -> np.ndarray:
    """Complex Fresnel field / unobstructed field, exp(-j*omega*tau) convention.

    D(v)=(1+j)/2 * integral_v^infinity exp(-j*pi*u^2/2) du.
    D(0)=0.5, D(-infinity)=1; positive v means shadow. Preserve the
    complex phase: an attenuation-only model loses ranging-relevant delay.
    """
    v = np.asarray(v, dtype=float)
    if not np.all(np.isfinite(v)):
        raise ValueError("v must be finite")
    s, c = fresnel(v)
    return (1 + 1j) / 2 * ((0.5 - c) - 1j * (0.5 - s))


@dataclass(frozen=True)
class Tap:
    length_m: float
    gain: complex
    label: str = "reflection"
    # Positive screen-edge excess distance, used to retain Fresnel phase.
    diffraction_excess_m: float | None = None
    ground: GroundReflection | None = None
    ground_grazing_sine: float | None = None

    def response(self, frequency_hz):
        _positive(self.length_m, "tap length_m")
        if not np.isfinite(self.gain):
            raise ValueError("tap gain must be finite")
        f = np.asarray(frequency_hz, dtype=float)
        gain = complex(self.gain)
        if self.ground is not None:
            if self.diffraction_excess_m is not None or self.ground_grazing_sine is None:
                raise ValueError("ground tap needs grazing sine and cannot also be a diffraction tap")
            gain = gain*self.ground.coefficient(f, self.ground_grazing_sine)
        if self.diffraction_excess_m is not None:
            excess = self.diffraction_excess_m
            _positive(excess, "diffraction excess", allow_zero=True)
            if excess >= self.length_m:
                raise ValueError("diffraction excess must be smaller than total length")
            # v^2=4*excess/lambda. D includes the extra propagation phase;
            # remove it from the coefficient before using geometric length.
            # Equivalently: D(v)*exp(-j*2*pi*f*direct_length/c).
            v = np.sqrt(4 * excess * f / C)
            gain = gain * knife_edge_coefficient(v) * np.exp(2j * np.pi * f * excess / C)
        return gain * np.exp(-2j * np.pi * f * self.length_m / C)


@dataclass
class ChannelConfig:
    scenario: str = "free_space"
    distance_m: float = 8.0
    # Static paths: (ONE-WAY excess length [m], voltage amplitude, phase [deg]).
    static_taps: tuple = ((0.0, 1.0, 0.0), (2.0, 0.5, 90.0))
    obstacle_fraction: float = 0.5
    lateral_offset_m: float = 0.0
    human_width_m: float = 0.45
    car_width_m: float = 1.8
    car_roof_clearance_m: float = 0.8
    human_penetration_loss_db: float = 25.0
    car_penetration_loss_db: float = 45.0
    # Relative to an unobstructed channel of unit amplitude at the SAME d.
    garage_direct_loss_db: float = 18.0
    garage_direct_present: bool = True
    garage_specular: tuple = ((1.5, 0.7, 180.0), (4.0, 0.45, 90.0), (9.0, 0.25, -45.0))
    garage_tail_count: int = 40
    garage_tail_start_ns: float = 10.0
    garage_tail_span_ns: float = 160.0
    garage_decay_ns: float = 45.0
    garage_tail_power_db: float = -5.0
    # Literature-backed profiles: see BLE_LITERATURE_CHANNELS.md.
    # Extra delay to earliest stochastic arrival, independently of true range.
    excess_onset_ns: float = 0.0
    exp_decay_ns: float = 50.0
    exp_step_ns: float = 5.0
    exp_cutoff_db: float = 40.0
    sv_cluster_decay_ns: float = 35.6
    sv_ray_decay_ns: float = 36.5
    sv_cluster_interval_ns: float = 130.0
    sv_ray_interval_ns: float = 7.0
    sv_max_delay_ns: float = 400.0
    tgn_los: bool = False
    # For two_ray_ground, distance_m is slant DIRECT range, not horizontal.
    tx_height_m: float = 1.0
    rx_height_m: float = 1.0
    ground_relative_permittivity: float = 2.5
    ground_conductivity_s_per_m: float = 0.0
    ground_polarization: str = "vertical"


@dataclass
class Channel:
    frequency_hz: np.ndarray
    h: np.ndarray
    taps: list[Tap]
    distance_m: float
    metadata: dict = field(default_factory=dict)


def _user_taps(spec, distance_m, prefix):
    taps = []
    for i, (excess, amplitude, phase_deg) in enumerate(spec):
        _positive(excess, "excess length", allow_zero=True)
        _positive(amplitude, "tap amplitude", allow_zero=True)
        if not np.isfinite(phase_deg):
            raise ValueError("tap phase must be finite")
        taps.append(Tap(distance_m + excess, amplitude * np.exp(1j * np.deg2rad(phase_deg)), f"{prefix}_{i}"))
    return taps


def make_channel(config: ChannelConfig, frequency_hz=None, *, seed=None) -> Channel:
    """Generate H(f). Fixed seed reproduces a fixed stochastic scene.

    Unit unobstructed amplitude; no Friis loss or automatic normalization.
    Reflection amplitudes and screen attenuation therefore remain observable.
    Every new seed is a different static scene, not a time-correlated trajectory.
    """
    cfg = config
    if cfg.scenario not in SCENARIOS:
        raise ValueError(f"scenario must be one of {SCENARIOS}")
    _positive(cfg.distance_m, "distance_m")
    f = np.array(tone_grid() if frequency_hz is None else frequency_hz, dtype=float, copy=True)
    if f.ndim != 1 or len(f) < 2 or not np.all(np.isfinite(f)) or np.any(f <= 0) or np.any(np.diff(f) <= 0):
        raise ValueError("frequency_hz must be a finite, positive, strictly ascending vector")
    d = cfg.distance_m
    rng = np.random.default_rng(seed)
    meta = {"scenario": cfg.scenario, "one_way": True, "amplitude_reference": "unblocked unit field at same distance"}
    if cfg.scenario in LITERATURE_SCENARIOS:
        taps, provenance = literature_taps(cfg, rng)
        meta.update(provenance)
        if cfg.scenario != "two_ray_ground":
            meta["amplitude_reference"] = "unit conditional ensemble total tap power; no Friis loss"
    elif cfg.scenario == "free_space":
        taps = [Tap(d, 1.0, "direct")]
    elif cfg.scenario == "static_multipath":
        taps = _user_taps(cfg.static_taps, d, "static")
    elif cfg.scenario in ("human_blockage", "car_blockage"):
        if not np.isfinite(cfg.obstacle_fraction) or not 0 < cfg.obstacle_fraction < 1:
            raise ValueError("obstacle_fraction must lie strictly between 0 and 1")
        if not np.isfinite(cfg.lateral_offset_m):
            raise ValueError("lateral_offset_m must be finite")
        human = cfg.scenario == "human_blockage"
        width = cfg.human_width_m if human else cfg.car_width_m
        loss_db = cfg.human_penetration_loss_db if human else cfg.car_penetration_loss_db
        _positive(width, "obstacle width")
        _positive(loss_db, "penetration loss", allow_zero=True)
        blocked = abs(cfg.lateral_offset_m) <= width / 2
        meta.update(blocked=blocked, approximation="absorbing finite screen, coherent independent Fresnel edges")
        if not blocked:
            taps = [Tap(d, 1.0, "direct")]
        else:
            taps = [Tap(d, 10 ** (-loss_db / 20), "penetration")]
            clearances = [(width / 2 - cfg.lateral_offset_m, "left_edge"),
                          (width / 2 + cfg.lateral_offset_m, "right_edge")]
            if not human:
                _positive(cfg.car_roof_clearance_m, "car_roof_clearance_m")
                clearances.append((cfg.car_roof_clearance_m, "roof_edge"))
            d1 = d * cfg.obstacle_fraction
            d2 = d - d1
            for height, label in clearances:
                length = np.hypot(d1, height) + np.hypot(d2, height)
                taps.append(Tap(float(length), d / length, label, float(length - d)))
    else:
        if not isinstance(cfg.garage_direct_present, (bool, np.bool_)):
            raise ValueError("garage_direct_present must be bool")
        _positive(cfg.garage_direct_loss_db, "garage_direct_loss_db", allow_zero=True)
        _positive(cfg.garage_tail_start_ns, "garage_tail_start_ns", allow_zero=True)
        _positive(cfg.garage_tail_span_ns, "garage_tail_span_ns")
        _positive(cfg.garage_decay_ns, "garage_decay_ns")
        if isinstance(cfg.garage_tail_count, bool) or not isinstance(cfg.garage_tail_count, (int, np.integer)) or cfg.garage_tail_count < 0:
            raise ValueError("garage_tail_count must be a nonnegative integer")
        if not np.isfinite(cfg.garage_tail_power_db):
            raise ValueError("garage_tail_power_db must be finite")
        taps = [Tap(d, 10 ** (-cfg.garage_direct_loss_db / 20), "direct")] if cfg.garage_direct_present else []
        taps += _user_taps(cfg.garage_specular, d, "specular")
        n = cfg.garage_tail_count
        if n:
            delay_ns = np.sort(rng.uniform(cfg.garage_tail_start_ns,
                                          cfg.garage_tail_start_ns + cfg.garage_tail_span_ns, n))
            power = np.exp(-(delay_ns - cfg.garage_tail_start_ns) / cfg.garage_decay_ns)
            # Ensemble expected total diffuse power, not per-realization AGC.
            power *= 10 ** (cfg.garage_tail_power_db / 10) / power.sum()
            gains = (rng.normal(size=n) + 1j * rng.normal(size=n)) * np.sqrt(power / 2)
            taps += [Tap(d + delay * 1e-9 * C, gain, "diffuse") for delay, gain in zip(delay_ns, gains)]
        meta.update(approximation="specular plus exponential diffuse PDP; not IEEE CM1", temporal_correlation=False)
    h = sum((tap.response(f) for tap in taps), np.zeros(len(f), complex))
    return Channel(f, h, taps, d, meta)


@dataclass
class MeasurementConfig:
    snr_db: float = 30.0
    snr_reference: Literal["unblocked", "received"] = "unblocked"
    phase_noise_std_deg: float = 0.0
    missing_probability: float = 0.0


@dataclass
class Measurement:
    channel: Channel
    iq_a: np.ndarray
    iq_b: np.ndarray
    combined_iq: np.ndarray
    valid_mask: np.ndarray
    noise_power_per_endpoint: float


def measure(channel: Channel, config: MeasurementConfig | None = None, *, seed=None) -> Measurement:
    """Same reciprocal H, independent endpoint noise, then Y_A * Y_B.

    SNR is per endpoint. 'unblocked' keeps receiver noise fixed through
    blockage; 'received' sets SNR using mean |H|^2. Missing tones are zero
    with an explicit mask (no interpolation, no compressed-grid IFFT).
    """
    cfg = MeasurementConfig() if config is None else config
    if not (np.isfinite(cfg.snr_db) or cfg.snr_db == np.inf):
        raise ValueError("snr_db must be finite or +inf")
    _positive(cfg.phase_noise_std_deg, "phase_noise_std_deg", allow_zero=True)
    if not np.isfinite(cfg.missing_probability) or not 0 <= cfg.missing_probability <= 1:
        raise ValueError("missing_probability must lie in [0,1]")
    if cfg.snr_reference not in ("unblocked", "received"):
        raise ValueError("snr_reference must be unblocked or received")
    h = channel.h
    rng = np.random.default_rng(seed)
    reference_power = 1.0 if cfg.snr_reference == "unblocked" else float(np.mean(abs(h) ** 2))
    noise_power = reference_power * 10 ** (-cfg.snr_db / 10)
    endpoints = []
    for _ in range(2):
        phase = rng.normal(0, np.deg2rad(cfg.phase_noise_std_deg), len(h))
        noise = np.sqrt(noise_power / 2) * (rng.normal(size=len(h)) + 1j * rng.normal(size=len(h)))
        endpoints.append(h * np.exp(1j * phase) + noise)
    valid = rng.random(len(h)) >= cfg.missing_probability
    a, b = (np.where(valid, z, 0j) for z in endpoints)
    return Measurement(channel, a, b, a * b, valid, noise_power)


def to_cir(frequency_hz, iq, *, nfft=512, round_trip=True):
    """Zero-fill omitted positions on the physical 1 MHz grid, then IFFT.

    Returns (distance_m, complex_cir). Start-frequency carrier phase is a
    global phase only. IQ must use ascending frequencies and contain no NaN.
    Distance axis is c*tau/2 for combined IQ, c*tau for single-endpoint IQ.
    """
    f = np.asarray(frequency_hz, float)
    z = np.asarray(iq, complex)
    if f.ndim != 1 or len(f) < 2 or z.shape != f.shape or not np.all(np.isfinite(f)) or not np.all(np.isfinite(z)):
        raise ValueError("frequency_hz and iq must be matching finite 1-D arrays")
    if np.any(f <= 0) or np.any(np.diff(f) <= 0):
        raise ValueError("frequencies must be positive and strictly ascending")
    slots = (f - f[0]) / 1e6
    if not np.allclose(slots, np.rint(slots), atol=1e-6, rtol=0):
        raise ValueError("to_cir requires tones on a physical 1 MHz grid")
    index = np.rint(slots).astype(int)
    if isinstance(nfft, bool) or not isinstance(nfft, (int, np.integer)) or nfft <= index[-1]:
        raise ValueError("nfft must be an integer covering the full physical grid")
    spectrum = np.zeros(nfft, complex)
    spectrum[index] = z
    cir = np.fft.ifft(spectrum)
    distance = np.arange(nfft) * C / ((2 if round_trip else 1) * nfft * 1e6)
    return distance, cir
