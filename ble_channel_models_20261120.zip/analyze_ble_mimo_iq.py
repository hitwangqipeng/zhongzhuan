"""Read-only four-path IQ audit; sample files, pair by frame, report file-balanced statistics.

No raw IQ is squared: existing local caches/logs contain already-combined IQ.
No path->physical-antenna mapping, array spacing, or intra-step time is inferred.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path
import sys

import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent


def complete_frames(iq, frame_keys, paths, cap=64):
    """Keep exactly one row per path 0..3 and reject duplicate keys/paths."""
    z = np.asarray(iq, complex)
    p = np.asarray(paths)
    keys = np.asarray(frame_keys)
    if keys.ndim != 2 or len(keys) != len(z) or len(p) != len(z) or z.ndim != 2:
        raise ValueError("bad frame input shapes")
    if not np.isfinite(z).all() or not isinstance(cap, int) or cap < 1:
        raise ValueError("invalid IQ or cap")
    unique, inverse = np.unique(keys, axis=0, return_inverse=True)
    groups = {}
    duplicates = set()
    for row, (group, path) in enumerate(zip(inverse, p)):
        group, path = int(group), int(path)
        bucket = groups.setdefault(group, {})
        if path in bucket:
            duplicates.add(group)
        bucket[path] = row
    good = [g for g in range(len(unique)) if g not in duplicates and set(groups[g]) == {0, 1, 2, 3}]
    if len(good) > cap:
        # Coverage across the acquisition, not just its first frames.
        good = [good[i] for i in np.linspace(0, len(good)-1, cap, dtype=int)]
    rows = np.array([[groups[g][p] for p in range(4)] for g in good], dtype=int).reshape(-1, 4)
    return z[rows], unique[good], dict(complete_before_sampling=len(groups)-sum(
        g in duplicates or set(bucket) != {0, 1, 2, 3} for g, bucket in groups.items()),
        retained=len(good), rejected_duplicate_frames=len(duplicates), total_frames=len(unique))


def spectral_similarity(a, b):
    """Across-frequency cosine magnitude and centered amplitude correlation.

    These are spectral-shape descriptors, NOT independent temporal samples
    estimating the spatial channel covariance or Rician K-factor.
    """
    mask = (abs(a) > 0) & (abs(b) > 0)
    if mask.sum() < 16:
        return np.nan, np.nan
    x, y = a[mask], b[mask]
    cosine = abs(np.vdot(x, y)) / np.sqrt(np.vdot(x, x).real*np.vdot(y, y).real)
    ax, ay = abs(x), abs(y)
    ax, ay = ax-ax.mean(), ay-ay.mean()
    den = np.linalg.norm(ax)*np.linalg.norm(ay)
    amp = float(ax @ ay / den) if den > 1e-15 else np.nan
    return float(np.clip(cosine, 0, 1)), amp


def frame_metrics(z):
    """z[N,4,80] -> per-frame rows for six pairings; no phase calibration fitted."""
    z = np.asarray(z, complex)
    if z.ndim != 3 or z.shape[1:] != (4, 80):
        raise ValueError("expected N x 4 x 80 already-combined IQ")
    power = np.mean(abs(z)**2, axis=2)
    spread = 10*np.log10(np.maximum(power.max(1), 1e-30)/np.maximum(power.min(1), 1e-30))
    # Physical 80 x 1MHz grid. Strongest peak descriptor; not first-path truth.
    mag = abs(np.fft.ifft(z, n=2048, axis=2))
    distance = np.argmax(mag[:, :, :820], axis=2)*299792458/(2e6*2048)
    rows = []
    for n in range(len(z)):
        for i, j in itertools.combinations(range(4), 2):
            cosine, amplitude_corr = spectral_similarity(z[n, i], z[n, j])
            rows.append(dict(frame=n, pair=f"{i}-{j}", spectral_cosine=cosine,
                             amplitude_correlation=amplitude_corr,
                             peak_gap_m=float(abs(distance[n, i]-distance[n, j])),
                             power_spread_db=float(spread[n])))
    temporal = []
    for n in range(len(z)-1):
        for q in range(4):
            temporal.append(spectral_similarity(z[n, q], z[n+1, q])[0])
    return pd.DataFrame(rows), dict(n_frames=len(z), zero_tone_fraction=float(np.mean(z == 0)),
                                   median_temporal_shape_similarity=float(np.nanmedian(temporal)) if temporal else None)


def _sha(path):
    with Path(path).open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def analyze(output, bench_limit=72, car_limit=32, frame_cap=64):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(20261120)
    records, pair_records, manifest = [], [], []
    audit_path = BASE/"outputs/step12/file_audit.csv"
    audit = pd.read_csv(audit_path)
    eligible = audit[audit.expected_paths.eq(4) & audit.truth_m.notna() & audit.duplicate_of.isna() & audit.complete_frames.gt(0)]
    # Choose one file per environment x condition x distance, then cap.
    candidates = [group.iloc[int(rng.integers(len(group)))] for _, group in eligible.groupby(["environment", "condition", "truth_m"], sort=True)]
    if len(candidates) > bench_limit:
        candidates = [candidates[i] for i in np.sort(rng.choice(len(candidates), bench_limit, replace=False))]
    car_audit_path = BASE/"outputs/ti_sdk_nn_retrained_20261117/source_audit.csv"
    car_source = pd.read_csv(car_audit_path)
    # This known acquisition tree is fob_v2 / car-dataset / condition / distance / log.
    # Resolve its existing root from audited metadata rather than a machine name.
    raw_root = Path(car_source.file.iloc[0]).parents[3]
    for row in candidates:
        fid = int(row.file_id)
        cache_path = BASE/"outputs/step12/cache"/f"{fid:04d}.npz"
        if not cache_path.is_file():
            continue
        raw_path = raw_root / row.relative_path
        raw_ok = raw_path.is_file() and _sha(raw_path) == row.sha256
        if not raw_ok:
            raise ValueError(f"raw source hash unavailable/mismatch for bench {fid}")
        with np.load(cache_path, allow_pickle=False) as cache:
            z = cache["iq"].astype(float)
            z = z[..., 0]+1j*z[..., 1]
            keys = np.column_stack([cache[k] for k in ("epoch", "key", "ts")])
            frames, _, grouping = complete_frames(z, keys, cache["path"], cap=frame_cap)
        if not len(frames):
            continue
        desc, extra = frame_metrics(frames)
        source = f"bench:{fid}"
        metrics = dict(source=source, dataset="bench", condition=str(row.condition), environment=str(row.environment),
                       truth_m=float(row.truth_m), **extra, **grouping)
        desc["source"] = source
        pair_records.append(desc)
        records.append(metrics)
        manifest.append(dict(source=source, raw_file=str(raw_path), raw_sha256=row.sha256,
                             cache=str(cache_path), cache_sha256=_sha(cache_path),
                             combined_iq=True, physical_pair_mapping_verified=False,
                             microsecond_slot_times_available=False))
    car = car_source.sort_values("file")
    if len(car) > car_limit:
        car = car.iloc[np.linspace(0, len(car)-1, car_limit, dtype=int)]
    sys.path.insert(0, str(BASE/"ti_ble_ranging_project/src"))
    try:
        from ble_ti_ranging.inputs import _parse_log
        for row in car.itertuples():
            path = Path(row.file)
            if _sha(path) != row.sha256:
                raise ValueError(f"raw car hash mismatch {row.file_id}")
            parsed, log_audit = _parse_log(path, complete_four_paths=True)
            if not parsed:
                continue
            keys = np.array([r[:3] for r in parsed])
            paths = np.array([r[3] for r in parsed])
            z = np.array([r[5] for r in parsed])
            frames, _, grouping = complete_frames(z, keys, paths, cap=frame_cap)
            if not len(frames):
                continue
            desc, extra = frame_metrics(frames)
            source = f"car:{row.file_id}"
            # Preserve actual acquisition-folder condition, not a guessed class.
            condition = path.parent.parent.name
            desc["source"] = source
            pair_records.append(desc)
            records.append(dict(source=source, dataset="car", condition=condition,
                                environment="real_car", truth_m=None, **extra, **grouping))
            manifest.append(dict(source=source, raw_file=str(path), raw_sha256=row.sha256,
                                 combined_iq=True, physical_pair_mapping_verified=False,
                                 microsecond_slot_times_available=False))
    finally:
        sys.path.pop(0)
    if not records:
        raise ValueError("no complete four-path frames")
    frames_df = pd.concat(pair_records, ignore_index=True)
    sources = pd.DataFrame(records)
    numerical = ["spectral_cosine", "amplitude_correlation", "peak_gap_m", "power_spread_db"]
    # File medians first. Files, not frames, are units for group aggregation.
    file_pair = frames_df.groupby(["source", "pair"])[numerical].median().reset_index()
    file_summary = frames_df.groupby("source")[numerical].median().reset_index().merge(sources, on="source", validate="one_to_one")
    summary = file_summary.groupby(["dataset", "condition"]).agg(
        files=("source", "size"), frames=("n_frames", "sum"),
        spectral_cosine=("spectral_cosine", "median"), amplitude_correlation=("amplitude_correlation", "median"),
        peak_gap_m=("peak_gap_m", "median"), power_spread_db=("power_spread_db", "median"),
        temporal_shape_similarity=("median_temporal_shape_similarity", "median"),
        zero_tone_fraction=("zero_tone_fraction", "median")).reset_index()
    file_summary.to_csv(output/"file_summary.csv", index=False, encoding="utf-8-sig")
    file_pair.to_csv(output/"file_pair_metrics.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(output/"condition_summary.csv", index=False, encoding="utf-8-sig")
    protocol = dict(n_files=len(sources), sampled_complete_frames=int(sources.n_frames.sum()),
                    bench_files=int(sources.dataset.eq("bench").sum()), car_files=int(sources.dataset.eq("car").sum()),
                    frame_cap=frame_cap, seed=20261120,
                    raw_hashes_verified=True, source_data_modified=False, already_combined_iq_not_squared=True,
                    spectral_statistic="across-frequency shape similarity, not identified spatial covariance",
                    timing="frame IDs only; intra-tone switching times not recoverable from these logs",
                    hardware_geometry="not inferred; path index mapping and element coordinates unverified",
                    no_parameter_fit=True, file_balanced=True,
                    temporal_metric="consecutive RETAINED complete frames, not necessarily adjacent raw frames",
                    no_claim_of_independent_samples=True)
    (output/"analysis_protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    (output/"source_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(protocol))
    print(summary.to_json(orient="records", force_ascii=True))
    return summary


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output", type=Path, default=BASE/"outputs/ble_mimo_audit_20261120")
    p.add_argument("--bench-limit", type=int, default=72)
    p.add_argument("--car-limit", type=int, default=32)
    p.add_argument("--frame-cap", type=int, default=64)
    args = p.parse_args()
    if min(args.bench_limit, args.car_limit, args.frame_cap) < 1:
        p.error("limits must be positive")
    analyze(args.output, args.bench_limit, args.car_limit, args.frame_cap)


if __name__ == "__main__":
    main()
