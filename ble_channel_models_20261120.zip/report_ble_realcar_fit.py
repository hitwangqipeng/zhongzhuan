"""Create the reviewable report/figures from completed grouped model fits."""
from pathlib import Path
import json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from ble_channel_fit import FEATURES,simulate_features

BASE=Path(__file__).resolve().parent
OUT=BASE/"outputs/ble_realcar_channel_fit_20261120"
LABELS={"single_path":"Single path", "two_ray":"Two rays", "sparse_four_ray":"Four sparse rays",
        "exponential_diffuse":"Exponential diffuse", "clustered_sv":"SV-like clusters",
        "human_screen":"Human screen only", "car_screen":"Car screen only",
        "two_ray_phase":"Two rays + phase error", "exponential_diffuse_phase":"Exp. diffuse + phase error",
        "clustered_sv_phase":"Clusters + phase error"}
CN={"single_path":"单径", "two_ray":"两径", "sparse_four_ray":"稀疏四径",
    "exponential_diffuse":"指数衰减散射", "clustered_sv":"SV式簇状多径",
    "human_screen":"仅人体屏障", "car_screen":"仅车体屏障",
    "two_ray_phase":"两径＋相位扰动", "exponential_diffuse_phase":"指数散射＋相位扰动",
    "clustered_sv_phase":"簇状多径＋相位扰动"}


def main():
    comparison=pd.read_csv(OUT/"model_comparison.csv")
    scores=pd.read_csv(OUT/"heldout_file_scores.csv")
    bootstrap=pd.read_csv(OUT/"paired_group_bootstrap.csv")
    real=pd.read_csv(OUT/"real_file_features.csv")
    profiles=json.loads((OUT/"recommended_effective_profiles.json").read_text(encoding="utf-8"))
    protocol=json.loads((OUT/"real_feature_protocol.json").read_text(encoding="utf-8"))
    split=json.loads((OUT/"split_protocol.json").read_text(encoding="utf-8"))
    fig,axes=plt.subplots(1,2,figsize=(15,7.5),sharex=True,layout="constrained")
    rng=np.random.default_rng(88)
    for ax,condition in zip(axes,("LOS","NLOS")):
        sub=comparison[comparison.condition.eq(condition)].sort_values("cv_score",ascending=False)
        p=scores[scores.condition.eq(condition)].pivot_table(index="nominal_m",columns="family",values="score")
        ids=rng.integers(0,len(p),(4000,len(p)))
        lo=[];hi=[]
        for row in sub.itertuples():
            draws=p[row.family].to_numpy()[ids].mean(1)
            lo.append(max(0,row.cv_score-np.quantile(draws,.025)))
            hi.append(max(0,np.quantile(draws,.975)-row.cv_score))
        ax.barh([LABELS[f] for f in sub.family],sub.cv_score,color=["#197e93" if f==profiles[condition]["family"] else "#a7b9ca" for f in sub.family],
                xerr=np.array([lo,hi]),error_kw=dict(capsize=2,elinewidth=1))
        reference=float(sub.empirical_reference.iloc[0])
        ax.axvline(reference,color="#a95235",ls="--",lw=1.5,label="Empirical train-file reference")
        ax.set_title(f"{condition} acquisition folder",fontweight="bold")
        ax.set_xlabel("Held-out normalized CRPS (lower is closer)")
        ax.grid(axis="x",alpha=.2);ax.set_axisbelow(True);ax.legend(fontsize=8,loc="lower right")
    fig.suptitle("Four-path effective channel comparison | 8 held-out distance groups",fontsize=14,fontweight="bold")
    fig.savefig(OUT/"model_comparison.png",dpi=170)
    plt.close(fig)
    descriptors=[(0,"Envelope CV"),(3,"Between-path spectral cosine"),(6,"CIR energy concentration"),(8,"Circular CIR spread (m)")]
    fig,axes=plt.subplots(2,4,figsize=(15,6.5),layout="constrained")
    simulation={}
    for row,condition in enumerate(("LOS","NLOS")):
        profile=profiles[condition]
        sim=simulate_features(profile["family"],profile["parameters"],n=512,repeats=4,seed=9301)
        simulation[condition]=sim
        pd.DataFrame(sim,columns=FEATURES).to_csv(OUT/f"full_fit_simulated_features_{condition}.csv",index=False)
        for col,(index,title) in enumerate(descriptors):
            ax=axes[row,col]
            measured=np.sort(real[real.condition.eq(condition)][FEATURES[index]].to_numpy())
            generated=np.sort(sim[:,index])
            ax.step(measured,np.arange(1,len(measured)+1)/len(measured),where="post",color="#a95235",label="Measured files")
            ax.plot(generated,np.arange(1,len(generated)+1)/len(generated),color="#197e93",label="Full-fit simulation")
            ax.set_title(f"{condition}: {title}",fontsize=10);ax.grid(alpha=.2);ax.set_ylim(0,1)
            if col==0:ax.set_ylabel("Empirical CDF")
            if row==0 and col==0:ax.legend(fontsize=8)
    fig.suptitle("Full-data fit illustration (model selection uses separate grouped CV above)",fontsize=13,fontweight="bold")
    fig.savefig(OUT/"feature_distribution_fit.png",dpi=170)
    plt.close(fig)
    lines=["# 实车四路 IQ：有效信道模型拟合与候选比较","",
           "本报告比较的是现有测量链路输出的统计生成模型。模型先生成共享空间路径的单程 H，再叠加接收噪声/可选相位扰动，最后形成正反向乘积；没有直接把双向 IQ 当作单程 H，也没有对原始 IQ 再平方。","",
           "## 结果","",
           "| 采集标签 | CV最小误差候选 | 留出CRPS | 相对实测经验参考 | 与次名的区分 |",
           "|---|---|---:|---:|---|"]
    for condition in ("LOS","NLOS"):
        sub=comparison[comparison.condition.eq(condition)].sort_values("cv_score")
        first,second=sub.iloc[0],sub.iloc[1]
        interval=bootstrap[bootstrap.condition.eq(condition)&bootstrap.challenger.eq(second.family)].iloc[0]
        distinction="差异区间含0，不能明确区分" if interval.ci025<=0<=interval.ci975 else "分组bootstrap区间未跨0（探索性）"
        lines.append(f"| {condition}文件夹 | {CN[first.family]} | {first.cv_score:.4f} | {first.score_ratio:.3f}× | {distinction} |")
    lines += ["","CRPS为九个可观察统计量的边际经验分布评分，按幅度起伏、跨路形状、路间功率差、CIR形状四组等权；越小越接近，不是测距MAE或概率百分比。经验参考直接使用训练文件的特征分布预测留出文件，只作为现实可达到程度的参照，没有生成对应IQ。","",
              "LOS/NLOS是采集文件夹标签，不保证该标签下所有车身锚点均有无遮挡直达径。候选排名受本次参数范围、固定代表性阵元间距及有限搜索预算约束；模型选择本身使用了交叉验证，选择后没有新增一次独立实车测试。","",
              "![候选模型留出比较](model_comparison.png)","",
              "## 全部候选","","| 候选 | LOS留出CRPS | NLOS留出CRPS |","|---|---:|---:|"]
    for family in comparison.family.unique():
        vals=comparison[comparison.family.eq(family)].set_index("condition")
        lines.append(f"| {CN[family]} | {vals.loc['LOS','cv_score']:.4f} | {vals.loc['NLOS','cv_score']:.4f} |")
    lines += ["","单径、两径、稀疏四径检验少量路径是否足够；指数散射对应单一衰减尺度的弥散尾部；SV式模型使用3簇×8条ray、Poisson到达及簇内/簇间指数功率衰减；人体/车体候选只有原先的屏障绕射与穿透，没有额外环境散射。三个“相位扰动”变体在对应传播模型上加入独立的逐tone每端相位误差，用于检查宽CIR是否可能混有测量损伤；该参数不能直接宣称是已测得的振荡器相噪。","",
              "簇状模型是参考Saleh–Valenzuela/IEEE 802.15.4a结构的简化候选族，没有声称拟合出标准CM1/CM2等场景表。人体/车体候选表现差时，只能说明“仅靠屏障”不足，不能说明实际不存在人体或车体遮挡。","",
              "Rician/Rayleigh与SV不是互斥分类：前者主要描述直达与随机散射叠加的衰落统计，后者描述多径到达和延迟簇结构。本实现的指数/簇状族都包含可调直达分量；已经组合的双向IQ幅度不能直接当作单程Rician/Rayleigh样本。","",
              "## 导出的有效参数","","参数来自全量32文件/条件的最后一次拟合；留出评分来自分别只使用24训练文件/条件的四折模型。","",
              "| 条件 | 参数 | 数值 |","|---|---|---:|"]
    for condition,profile in profiles.items():
        for key,val in profile["parameters"].items():
            lines.append(f"| {condition} | `{key}` | {val:.5g} |")
        lines.append(f"| {condition} | 额外有效距离偏移（m，仅诊断） | {profile['effective_range_offset_m']:.5g} |")
    lines += ["","`tau_ns`是模型里单程超额路径/簇到达尺度，不能等同于从实测唯一恢复的RMS delay spread；`k_db`是该生成族的直达/散射功率比例参数，不是直接对双向IQ幅度做Rician拟合得到的物理K因子；增益、群时延和SNR参数均是共同假设下的有效值。额外距离偏移由强峰偏差中位数得到，混合了前端延迟、标定和NLOS起始超额路径，未用于候选排名，默认不施加。","",
              "![全量拟合的特征分布示意](feature_distribution_fit.png)","",
              "## 数据与留出协议","",
              f"- 全部64个静态文件，4个锚点×8个标称距离×2个采集标签；每文件最多{protocol['frame_cap']}个完整四路帧，合计{protocol['frames']}帧。",
              "- 原始文件SHA256与已有source audit一致；只保留同帧恰好0..3四路的记录，拒绝不完整/重复组合。数据源只读。",
              "- 真值使用用户2026-11-11更正的三维锚点几何；旧slave2/slave4坐标未使用。",
              f"- 四折留出标称距离分别为：`{split['held_nominal_distances']}`。同距离的四锚点、两个标签整组留出。",
              f"- 每个基本候选先用{split['candidates']}个Latin hypercube参数点，再对每个训练折做{split['refine']}次局部随机细化；每参数点{split['sim_scenes']}个共享几何场景×{split['repeats']}次独立端点噪声。",
              "- 相位扰动族额外从同一训练折的无相位父模型最优参数出发，包含0度及三个非零相位扰动起点；运行时保证其训练目标不劣于嵌套父模型。留出数据不参与这个起点选择。",
              "- 留出评分用新随机种子、四倍场景数；置信区间以8个距离采集组做4000次配对bootstrap，不把几千个相关帧当作独立实验。",
              "- bootstrap固定已拟合的各折模型，没有每次重新搜索参数，也未校正选择最优候选带来的多重比较；仅作为探索性稳定性描述。",
              "- 参数搜索使用前9个统计量；四路强峰差、Gram有效秩、强峰对几何距离偏差保留作额外检查，详见model_comparison.csv。",
              "- 频点相关，不按80个tone独立估计空间协方差。绝对接收幅度受AGC等影响，没有拟合Friis路径损耗指数。","",
              "## 能说明什么，不能说明什么","",
              "可以给出在这批数据的可观察统计上更接近的生成族，导出可复用的四路IQ仿真参数，并用留出分组检查是否只记住了训练场景。不能从已经组合的H_forward×H_reverse唯一分离两方向信道、物理散射点、天线间距/方向图、噪声与相位误差、逐slot运动以及硬件群时延。归一化描述也不支持恢复绝对路径损耗。","",
              "仿真中的5cm间距及垂直于两端连线的横截面内随机阵列方向是代表性先验，不是拟合出的真实天线坐标。这里只拟合静态文件内的频域形状分布，没有拟合多普勒、运动速度或跨帧时间相关函数。模型缺失机制可能被有效尾部/相位参数吸收；若不同族误差接近，应保留多个候选做训练增强，不应把最小分数当作唯一真实环境。","",
              "## 复现与生成","","```powershell",
              "python -m unittest discover -s tests -p 'test_ble*.py' -v",
              "python fit_ble_realcar.py --candidates 192 --sim-scenes 64 --refine 24",
              "python report_ble_realcar_fit.py",
              "python generate_fitted_ble_iq.py --profiles outputs/ble_realcar_channel_fit_20261120/recommended_effective_profiles.json --condition NLOS --scenes 16 --frames-per-scene 4",
              "```","",
              "拟合脚本依赖本地实车数据及ti_ble_ranging_project中的原始日志适配器；代码包不包含用户原始IQ。已导出的JSON参数和生成器可以独立使用。生成的IQ形状为scene×frame×4×80，四路共享同一静态几何；同场景的帧不重新抽取散射体。","",
              "## 一手资料","",
              "1. [Bluetooth Core 6.2, Vol.6 Part H §4.7](https://www.bluetooth.com/wp-content/uploads/Files/Specification/HTML/Core-62/out/en/low-energy-controller/channel-sounding.html)：多天线切换与正反向相同序列。",
              "2. [3GPP TR38.901 V18.0.0 §7.5](https://www.etsi.org/deliver/etsi_tr/138900_138999/138901/18.00.00_60/tr_138901v180000p.pdf)：公共ray与阵元位置/方向响应。",
              "3. [IEEE 802.15.4a channel model final report, §II](https://www.ieee802.org/15/pub/04/15-04-0662-02-004a-channel-model-final-report-r1.pdf)：簇状到达与指数衰减结构；未照搬其场景参数。",
              "4. [Channel Modeling for Phase-Based Ranging](https://arxiv.org/html/2608.17497v1)：tone级传播/硬件损伤分层。",
              "5. [Clarke 1968](https://doi.org/10.1002/j.1538-7305.1968.tb00069.x)：用于独立J0相关极限检查。",""
              ]
    (OUT/"BLE_REALCAR_FIT.md").write_text("\n".join(lines),encoding="utf-8")
    print(OUT/"BLE_REALCAR_FIT.md")


if __name__=="__main__":main()
