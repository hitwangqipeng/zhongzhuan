"""Fit effective static four-path channel families, with distance-group holdouts.

python fit_ble_realcar.py --candidates 192 --sim-scenes 64 --refine 24
No training of a ranging NN; no raw IQ or source files are modified.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import re
import sys
import time

import numpy as np
import pandas as pd
from scipy.stats import qmc

from analyze_ble_mimo_iq import complete_frames
from ble_channel_fit import (FAMILIES, FEATURES, FIT_IDS, parameter_space, decode_parameters, encode_parameters,
                             iq_features, simulate_features, crps_by_file, feature_scales)
from real_car_geometry import GEOMETRY_VERSION, range_truth

BASE=Path(__file__).resolve().parent


def save_json(path,value):
    Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False,allow_nan=False),encoding="utf-8")


def sha(path):
    with Path(path).open("rb") as f:
        return hashlib.file_digest(f,"sha256").hexdigest()


def prepare(output,frame_cap):
    output.mkdir(parents=True,exist_ok=True)
    target=output/"real_file_features.csv"
    if target.exists():
        protocol=json.loads((output/"real_feature_protocol.json").read_text(encoding="utf-8"))
        if protocol["frame_cap"]!=frame_cap or protocol["geometry_version"]!=GEOMETRY_VERSION:
            raise ValueError("feature cache protocol mismatch; use a new output directory")
        return pd.read_csv(target)
    audit=pd.read_csv(BASE/"outputs/ti_sdk_nn_retrained_20261117/source_audit.csv")
    sys.path.insert(0,str(BASE/"ti_ble_ranging_project/src"))
    records=[];manifest=[]
    try:
        from ble_ti_ranging.inputs import _parse_log
        for entry in audit.itertuples():
            path=Path(entry.file)
            if sha(path)!=entry.sha256:
                raise ValueError(f"source hash mismatch {entry.file_id}")
            condition=path.parent.parent.name
            match=re.search(r"(\d+(?:\.\d+)?)M",path.parent.name)
            anchor_match=re.search(r"\[(master|slave\d+)\]",path.name)
            if condition not in ("LOS","NLOS") or not match or not anchor_match:
                raise ValueError("unrecognized static source metadata")
            nominal=float(match[1]);anchor=anchor_match[1]
            truth=float(range_truth(nominal,anchor))
            parsed,source_audit=_parse_log(path,complete_four_paths=True)
            keys=np.array([r[:3] for r in parsed])
            paths=np.array([r[3] for r in parsed])
            z=np.array([r[5] for r in parsed])
            frames,_,grouping=complete_frames(z,keys,paths,cap=frame_cap)
            if len(frames)<8:
                raise ValueError("too few complete frames in a source")
            feature=np.median(iq_features(frames,truth),axis=0)
            row=dict(source=f"car:{entry.file_id}",condition=condition,nominal_m=nominal,anchor=anchor,
                     truth_m=truth,n_frames=len(frames),session=f"{condition}|{nominal:g}m")
            row.update(zip(FEATURES,map(float,feature)));records.append(row)
            manifest.append(dict(source=row["source"],file=str(path),sha256=entry.sha256,**grouping))
    finally:
        sys.path.pop(0)
    df=pd.DataFrame(records).sort_values(["condition","nominal_m","anchor"]).reset_index(drop=True)
    if len(df)!=64 or len(df.nominal_m.unique())!=8 or df.duplicated(["condition","nominal_m","anchor"]).any():
        raise ValueError("expected 64 unique static files at eight distances")
    df.to_csv(target,index=False,encoding="utf-8-sig")
    save_json(output/"real_source_manifest.json",manifest)
    save_json(output/"real_feature_protocol.json",dict(files=len(df),frames=int(df.n_frames.sum()),
        frame_cap=frame_cap,geometry_version=GEOMETRY_VERSION,combined_iq=True,raw_hashes_verified=True,
        already_combined_iq_not_squared=True,source_data_modified=False,
        fit_features=list(FEATURES[:9]),reserved_features=list(FEATURES[9:]),
        absolute_rx_gain_removed=True,raw_path_to_physical_pair_unverified=True,
        no_unique_one_way_CIR_recovered=True,unknown_intra_slot_times_not_fitted=True))
    return df


def library(family,folder,count,sim_scenes,repeats):
    path=folder/f"library_{family}.npz"
    if path.exists():
        with np.load(path) as z:
            if z["features"].shape!=(count,sim_scenes,len(FEATURES)) or int(z["repeats"])!=repeats:
                raise ValueError("simulation library mismatch")
            return z["unit"],z["features"]
    unit=qmc.LatinHypercube(len(parameter_space(family)),seed=20261120).random(count)
    unit[0]=.5
    features=[];start=time.perf_counter()
    for k,u in enumerate(unit):
        features.append(simulate_features(family,decode_parameters(family,u),n=sim_scenes,repeats=repeats,seed=1701))
        if (k+1)%48==0:
            print(f"LIBRARY {family} {k+1}/{count} {time.perf_counter()-start:.1f}s",flush=True)
    values=np.array(features)
    np.savez_compressed(path,unit=unit,features=values,repeats=repeats)
    return unit,values


def fit_one(family,target,unit,features,refine,sim_scenes,repeats,seed,warm_parameters=None):
    if warm_parameters is not None:
        # A phase-augmented family includes its parent at sigma=0. Ensure the
        # exact TRAINING-fold parent optimum is considered, avoiding a search
        # dimensionality artifact. No held-out score enters this choice.
        extra=[];generated=[]
        for sigma in (0.,5.,12.5,20.):
            p=dict(warm_parameters,phase_noise_std_deg=sigma)
            extra.append(encode_parameters(family,p))
            generated.append(simulate_features(family,p,n=sim_scenes,repeats=repeats,seed=1701))
        unit=np.concatenate([unit,np.array(extra)])
        features=np.concatenate([features,np.array(generated)])
    scales=feature_scales(target)
    losses=np.array([crps_by_file(x,target,scales).mean() for x in features])
    best=int(losses.argmin());best_unit=unit[best].copy();best_sim=features[best];best_loss=float(losses[best])
    rng=np.random.default_rng(seed)
    top=unit[np.argsort(losses)[:4]]
    refined=[]
    for k in range(refine):
        center=best_unit if k%2 else top[k%4]
        trial=np.clip(center+rng.normal(0,.06 if k>=refine/2 else .15,len(center)),0,1)
        sim=simulate_features(family,decode_parameters(family,trial),n=sim_scenes,repeats=repeats,seed=1701)
        loss=float(crps_by_file(sim,target,scales).mean())
        refined.append(trial)
        if loss<best_loss:
            best_loss,best_unit,best_sim=loss,trial,sim
    return decode_parameters(family,best_unit),best_loss,scales,best_sim


def folds_for_distances(distances):
    values=np.array(sorted(set(distances)))
    # Entire nominal-distance acquisition groups, including BOTH conditions and
    # all anchors, stay together. No random frame/path splitting.
    shuffled=np.random.default_rng(20261120).permutation(values)
    return [set(part.tolist()) for part in np.array_split(shuffled,4)]


def run(args):
    out=args.output;out.mkdir(parents=True,exist_ok=True)
    data=prepare(out,args.frame_cap)
    foldsets=folds_for_distances(data.nominal_m)
    save_json(out/"split_protocol.json",dict(held_nominal_distances=[sorted(x) for x in foldsets],
        train_test_group="nominal distance across both conditions and four anchors",seed=20261120,
        fit_unit="one median feature vector per raw file",no_anchor_specific_fits=True,
        simulation_distances_m=[3,30],simulation_scene_geometry="5cm example spacing, random transverse-plane array orientations",
        loss="marginal empirical CRPS, equal envelope/spatial/imbalance/CIR group weights",
        candidates=args.candidates,refine=args.refine,sim_scenes=args.sim_scenes,repeats=args.repeats,
        nested_phase_variants_include_parent_training_optimum=True,
        parameter_bounds={f:parameter_space(f) for f in FAMILIES},
        model_selection="four-fold grouped CV; final selected model has no additional independent field test"))
    rows=[];fits=[];profiles={}
    for family in FAMILIES:
        unit,features=library(family,out,args.candidates,args.sim_scenes,args.repeats)
        for condition in ("LOS","NLOS"):
            subset=data[data.condition.eq(condition)].copy()
            for fold,held in enumerate(foldsets):
                cache=out/f"fit_{family}_{condition}_fold{fold}.json"
                if cache.exists():
                    record=json.loads(cache.read_text(encoding="utf-8"))
                    rows.extend(record["scores"]);fits.append(record["fit"])
                    continue
                train=subset[~subset.nominal_m.isin(held)]
                test=subset[subset.nominal_m.isin(held)]
                if set(train.session)&set(test.session) or set(train.source)&set(test.source):
                    raise AssertionError("group leakage")
                target=train[list(FEATURES)].to_numpy()
                warm=None
                if family.endswith("_phase"):
                    parent=out/f"fit_{family.removesuffix('_phase')}_{condition}_fold{fold}.json"
                    parent_fit=json.loads(parent.read_text(encoding="utf-8"))["fit"]
                    warm=parent_fit["params"]
                params,loss,scales,sim_train=fit_one(family,target,unit,features,args.refine,args.sim_scenes,args.repeats,
                                                    seed=1910+fold,warm_parameters=warm)
                if warm is not None and loss > parent_fit["train_score"]+1e-9:
                    raise AssertionError("nested phase family lost its parent training optimum")
                # New random scene seeds AND four times more simulated files.
                sim_eval=simulate_features(family,params,n=args.sim_scenes*4,repeats=args.repeats,seed=24601)
                test_features=test[list(FEATURES)].to_numpy()
                scores=crps_by_file(sim_eval,test_features,scales)
                empirical=crps_by_file(target,test_features,scales)
                # Peak-range offset is a separate diagnostic, not optimized for
                # family ranking; it mixes hardware delay and excess propagation.
                bias_shift=float(np.median(target[:,-1])-np.median(sim_train[:,-1]))
                reserved_scale=np.maximum(np.subtract(*np.quantile(target[:,9:],[.75,.25],axis=0)),[1.,.1,1.])
                sim_reserved=sim_eval[:,9:].copy();sim_reserved[:,-1]+=bias_shift
                records=[]
                for index,(_,source) in enumerate(test.iterrows()):
                    reserved_error=abs(sim_reserved-np.array(source[list(FEATURES[9:])],float)[None,:]).mean(0)/reserved_scale
                    records.append(dict(source=source.source,condition=condition,nominal_m=float(source.nominal_m),
                                        anchor=source.anchor,fold=fold,family=family,score=float(scores[index]),
                                        empirical_reference_score=float(empirical[index]),
                                        peak_gap_abs_error_scaled=float(reserved_error[0]),
                                        gram_rank_abs_error_scaled=float(reserved_error[1]),
                                        peak_bias_abs_error_scaled=float(reserved_error[2])))
                fit=dict(family=family,condition=condition,fold=fold,train_files=len(train),test_files=len(test),
                         train_score=loss,test_score=float(scores.mean()),params=params,
                         scales=scales.tolist(),effective_range_offset_m=bias_shift,
                         parent_training_optimum_included=warm is not None)
                save_json(cache,dict(fit=fit,scores=records,simulated_quantiles=np.quantile(sim_eval,[.1,.5,.9],axis=0).tolist()))
                rows.extend(records);fits.append(fit)
                print(f"FIT {family} {condition} fold{fold} train={loss:.4f} held={scores.mean():.4f}",flush=True)
            # Final export fitted to all 32 files; not used for CV scores.
            fullfile=out/f"profile_{family}_{condition}.json"
            if fullfile.exists():
                profile=json.loads(fullfile.read_text(encoding="utf-8"))
            else:
                warm=None
                if family.endswith("_phase"):
                    parent=out/f"profile_{family.removesuffix('_phase')}_{condition}.json"
                    warm=json.loads(parent.read_text(encoding="utf-8"))["parameters"]
                params,loss,scales,sim=fit_one(family,subset[list(FEATURES)].to_numpy(),unit,features,args.refine,
                                             args.sim_scenes,args.repeats,seed=5001,warm_parameters=warm)
                profile=dict(family=family,condition=condition,parameters=params,train_score=loss,
                             files=len(subset),representative_spacing_a_m=.05,representative_spacing_b_m=.05,
                             geometry_identified=False,propagation_and_hardware_not_separately_identified=True,
                             effective_range_offset_m=float(np.median(subset.peak_bias_m)-np.median(sim[:,-1])),
                             offset_not_used_for_family_selection=True,parent_training_optimum_included=warm is not None)
                save_json(fullfile,profile)
            profiles[f"{condition}:{family}"]=profile
    scores=pd.DataFrame(rows)
    scores.to_csv(out/"heldout_file_scores.csv",index=False,encoding="utf-8-sig")
    pd.DataFrame([dict(**{k:v for k,v in r.items() if k not in ("params","scales")},parameters=json.dumps(r["params"])) for r in fits]).to_csv(out/"fold_fits.csv",index=False)
    summaries=[]
    for condition in ("LOS","NLOS"):
        part=scores[scores.condition.eq(condition)]
        for family,g in part.groupby("family"):
            summaries.append(dict(condition=condition,family=family,cv_score=g.score.mean(),
                                  empirical_reference=g.empirical_reference_score.mean(),
                                  score_ratio=g.score.mean()/g.empirical_reference_score.mean(),
                                  heldout_files=len(g),peak_gap_error=g.peak_gap_abs_error_scaled.mean(),
                                  gram_rank_error=g.gram_rank_abs_error_scaled.mean(),
                                  peak_bias_error=g.peak_bias_abs_error_scaled.mean()))
    summary=pd.DataFrame(summaries).sort_values(["condition","cv_score"])
    summary.to_csv(out/"model_comparison.csv",index=False)
    # Paired bootstrap over eight acquisition-distance groups (not over frames).
    bootstrap=[];rng=np.random.default_rng(4301)
    for condition in ("LOS","NLOS"):
        winner=summary[summary.condition.eq(condition)].iloc[0].family
        p=scores[scores.condition.eq(condition)].pivot_table(index="nominal_m",columns="family",values="score",aggfunc="mean")
        sample=rng.integers(0,len(p),(4000,len(p)))
        for family in FAMILIES:
            diff=(p[family]-p[winner]).to_numpy()
            dist=diff[sample].mean(1)
            bootstrap.append(dict(condition=condition,winner=winner,challenger=family,
                                  challenger_minus_winner=float(diff.mean()),ci025=float(np.quantile(dist,.025)),
                                  ci975=float(np.quantile(dist,.975)),bootstrap_groups=len(p)))
    pd.DataFrame(bootstrap).to_csv(out/"paired_group_bootstrap.csv",index=False)
    winners={condition:profiles[f"{condition}:{summary[summary.condition.eq(condition)].iloc[0].family}"] for condition in ("LOS","NLOS")}
    save_json(out/"recommended_effective_profiles.json",winners)
    print(summary.to_json(orient="records"),flush=True)
    print("FINISHED",out,flush=True)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output",type=Path,default=BASE/"outputs/ble_realcar_channel_fit_20261120")
    p.add_argument("--frame-cap",type=int,default=96)
    p.add_argument("--candidates",type=int,default=192)
    p.add_argument("--sim-scenes",type=int,default=64)
    p.add_argument("--repeats",type=int,default=4)
    p.add_argument("--refine",type=int,default=24)
    args=p.parse_args()
    if min(args.frame_cap,args.candidates,args.sim_scenes,args.repeats)<1 or args.refine<0:
        p.error("invalid search budget")
    run(args)


if __name__=="__main__":
    main()
