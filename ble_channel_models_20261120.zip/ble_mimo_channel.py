"""Shared-geometry, switched 2x2 BLE PBR model (scalar polarization).

References and limitations: BLE_MIMO_MODELS.md. This uses element positions,
common rays and actual sample times, inspired by TR 38.901 Section 7.5. It is
not a reproduction of its scenario tables or of the Bluetooth controller.
All arrays use canonical pair order [(A0,B0),(A0,B1),(A1,B0),(A1,B1)].
"""
from __future__ import annotations

from dataclasses import dataclass, field
import numpy as np

from ble_channel_models import C, ChannelConfig, MeasurementConfig, make_channel, knife_edge_coefficient, tone_grid
from ble_literature_channels import GroundReflection

PAIRS = np.array([[0, 0], [0, 1], [1, 0], [1, 1]], dtype=int)


def _array(x, shape, name):
    value = np.array(x, dtype=float, copy=True)
    if value.shape != shape or not np.isfinite(value).all():
        raise ValueError(f"{name} must have shape {shape} and finite entries")
    return value


def _nonnegative(x, name, positive=False):
    if not np.isfinite(x) or (x <= 0 if positive else x < 0):
        raise ValueError(f"invalid {name}")


@dataclass
class AntennaArray:
    """World coordinates [m]; each endpoint shares an LO across its antennas.

    gain_db and phase_deg are voltage-gain dB and constant hardware phase per
    element; delay_ns is per-direction element hardware group delay. The same
    factor is used on TX/RX here (override calibrated measurements externally
    for nonreciprocal electronics). Optional linear-dipole effective axes give
    scalar co-polarized patterns; default isotropic elements.
    """
    positions_m: object
    velocity_mps: object = (0.0, 0.0, 0.0)
    gain_db: object = (0.0, 0.0)
    phase_deg: object = (0.0, 0.0)
    delay_ns: object = (0.0, 0.0)
    dipole_axes: object | None = None

    def validate(self):
        self.positions_m = _array(self.positions_m, (2, 3), "positions_m")
        self.velocity_mps = _array(self.velocity_mps, (3,), "velocity_mps")
        for key in ("gain_db", "phase_deg", "delay_ns"):
            setattr(self, key, _array(getattr(self, key), (2,), key))
        if self.dipole_axes is not None:
            axes = _array(self.dipole_axes, (2, 3), "dipole_axes")
            norm = np.linalg.norm(axes, axis=1)
            if np.any(norm == 0):
                raise ValueError("dipole axes cannot be zero")
            self.dipole_axes = axes / norm[:, None]

    def at(self, element, time_s):
        return self.positions_m[element] + np.asarray(time_s)[..., None] * self.velocity_mps

    def hardware(self, element, frequency_hz):
        return 10 ** (self.gain_db[element] / 20) * np.exp(
            1j * np.deg2rad(self.phase_deg[element]) - 2j * np.pi * frequency_hz * self.delay_ns[element] * 1e-9)

    def pattern(self, element, direction):
        if self.dipole_axes is None:
            return np.ones(np.shape(direction)[:-1])
        dot = np.sum(direction * self.dipole_axes[element], axis=-1)
        return np.sqrt(np.maximum(0, 1 - np.clip(dot, -1, 1)**2))


def linear_arrays(distance_m=8.0, spacing_a_m=0.05, spacing_b_m=0.05):
    """Parallel y-axis arrays with centers (0,0,0) and (distance,0,0).

    These are explicit example dimensions, NOT estimated hardware geometry.
    """
    _nonnegative(distance_m, "distance_m", positive=True)
    _nonnegative(spacing_a_m, "spacing_a_m")
    _nonnegative(spacing_b_m, "spacing_b_m")
    return (AntennaArray([[0, -spacing_a_m/2, 0], [0, spacing_a_m/2, 0]]),
            AntennaArray([[distance_m, -spacing_b_m/2, 0], [distance_m, spacing_b_m/2, 0]]))


def ground_arrays(distance_m=8., spacing_a_m=.05, spacing_b_m=.05,
                  tx_height_m=1., rx_height_m=1.):
    """Parallel arrays above z=0; distance_m is the center DIRECT/slant range."""
    _nonnegative(distance_m, "distance_m", positive=True)
    _nonnegative(tx_height_m, "tx_height_m", positive=True)
    _nonnegative(rx_height_m, "rx_height_m", positive=True)
    if distance_m <= abs(tx_height_m-rx_height_m):
        raise ValueError("distance_m must exceed absolute antenna height difference")
    horizontal = float(np.sqrt(distance_m**2-(tx_height_m-rx_height_m)**2))
    a,b = linear_arrays(horizontal, spacing_a_m, spacing_b_m)
    a.positions_m = np.asarray(a.positions_m,float)+[0.,0.,tx_height_m]
    b.positions_m = np.asarray(b.positions_m,float)+[0.,0.,rx_height_m]
    return a,b


@dataclass
class Ray:
    gain: complex = 1.0
    vertices_m: object | None = None
    velocity_mps: object = (0.0, 0.0, 0.0)
    label: str = "direct"
    ground: GroundReflection | None = None
    ground_z_m: float = 0.0

    def validate(self):
        if not np.isfinite(self.gain):
            raise ValueError("ray gain must be finite")
        if self.vertices_m is not None:
            v = np.array(self.vertices_m, float, copy=True)
            if v.ndim != 2 or v.shape[1] != 3 or len(v) == 0 or not np.isfinite(v).all():
                raise ValueError("vertices_m must be nonempty P x 3")
            self.vertices_m = v
        self.velocity_mps = _array(self.velocity_mps, (3,), "ray velocity")
        if self.ground is not None:
            self.ground.validate()
            if self.vertices_m is not None or np.any(self.velocity_mps):
                raise ValueError("ground ray uses a fixed mirror plane, no vertices or ray velocity")
            if not np.isfinite(self.ground_z_m):
                raise ValueError("ground_z_m must be finite")


@dataclass
class Screen:
    center_m: object
    normal: object
    horizontal: object
    width_m: float
    penetration_loss_db: float
    roof_height_m: float | None = None

    def validate(self):
        for key in ("center_m", "normal", "horizontal"):
            setattr(self, key, _array(getattr(self, key), (3,), key))
        if np.linalg.norm(self.normal) == 0 or np.linalg.norm(self.horizontal) == 0:
            raise ValueError("screen axes cannot be zero")
        self.normal /= np.linalg.norm(self.normal)
        self.horizontal /= np.linalg.norm(self.horizontal)
        if abs(self.normal @ self.horizontal) > 1e-8:
            raise ValueError("screen normal and horizontal must be orthogonal")
        _nonnegative(self.width_m, "screen width", positive=True)
        _nonnegative(self.penetration_loss_db, "screen loss")
        if self.roof_height_m is not None:
            _nonnegative(self.roof_height_m, "roof height", positive=True)


@dataclass
class MIMOScene:
    array_a: AntennaArray
    array_b: AntennaArray
    rays: list[Ray] = field(default_factory=lambda: [Ray()])
    screen: Screen | None = None
    metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        self.array_a.validate()
        self.array_b.validate()
        for ray in self.rays:
            ray.validate()
        if self.screen is not None:
            self.screen.validate()
        self.reference_distance_m = float(np.linalg.norm(self.array_b.positions_m.mean(0) - self.array_a.positions_m.mean(0)))
        _nonnegative(self.reference_distance_m, "array center distance", positive=True)

    def center_truth(self, time_s):
        a = self.array_a.positions_m.mean(0) + np.asarray(time_s)[..., None] * self.array_a.velocity_mps
        b = self.array_b.positions_m.mean(0) + np.asarray(time_s)[..., None] * self.array_b.velocity_mps
        return np.linalg.norm(b-a, axis=-1)

    def _screen_field(self, a, b, frequency_hz):
        """Fixed world screen, pair-specific intersection and edge excess.

        Each edge is approximated by the closest point to the straight-ray
        intersection, not a stationary-phase optimization on a 3D edge.
        Coherent independent-edge approximation, as in the scalar baseline.
        """
        s = self.screen
        delta = b-a
        direct = np.linalg.norm(delta, axis=-1)
        denom = delta @ s.normal
        frac = np.divide((s.center_m-a) @ s.normal, denom,
                         out=np.full_like(direct, np.nan), where=abs(denom) > 1e-12)
        intersection = a + frac[..., None] * delta
        x = (intersection-s.center_m) @ s.horizontal
        up = np.cross(s.normal, s.horizontal)
        z = (intersection-s.center_m) @ up
        blocked = np.isfinite(frac) & (frac > 0) & (frac < 1) & (abs(x) <= s.width_m/2)
        if s.roof_height_m is not None:
            blocked &= z <= s.roof_height_m
        result = np.ones_like(direct, dtype=complex)
        if not np.any(blocked):
            return result
        aa, bb = a[blocked], b[blocked]
        hit = intersection[blocked]
        d = direct[blocked]
        value = np.full(len(d), 10 ** (-s.penetration_loss_db / 20), complex)
        edges = [hit + (edge-x[blocked])[..., None] * s.horizontal for edge in (-s.width_m/2, s.width_m/2)]
        if s.roof_height_m is not None:
            edges.append(hit + (s.roof_height_m-z[blocked])[..., None] * up)
        for edge in edges:
            length = np.linalg.norm(aa-edge, axis=-1) + np.linalg.norm(bb-edge, axis=-1)
            excess = np.maximum(length-d, 0)
            # Fresnel coefficient already contains the extra propagation phase.
            value += d/length * knife_edge_coefficient(np.sqrt(4 * excess * frequency_hz[blocked] / C))
        result[blocked] = value
        return result

    def response(self, frequency_hz, time_s=0.0, *, include_hardware=True):
        """H[4,K], canonical pairs. Times scalar or [4,K], measured in seconds.

        Exact polyline lengths, including moving endpoints/vertices. A moving
        geometry supplies Doppler automatically; no duplicate Doppler factor.
        Relative spreading d_reference/L retains motion-related path loss.
        """
        f = np.asarray(frequency_hz, float)
        if f.ndim != 1 or len(f) < 1 or not np.isfinite(f).all() or np.any(f <= 0):
            raise ValueError("frequencies must be a positive finite vector")
        t = np.asarray(time_s, float)
        if t.ndim == 0:
            t = np.full((4, len(f)), t)
        if t.shape != (4, len(f)) or not np.isfinite(t).all():
            raise ValueError("time_s must be scalar or [4,K]")
        result = np.zeros((4, len(f)), complex)
        for q, (i, j) in enumerate(PAIRS):
            a = self.array_a.at(i, t[q])
            b = self.array_b.at(j, t[q])
            for ray in self.rays:
                if ray.ground is not None:
                    if np.any(a[:,2] <= ray.ground_z_m) or np.any(b[:,2] <= ray.ground_z_m):
                        raise ValueError("ground-ray endpoints must stay above the mirror plane")
                    image_b, image_a = b.copy(), a.copy()
                    image_b[:,2] = 2*ray.ground_z_m-b[:,2]
                    image_a[:,2] = 2*ray.ground_z_m-a[:,2]
                    outgoing, incoming = image_b-a, image_a-b
                    length = np.linalg.norm(outgoing, axis=-1)
                elif ray.vertices_m is None:
                    delta = b-a
                    length = np.linalg.norm(delta, axis=-1)
                    outgoing = delta
                    incoming = -delta
                else:
                    points = ray.vertices_m[None, :, :] + t[q, :, None, None] * ray.velocity_mps
                    outgoing = points[:, 0]-a
                    incoming = points[:, -1]-b
                    length = np.linalg.norm(outgoing, axis=-1) + np.linalg.norm(incoming, axis=-1)
                    if points.shape[1] > 1:
                        length += np.linalg.norm(np.diff(points, axis=1), axis=-1).sum(axis=1)
                if np.any(length <= 0) or np.any(np.linalg.norm(outgoing, axis=-1) <= 0) or np.any(np.linalg.norm(incoming, axis=-1) <= 0):
                    raise ValueError("degenerate path geometry")
                u = outgoing / np.linalg.norm(outgoing, axis=-1)[:, None]
                v = incoming / np.linalg.norm(incoming, axis=-1)[:, None]
                gain = ray.gain * self.array_a.pattern(i, u) * self.array_b.pattern(j, v)
                if ray.ground is not None:
                    grazing = (a[:,2]+b[:,2]-2*ray.ground_z_m)/length
                    gain = gain*ray.ground.coefficient(f, np.clip(grazing,0,1))
                elif ray.vertices_m is None and self.screen is not None:
                    gain = gain * self._screen_field(a, b, f)
                result[q] += gain * self.reference_distance_m/length * np.exp(-2j*np.pi*f*length/C)
            if include_hardware:
                result[q] *= self.array_a.hardware(i, f) * self.array_b.hardware(j, f)
        return result


def make_mimo_scene(config: ChannelConfig, array_a=None, array_b=None, *, seed=None):
    """Convert scalar profiles to a fixed shared geometrical scene.

    Scalar excess lengths/gains are matched at the ARRAY CENTERS. Reflection
    vertices are sampled on prolate ellipsoids with those centers as foci.
    The ellipsoid distribution is a synthetic prior, not a fitted angular PDP.
    Explicit Ray(vertices_m=...) can supply measured/CAD reflection geometry.
    """
    if (array_a is None) != (array_b is None):
        raise ValueError("provide both endpoint arrays or neither")
    if array_a is None:
        if config.scenario == "two_ray_ground":
            array_a,array_b = ground_arrays(config.distance_m, tx_height_m=config.tx_height_m,
                                            rx_height_m=config.rx_height_m)
        else:
            array_a, array_b = linear_arrays(config.distance_m)
    array_a.validate()
    array_b.validate()
    a, b = array_a.positions_m.mean(0), array_b.positions_m.mean(0)
    d = float(np.linalg.norm(b-a))
    if not np.isclose(d, config.distance_m, rtol=0, atol=1e-8):
        raise ValueError("ChannelConfig.distance_m must match array-center distance")
    if config.scenario == "two_ray_ground":
        if not np.allclose([a[2],b[2]],[config.tx_height_m,config.rx_height_m],rtol=0,atol=1e-8):
            raise ValueError("ground arrays must match configured heights above z=0")
    scalar = make_channel(config, seed=seed)
    rng = np.random.default_rng(np.random.SeedSequence(seed).spawn(1)[0])
    axis = (b-a)/d
    helper = np.array([0., 0., 1.]) if abs(axis[2]) < .9 else np.array([0., 1., 0.])
    side = np.cross(helper, axis)
    side /= np.linalg.norm(side)
    up = np.cross(axis, side)
    screen = None
    if config.scenario in ("human_blockage", "car_blockage"):
        human = config.scenario == "human_blockage"
        screen = Screen(a + config.obstacle_fraction*(b-a) + config.lateral_offset_m*side,
                        axis, side, config.human_width_m if human else config.car_width_m,
                        config.human_penetration_loss_db if human else config.car_penetration_loss_db,
                        None if human else config.car_roof_clearance_m)
        rays = [Ray()]
    else:
        rays = []
        for tap in scalar.taps:
            if tap.ground is not None:
                # The mirror point moves with endpoints; a fixed ellipsoid
                # scatterer would incorrectly change the ground-reflected path.
                rays.append(Ray(gain=1., label=tap.label, ground=tap.ground))
                continue
            if tap.length_m-d < 1e-10:
                rays.append(Ray(gain=tap.gain, label=tap.label))
                continue
            # Uniform ellipsoid direction, NOT uniform surface-area sampling.
            cosine = rng.uniform(-.8, .8)
            phi = rng.uniform(0, 2*np.pi)
            major = tap.length_m/2
            minor = np.sqrt(max(0, major**2-(d/2)**2))
            vertex = (a+b)/2 + major*cosine*axis + minor*np.sqrt(1-cosine**2)*(np.cos(phi)*side+np.sin(phi)*up)
            # Exact spreading applied in response; preserve scalar gain at center.
            rays.append(Ray(gain=tap.gain*tap.length_m/d, vertices_m=[vertex], label=tap.label))
    metadata = dict(scalar.metadata)
    metadata.update(seed=seed, example_geometry=True, calibrated=False,
                    angular_prior="mirror ground plane" if config.scenario == "two_ray_ground"
                                  else "shared ellipsoid vertices, synthetic")
    return MIMOScene(array_a, array_b, rays, screen, metadata)


@dataclass
class TDMSchedule:
    time_forward_s: np.ndarray  # [4,K], canonical pair/frequency index
    time_reverse_s: np.ndarray
    tone_order: np.ndarray  # acquisition position -> ascending-frequency index
    pair_order: np.ndarray  # [K,4], indexed by ascending frequency
    metadata: dict = field(default_factory=dict)

    def __post_init__(self):
        self.time_forward_s = np.array(self.time_forward_s, float, copy=True)
        self.time_reverse_s = np.array(self.time_reverse_s, float, copy=True)
        shape = self.time_forward_s.shape
        if len(shape) != 2 or shape[0] != 4 or shape[1] < 1 or self.time_reverse_s.shape != shape:
            raise ValueError("schedule timestamps require [4,K] arrays")
        if not np.isfinite([self.time_forward_s, self.time_reverse_s]).all() or np.any(self.time_forward_s < 0) or np.any(self.time_reverse_s < 0):
            raise ValueError("schedule timestamps must be finite and nonnegative")
        k = shape[1]
        self.tone_order = np.array(self.tone_order, copy=True)
        self.pair_order = np.array(self.pair_order, copy=True)
        if self.tone_order.dtype.kind not in "iu" or self.tone_order.shape != (k,) or not np.array_equal(np.sort(self.tone_order), np.arange(k)):
            raise ValueError("tone_order must be a permutation of 0..K-1")
        if self.pair_order.dtype.kind not in "iu" or self.pair_order.shape != (k, 4) or not np.all(np.sort(self.pair_order, axis=1) == np.arange(4)):
            raise ValueError("pair_order rows must be permutations of 0..3")


def make_schedule(n_tones, *, slot_s=20e-6, turn_s=40e-6, tone_gap_s=20e-6,
                  frame_start_s=0.0, layout="tone_major", random_tones=False,
                  random_pairs=False, seed=None):
    """Effective sample-center timestamps, not a full BLE timing implementation.

    tone_major: A->B four slots, turnaround, B->A same four slots, next tone.
    pair_major: finish one pair's forward/reverse frequency sweep, next pair.
    Pair/tone shuffles are repeatable; they do NOT implement Bluetooth DRBG.
    An exact hardware schedule can instead instantiate TDMSchedule directly.
    """
    if isinstance(n_tones, bool) or not isinstance(n_tones, (int, np.integer)) or n_tones < 1:
        raise ValueError("n_tones must be a positive integer")
    for value, name in ((slot_s, "slot_s"), (turn_s, "turn_s"), (tone_gap_s, "tone_gap_s"), (frame_start_s, "frame_start_s")):
        _nonnegative(value, name, positive=name == "slot_s")
    if layout not in ("tone_major", "pair_major"):
        raise ValueError("unknown layout")
    if layout == "pair_major" and random_pairs:
        raise ValueError("pair_major uses fixed pair sweep order; set an explicit schedule for other permutations")
    rng = np.random.default_rng(seed)
    order = rng.permutation(n_tones) if random_tones else np.arange(n_tones)
    pairs = np.tile(np.arange(4), (n_tones, 1))
    if random_pairs:
        pairs = np.array([rng.permutation(4) for _ in range(n_tones)])
    fw, rv = np.empty((4, n_tones)), np.empty((4, n_tones))
    now = frame_start_s
    if layout == "tone_major":
        for k in order:
            for rank, q in enumerate(pairs[k]):
                fw[q, k] = now + (rank+.5)*slot_s
                rv[q, k] = now + 4*slot_s + turn_s + (rank+.5)*slot_s
            now += 8*slot_s + turn_s + tone_gap_s
    else:
        for q in range(4):
            for k in order:
                fw[q, k] = now + .5*slot_s
                rv[q, k] = now + 1.5*slot_s + turn_s
                now += 2*slot_s + turn_s + tone_gap_s
    return TDMSchedule(fw, rv, order, pairs,
                       dict(layout=layout, slot_s=slot_s, turn_s=turn_s, tone_gap_s=tone_gap_s,
                            frame_start_s=frame_start_s, duration_s=now-frame_start_s,
                            exact_bluetooth_timing=False, exact_bluetooth_drbg=False))


@dataclass
class LOConfig:
    residual_cfo_hz: float = 0.0
    initial_phase_rad: float = 0.0
    wiener_std_rad_per_sqrt_s: float = 0.0


@dataclass
class LOTrace:
    time_s: np.ndarray
    phase_rad: np.ndarray

    def at(self, time_s):
        query = np.asarray(time_s)
        ids = np.searchsorted(self.time_s, query)
        if np.any(ids >= len(self.time_s)) or not np.array_equal(self.time_s[ids], query):
            raise ValueError("LO trace must contain every requested timestamp exactly")
        return self.phase_rad[ids]


def make_lo_trace(schedules, config=None, *, seed=None):
    """One differential-LO process over ALL supplied frames/sample times."""
    cfg = config or LOConfig()
    _nonnegative(cfg.wiener_std_rad_per_sqrt_s, "Wiener strength")
    if not np.isfinite([cfg.residual_cfo_hz, cfg.initial_phase_rad]).all():
        raise ValueError("LO parameters must be finite")
    if not schedules:
        raise ValueError("at least one schedule is needed")
    times = np.unique(np.concatenate([s.time_forward_s.ravel() for s in schedules] +
                                     [s.time_reverse_s.ravel() for s in schedules]))
    rng = np.random.default_rng(seed)
    brownian = np.cumsum(rng.normal(size=len(times)) * np.sqrt(np.diff(np.r_[0.0, times])))
    phase = cfg.initial_phase_rad + 2*np.pi*cfg.residual_cfo_hz*times + cfg.wiener_std_rad_per_sqrt_s*brownian
    return LOTrace(times, phase)


@dataclass
class MIMOMeasurement:
    iq_forward: np.ndarray
    iq_reverse: np.ndarray
    combined_iq: np.ndarray
    clean_forward: np.ndarray
    clean_reverse: np.ndarray
    valid_mask: np.ndarray
    schedule: TDMSchedule
    lo_phase_forward: np.ndarray
    lo_phase_reverse: np.ndarray
    pair_truth_m: np.ndarray
    center_truth_m: float
    noise_power_per_endpoint: float


def measure_mimo(scene, frequency_hz=None, schedule=None, measurement=None, lo=None, *, seed=None, lo_trace=None):
    """Independent thermal noise + a single differential-LO time process.

    Differential LO has opposite signs on forward/reverse reception; at equal
    times it cancels, at unequal times residual CFO/phase drift remain. The
    common process is shared by all switched antenna pairs. Optional independent
    per-tone phase noise models the remaining integration/estimation error.
    """
    f = np.array(tone_grid() if frequency_hz is None else frequency_hz, float, copy=True)
    if f.ndim != 1 or len(f) < 1 or not np.isfinite(f).all() or np.any(f <= 0) or np.any(np.diff(f) <= 0):
        raise ValueError("frequencies must be ascending, finite and positive")
    cfg = measurement or MeasurementConfig()
    oscillator = lo or LOConfig()
    sched = schedule or make_schedule(len(f))
    for ts in (sched.time_forward_s, sched.time_reverse_s):
        if np.shape(ts) != (4, len(f)) or not np.isfinite(ts).all() or np.any(ts < 0):
            raise ValueError("schedule timestamps must be nonnegative [4,K] arrays")
    if not (np.isfinite(cfg.snr_db) or cfg.snr_db == np.inf):
        raise ValueError("invalid SNR")
    if cfg.snr_reference not in ("unblocked", "received"):
        raise ValueError("invalid SNR reference")
    if not np.isfinite(cfg.missing_probability) or not 0 <= cfg.missing_probability <= 1:
        raise ValueError("invalid missing_probability")
    _nonnegative(cfg.phase_noise_std_deg, "phase noise")
    _nonnegative(oscillator.wiener_std_rad_per_sqrt_s, "Wiener strength")
    if not np.isfinite([oscillator.residual_cfo_hz, oscillator.initial_phase_rad]).all():
        raise ValueError("LO parameters must be finite")
    hf = scene.response(f, sched.time_forward_s)
    hr = scene.response(f, sched.time_reverse_s)
    # Separate random streams: enabling an LO impairment cannot change AWGN.
    streams = np.random.SeedSequence(seed).spawn(4)
    lo_rng, phase_rng, noise_rng, mask_rng = [np.random.default_rng(s) for s in streams]
    if lo_trace is None:
        all_time = np.concatenate((sched.time_forward_s.ravel(), sched.time_reverse_s.ravel()))
        times, inv = np.unique(all_time, return_inverse=True)
        brownian = np.cumsum(lo_rng.normal(size=len(times)) * np.sqrt(np.diff(np.r_[0.0, times])))
        phase = oscillator.initial_phase_rad + 2*np.pi*oscillator.residual_cfo_hz*times + oscillator.wiener_std_rad_per_sqrt_s*brownian
        mapped = phase[inv].reshape(2, 4, len(f))
    else:
        mapped = np.array([lo_trace.at(sched.time_forward_s), lo_trace.at(sched.time_reverse_s)])
    ref_power = 1.0 if cfg.snr_reference == "unblocked" else float((np.mean(abs(hf)**2)+np.mean(abs(hr)**2))/2)
    power = ref_power * 10 ** (-cfg.snr_db/10)
    observed = []
    for h, sign, theta in ((hf, 1, mapped[0]), (hr, -1, mapped[1])):
        independent_phase = phase_rng.normal(0, np.deg2rad(cfg.phase_noise_std_deg), h.shape)
        noise = np.sqrt(power/2) * (noise_rng.normal(size=h.shape)+1j*noise_rng.normal(size=h.shape))
        observed.append(h*np.exp(1j*(sign*theta+independent_phase))+noise)
    valid = mask_rng.random(hf.shape) >= cfg.missing_probability
    a, b = [np.where(valid, x, 0j) for x in observed]
    middle = (sched.time_forward_s+sched.time_reverse_s)/2
    truth = np.array([np.linalg.norm(scene.array_b.at(j, middle[q])-scene.array_a.at(i, middle[q]), axis=-1)
                      for q, (i, j) in enumerate(PAIRS)])
    return MIMOMeasurement(a, b, a*b, hf, hr, valid, sched, mapped[0], mapped[1], truth,
                           float(scene.center_truth(np.mean(middle))), power)
