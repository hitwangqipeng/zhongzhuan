# BLE 2.4 GHz 文献信道：模型、参数与使用方式

本次新增 8 个场景，统一通过 `ble_channel_models.ChannelConfig` / `make_channel` 调用；同时支持 `ble_mimo_channel.make_mimo_scene` 的 2×2 时分采样。原有 5 个场景仍可使用。

这些实现提供单向传播响应 H(f)，然后由测量层生成两端 IQ 并相乘。本文没有新增实车拟合，也没有改变之前十个有效信道候选的拟合结果。文献参数、可调工程参数和实车拟合参数是三种不同来源。

## 模型选择

| scenario | 结构与依据 | 默认参数 | 适合检验的问题 |
|---|---|---|---|
| `exponential_pdp` | 等时延间隔、平均功率指数衰减、独立复高斯抽头；参考 IEEE 802.11-97/125 | 功率衰减常数 50 ns、步长 5 ns、功率截断 40 dB | 连续散射尾部、频率选择性；参数是工程基线 |
| `sv_2p4ghz` | 簇间和簇内双 Poisson 到达，功率分别指数衰减；2.4 GHz 建筑实测论文 | Γ=35.6 ns、γ=36.5 ns、平均簇间隔 130 ns、平均射线间隔 7 ns | 有分簇结构的室内多径 |
| `two_ray_ground` | 直达＋平滑地面 Fresnel 反射；ST AN5528 有 BLE RSSI 对照实验 | 收发高度各 1 m、相对介电常数 2.5、电导率 0、垂直极化 | 室外直视、天线高度导致的相消和反射峰 |
| `tgn_b` | TGn B 的 SISO 功率时延表 | 9 抽头、2 簇，名义 NLOS RMS DS=15 ns | 较小室内空间基准 |
| `tgn_c` | TGn C 的 SISO 功率时延表 | 14 抽头、2 簇，名义 NLOS RMS DS=30 ns | 住宅/办公室基准 |
| `tgn_d` | TGn D 的 SISO 功率时延表 | 18 抽头、3 簇，名义 NLOS RMS DS=50 ns | 中等时延扩展 |
| `tgn_e` | TGn E 的 SISO 功率时延表 | 18 抽头、4 簇，名义 NLOS RMS DS=100 ns | 较丰富室内多径 |
| `tgn_f` | TGn F 的 SISO 功率时延表 | 18 抽头、6 簇，名义 NLOS RMS DS=150 ns | 大空间、长延迟尾部的压力测试 |

TGn B–F 默认 `tgn_los=False`。开启 `tgn_los=True` 后，只在首抽头增加确定性分量，其首抽头 K 因子分别为 0、0、3、6、6 dB。0 dB 表示等功率的确定性与散射分量；无确定性 LOS 时 K 是负无穷 dB。表格中的名义 DS 指 NLOS；LOS 增强后实际 DS 会改变。

地库可以用 TGn E/F 检查长尾鲁棒性，但它们不是经过本地地库测量标定的模型。原有 `garage` 是“衰减直达＋指定镜面径＋随机散射尾部”的可调工程组合。人体、车体遮挡的 `human_blockage` / `car_blockage` 仍是有限屏幕边缘绕射近似，也不是从这些室内文献中获得的遮挡参数。

## 一、统一的信号与幅度约定

所有路径长度、抽头时延均是单向量：

\[
H(f)=\sum_\ell a_\ell(f)\exp\{-j2\pi f[d/c+\tau_{\rm onset}+\tau_\ell]\}.
\]

- `distance_m=d` 是天线中心直线距离的真值，单位 m。
- 随机场景的 `excess_onset_ns` 只移动最早到达路径；默认 0 ns。它可以表示用户指定的额外首径延迟，但不是文献拟合出的通用 NLOS 偏差，也不修改真值。
- 统计模型在零超额时延处有一个随机首抽头，并不表示存在确定性直达路径。
- 统计模型将条件于时延结构的期望抽头总功率设为 1；不按每个样本的实际增益进行 AGC。因此不同随机实现仍有功率起伏。
- 地面两径以相同直达距离处的无遮挡单位场为参考，反射路径保留 d/L 的相对扩散损耗；不额外把接收总功率归一成 1。
- 各模型默认不施加绝对 Friis 路损、发射功率、天线增益或大尺度阴影。这些可另行叠加；不要把这里的幅度当作 dBm。

测量层保持原约定：

\[
Y_A=H\,e^{j\epsilon_A}+n_A,\qquad
Y_B=H\,e^{j\epsilon_B}+n_B,\qquad Z=Y_A Y_B.
\]

静态、互易、无噪声时 Z=H²，不是 H·conj(H)。不能在传播层先把路径长度乘 2，再在测量层乘一次。真实日志若已经是 combined IQ，也不能再次平方。

`MeasurementConfig.phase_noise_std_deg` 是每端、每频点独立相位误差的工程模型，默认 0，并非这里各文献已标定的芯片相位噪声。`snr_db` 是每端 SNR；`snr_reference="unblocked"` 使用参考功率 1，`"received"` 根据该实现的频带内接收功率定义噪声。

## 二、指数 PDP

实现位置：`ble_literature_channels.exponential_profile`。

\[
\tau_\ell=\ell\Delta\tau,\qquad
p_\ell=\frac{e^{-\tau_\ell/\tau_d}}{\sum_m e^{-\tau_m/\tau_d}},\qquad
a_\ell\sim\mathcal{CN}(0,p_\ell).
\]

`exp_decay_ns` 控制功率衰减，不是幅度衰减。`exp_cutoff_db` 指平均功率相对首抽头下降的 dB；默认保留不低于 −40 dB 的抽头。有限截断和离散化使实际 RMS DS 略偏离连续时间常数；以输出 metadata 的 `rms_delay_spread_ns` 为准。

IEEE 802.11-97/125 介绍了测量支持的指数平均 PDP、Rayleigh 幅度与均匀相位简化模型。50 ns / 5 ns / 40 dB 是本项目公开的工程默认值，不是该文件针对某个 BLE 场景拟合出的三元参数。

与旧拟合候选 `exponential_diffuse` 的区别：旧候选固定 32 条随机时延射线；新 `exponential_pdp` 使用等间隔抽头和显式指数平均功率表。不能将两者的参数或既有拟合评分直接互换。

## 三、2.4 GHz 实测 S–V

依据：Blažević、Zanchi、Marinović，JCOMSS 2007，2.4 GHz 中心频率、400 MHz 测量带宽、大学建筑 VNA 实测。

\[
T_{k+1}-T_k\sim\operatorname{Exp}(\text{mean}=130\text{ ns}),\qquad
\tau_{r+1,k}-\tau_{r,k}\sim\operatorname{Exp}(\text{mean}=7\text{ ns}),
\]

\[
\mathbb E|a_{r,k}|^2\propto e^{-T_k/35.6\text{ ns}}e^{-\tau_{r,k}/36.5\text{ ns}}.
\]

35.6 ns、36.5 ns 采用论文表2 `Fit` 列的回归值；130 ns、7 ns 采用表3 `Adjusted` 列。表2同时给出了不同的 Mean/Median，不能混用而不注明。

本实现显式使用双 Poisson 到达过程：首簇、簇内首射线从零开始，其余到达时间由指数间隔生成，只保留总超额时延不超过 `sv_max_delay_ns=400` 的射线。簇数和每簇射线数均可变化。有限观察窗采样、条件期望功率归一化是本实现的工程约定，没有声称逐项复现论文所有仿真计数步骤。

配置字段：`sv_cluster_decay_ns`、`sv_ray_decay_ns`、`sv_cluster_interval_ns`、`sv_ray_interval_ns`、`sv_max_delay_ns`。修改前四项后，输出仍记录全部值，但不再是原文献的默认拟合参数。

与旧 `clustered_sv` 候选的区别：旧候选固定 3 簇×8 径，并用不同的时延/衰减参数化；新模型采用上述文献的四个统计参数与可变射线数。论文场景不包含实车车体或人体遮挡标定。

## 四、TGn B–F 的 SISO PDP 子集

本次实际核对和转录的来源是 **IEEE 802.11-03/940r1，January 2004**，Appendix C，印刷页35–41；不是尚未逐表核验的 r4 版本。参数表集中在 `TGN_TABLES`，以“簇起始抽头索引＋簇内 dB 功率”保存，缺失项是负无穷。重叠簇必须先转为线性功率再求和：

\[
p_\ell^{\rm diffuse}\propto\sum_k10^{P_{k,\ell}^{\rm dB}/10}.
\]

NLOS 抽头是独立复高斯变量。LOS 按报告第4节处理：保持原散射 PDP，在首抽头**额外增加**确定性功率 `K_linear × p_diffuse[0]`，然后统一期望功率归一化。K 是首抽头内部的确定性/散射功率比，不能按整个 PDP 的总散射功率定义。

| 模型 | 最大超额时延 ns | 抽头数 | 簇数 | 名义 NLOS RMS DS ns | 根据转录表算得的 RMS DS ns（约） |
|---|---:|---:|---:|---:|---:|
| B | 80 | 9 | 2 | 15 | 15.65 |
| C | 200 | 14 | 2 | 30 | 33.44 |
| D | 390 | 18 | 3 | 50 | 50.16 |
| E | 730 | 18 | 4 | 100 | 98.98 |
| F | 1050 | 18 | 6 | 150 | 148.80 |

代码保留原表，不通过伸缩时延把数值强行调整到名义 DS。输出同时包含名义值和实际计算值。`rms_delay_spread_ns` 是单向期望 PDP 的统计量，不是对双向 IQ 的 IFFT 峰宽。

**实现边界：**这里加入的是静态 SISO PDP 与首抽头 LOS 规则；没有实现 TGn 全部角度表、Laplacian 角度分布、标准空间相关矩阵、标准 Doppler 滤波器、路径损耗或阴影相关过程。2×2 复用本项目原有共享椭球散射点扩展，因此不能将它称为完整 TGn MIMO 实现。metadata 明确给出 `full_tgn_spatial_model=False` / `full_tgn_doppler_model=False`。

## 五、几何地面反射两径

`distance_m=d` 保持直达斜距定义。收发天线离平面 z=0 的高度为 h_t、h_r 时：

\[
x=\sqrt{d^2-(h_t-h_r)^2},\quad L_0=d,\quad
L_g=\sqrt{x^2+(h_t+h_r)^2}=\sqrt{d^2+4h_th_r}.
\]

要求高度为正，d>|h_t−h_r|。归一化单向响应为：

\[
H(f)=e^{-j2\pi fL_0/c}+\Gamma_g(f,\theta)\frac{d}{L_g}e^{-j2\pi fL_g/c}.
\]

代码按地面复介电常数 `epsilon_r − j·sigma/(2πf epsilon_0)` 计算频率相关 Fresnel 场反射系数；支持 `vertical`（TM，固定世界极化符号约定）与 `horizontal`（TE）。`ground_grazing_sine` 使用相对于地面的掠射角，不是相对于法线的入射角。

ST AN5528 §2.4 在 BlueNRG-2、2454 MHz、收发高度1 m、沙地条件下比较了 RSSI 与两径预测。它支持这一物理机制，但没有验证 Channel Sounding 的逐频点复数 IQ，也不提供你的车体、地库或芯片校准参数。默认 epsilon_r=2.5 对应其沙地示例；电导率0和平滑无限平面等是简化。

2×2 模型使用镜像法在每个实际采样时刻重新计算每对天线的反射路径。不能用一个固定反射散射点代替移动端点的镜像几何。直接传数组时，需要两端中心 z 与配置高度匹配；便捷函数 `ground_arrays` 可以构造示例。

## 六、Python 用法

```python
import numpy as np
from ble_channel_models import ChannelConfig, MeasurementConfig, make_channel, measure, tone_grid, to_cir

f = tone_grid("legacy80")
cfg = ChannelConfig(scenario="tgn_d", distance_m=8.0, tgn_los=False,
                    excess_onset_ns=0.0)
ch = make_channel(cfg, f, seed=42)
obs = measure(ch, MeasurementConfig(snr_db=25.0), seed=43)
range_axis_m, cir = to_cir(f, obs.combined_iq, nfft=512)
print(ch.metadata)  # 来源、期望功率、单向 DS、实现边界

# 2.4 GHz 文献 S–V：使用默认四个文献参数
sv = make_channel(ChannelConfig(scenario="sv_2p4ghz", distance_m=8), f, seed=42)

# 几何两径：距离是真正的直线斜距
ground = make_channel(ChannelConfig(scenario="two_ray_ground", distance_m=8,
    tx_height_m=.7, rx_height_m=1.2, ground_relative_permittivity=4.2,
    ground_conductivity_s_per_m=.01, ground_polarization="vertical"), f)
```

2×2 TDM：

```python
from ble_mimo_channel import ground_arrays, make_mimo_scene, make_schedule, measure_mimo

cfg = ChannelConfig(scenario="two_ray_ground", distance_m=8,
                    tx_height_m=.7, rx_height_m=1.2)
a, b = ground_arrays(8, spacing_a_m=.05, spacing_b_m=.05,
                     tx_height_m=.7, rx_height_m=1.2)
b.velocity_mps = [0.5, 0, 0]
scene = make_mimo_scene(cfg, a, b, seed=42)
schedule = make_schedule(len(f), slot_s=20e-6, turn_s=40e-6)
obs = measure_mimo(scene, f, schedule, MeasurementConfig(snr_db=25), seed=43)
assert obs.combined_iq.shape == (4, 80)
```

若把四路当四个单天线分析，可分别取 `obs.combined_iq[q]`，不要沿四路轴求平均。若需要四个彼此独立的单天线环境，则调用四次 `make_channel` 并使用不同 seed；这和同一场景的四条天线链路具有不同的统计含义。

## 七、命令行与导出

```powershell
# 新增8种场景，每种生成100个独立静态单链路实现
python generate_ble_channels.py --scenario literature --samples 100 --grid legacy80 --output outputs/literature_scalar

python generate_ble_channels.py --scenario tgn_d --tgn-los --samples 100 --output outputs/tgn_d_los
python generate_ble_channels.py --scenario sv_2p4ghz --samples 100 --output outputs/sv_measured_prior
python generate_ble_channels.py --scenario exponential_pdp --exp-decay-ns 50 --exp-step-ns 5 --output outputs/exp_pdp

# 固定共享场景的2×2时分测量；frames是时间帧，不是独立环境
python generate_ble_mimo.py --scenario literature --frames 16 --output outputs/literature_mimo
python generate_ble_mimo.py --scenario two_ray_ground --tx-height-m .7 --rx-height-m 1.2 --velocity-b-mps .5 0 0 --frames 16 --output outputs/ground_mimo
```

`--scenario all` 现在包含原有5种＋新增8种。`--phase-noise-std-deg` 和 `--snr-reference` 两个脚本均支持；其他新增参数可用 `--help` 查看。旧的单场景命令保持有效。

导出继续支持 combined NPZ、两端 paired NPZ 和80频点的现有 TI 输入配置。协议 JSON 记录配置、seed 和来源/实现边界；SISO metadata 示例仅对应最后一个实现，其他实现可用导出 seed 复算。

`ble72` 必须按物理1 MHz网格插入缺失频点再做 IFFT，不能把72项直接当成连续频点。1 MHz采样使时延周期为1微秒，双向距离周期约149.9 m。TGn E/F 的长尾及 H² 交叉项可能发生时延混叠；代码保留原始路径，不偷偷截断。增大 IFFT 点数只细化显示网格，不能扩大无模糊范围或提升实际带宽分辨率。

## 八、验证与下一步拟合

运行：

```powershell
python -m unittest discover -s tests -p "test_ble*.py" -v
```

新增验证包括：原始表簇重叠的线性功率求和、抽头平均功率和非AGC起伏、首抽头 K 因子、S–V 到达过程统计、Fresnel 法向/掠射/Brewster 极限、远距离两径功率规律、标量与重合天线 MIMO 一致性、运动地面反射的逐时刻几何、互易乘积、配置校验和原 TI 输入读取。

这些是实现正确性测试，不能替代外场验证。旧拟合脚本 `ble_channel_fit.py` / `ble_single_channel_fit.py` 的 `FAMILIES` 及旧评分保持原样；新增场景尚未加入其参数搜索，也未重新拟合实车数据。因此不能把旧“指数散射＋相位扰动”的最优评分移植到新模型。

公开 BLE IQ 数据集 [10.5281/zenodo.17347695](https://doi.org/10.5281/zenodo.17347695) 可以作为后续独立验证来源。本次不下载该数据，不将其作为已完成的标定结果。

## 参考资料

1. Richard van Nee, **Delay Spread Requirements for Wireless Networks in the 2.4 GHz and 5 GHz Bands**, IEEE P802.11-97/125, 1997. [IEEE原文](https://www.ieee802.org/11/Documents/DocumentArchives/1997_docs/71252.pdf)
2. Zoran Blažević, Igor Zanchi, Ivan Marinović, **Propagation Measurements at 2.4 GHz Inside a University Building and Estimation of Saleh–Valenzuela Parameters**, JCOMSS 3(2), 99–107, 2007. [DOI](https://doi.org/10.24138/jcomss.v3i2.258) · [原文PDF](https://jcoms.fesb.unist.hr/pdfs/jcomss_v3n2_june2007_99-107.pdf)
3. Vinko Erceg et al., **Indoor MIMO WLAN TGn Channel Models**, IEEE 802.11-03/940r1, January 2004. 本次实现实际核验的数值表版本。[报告镜像](https://iitk.ac.in/mwn/papers/11-03-0940-01-000n-tgn-channel-models.pdf)
4. STMicroelectronics, **AN5528 — Radio communication range estimation in ISM band**, Rev 2, July 2022, §1.3–1.4 / §2.4. [ST官方PDF](https://www.st.com/resource/en/application_note/dm00718575-radio-communication-range-estimation-in-ism-band-stmicroelectronics.pdf)
5. Jorg Wieme et al., **Performance Evaluation of Bluetooth Channel Sounding on Commercial Hardware**, IEEE Access, 2025, DOI 10.1109/ACCESS.2025.3623242. [论文](https://doi.org/10.1109/ACCESS.2025.3623242) · [公开IQ数据](https://doi.org/10.5281/zenodo.17347695)
