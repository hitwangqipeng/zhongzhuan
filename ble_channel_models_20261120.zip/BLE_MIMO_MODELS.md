# 2×2 时分多天线 BLE IQ 仿真

新增的8种文献信道也可通过本文接口使用，详见 [BLE_LITERATURE_CHANNELS.md](BLE_LITERATURE_CHANNELS.md)。几何地面两径使用 `ground_arrays` 构建离地天线，并在每个时分采样时刻重算镜像反射路径。TGn 仅引入 SISO 功率时延表，空间扩展沿用共享几何，不宣称完整 TGn MIMO 复现。

本模块在现有单程信道模型上增加共享几何、四组天线对、正反向时分采样、公共振荡器过程和导出。没有启动网络训练。

## 文献依据与实现边界

| 资料 | 实现采用的内容 | 未声称实现的部分 |
|---|---|---|
| [Bluetooth Core 6.2 Vol.6 Part H §4.7.4–4.7.5](https://www.bluetooth.com/wp-content/uploads/Files/Specification/HTML/Core-62/out/en/low-energy-controller/channel-sounding.html) | 2:2 对应四组天线对；正反向相同切换次序；天线组合和采样次序分开存储 | 完整控制器时序、扩展 slot、标准 DRBG |
| [3GPP TR 38.901 V18.0.0 §7.5，尤其式7.5-22附近](https://www.etsi.org/deliver/etsi_tr/138900_138999/138901/18.00.00_60/tr_138901v180000p.pdf) | 同一条 ray 共享散射系数，通过阵元位置、方向响应和运动生成各链路相位 | 完整场景参数表、簇出生消失、双极化、互耦 |
| [Clarke 1968, A Statistical Theory of Mobile-Radio Reception](https://doi.org/10.1002/j.1538-7305.1968.tb00069.x) | 二维各向同性散射的空间相关 J0 极限作为独立数值检查 | 直接用 J0 替代实车环境的实际相关性 |
| [Droemmer & Gardill, Channel Modeling for Phase-Based Ranging](https://arxiv.org/html/2608.17497v1) | 频域 tone 级接口、传播与测量损伤分离 | 整篇论文复现或实测参数复现 |

普通路径使用 `H_ij(f,t)=sum(alpha_p G_ij,p exp(-j2pi f L_ij,p(t)/c))`。直达径和用户显式给出的多段散射路径都按实际三维长度计算。移动端点或散射体直接改变长度，从而产生多普勒；不重复加运动相位。

默认反射点放在两端阵列中心为焦点的椭球上，保证在阵列中心匹配单天线模型给定的超额路径和复增益。该角度分布是合成先验，不是 3GPP 场景表或实测拟合结果。用户可用 `Ray(vertices_m=...)` 提供 CAD/测量路径；它支持单次或多次折线散射，不自动求平面镜面反射点。

人体/车体沿用有限吸收屏障 Fresnel 边缘近似，但屏障固定在世界坐标中，对每组连线重新计算穿越位置及边缘绕行长度。它不是圆柱介质 UTD、完整三维绕射或车体 CAD 射线追踪。

## 直接调用

```python
import numpy as np
from ble_channel_models import ChannelConfig, MeasurementConfig, tone_grid
from ble_mimo_channel import (
    linear_arrays, make_mimo_scene, make_schedule, measure_mimo, LOConfig,
)

f = tone_grid("legacy80")
a, b = linear_arrays(distance_m=8, spacing_a_m=.05, spacing_b_m=.05)
# 5 cm 只是示例，不是从日志反推出的真实间距。
b.velocity_mps = [0., 0., 0.]
scene = make_mimo_scene(ChannelConfig(scenario="garage", distance_m=8), a, b, seed=42)
schedule = make_schedule(
    len(f), slot_s=20e-6, turn_s=40e-6, tone_gap_s=20e-6,
    layout="tone_major", random_tones=True, random_pairs=True, seed=43,
)
m = measure_mimo(scene, f, schedule, MeasurementConfig(snr_db=30),
                 LOConfig(residual_cfo_hz=2), seed=44)
assert m.combined_iq.shape == (4, 80)
np.testing.assert_allclose(m.combined_iq, m.iq_forward*m.iq_reverse)
```

固定组合顺序：`[(A0,B0),(A0,B1),(A1,B0),(A1,B1)]`。`pair_order[k]` 指第 k 个频点实际时隙到固定组合的排列；`tone_order` 指采集次序到递增频率索引的排列。输出 IQ 一直按固定组合、递增频率索引存放。

## 时序、运动和硬件

- `tone_major`：每个频点先正向四个 slot，转向后反向四个 slot，再跳频；正反向组合顺序相同。
- `pair_major`：完成某组天线对的逐频正反向扫描，再测下一组。
- 默认 20 μs slot、40 μs 转向和20 μs频点间隔是示例有效采样时序。它们不是根据本地日志测得，也不是完整 CS step。
- 已知真实采样中心时刻时，直接构造 `TDMSchedule(time_forward_s, time_reverse_s, tone_order, pair_order)`。
- 每端共用振荡器；差分相位过程在正反向接收时符号相反。常数相位抵消；CFO 残差依赖 `t_forward-t_reverse`。随频率变化的时间差才会产生相应的额外相位斜率。
- 热噪声对接收端、天线对和测量时刻独立；额外独立相位噪声代表积分/估计残差，不替代共享振荡器。
- 跨多帧 Wiener 相位必须共享 `make_lo_trace(schedules, LOConfig(...))`；单独调用 `measure_mimo` 且不传 trace 时，默认只生成本次调用内的相位过程。
- `AntennaArray` 支持阵元固定增益、相位、群时延及可选线性偶极子方向图。当前硬件因子假设收发相同；严格非互易前端和全极化需另外校准/扩展。

单程所有路径长度均以米为单位。每个天线对独立执行 `Y_forward*Y_reverse`，静态无噪声且零硬件/LO损伤时等于 `H_ij**2`，包含传播路径间交叉项。对反向信道不取共轭。

## 批量生成与 TI 接入

```powershell
python generate_ble_mimo.py --scenario all --frames 16 --grid legacy80 --output outputs/ble_mimo_examples
python generate_ble_mimo.py --scenario garage --frames 16 --shuffle-tones --shuffle-pairs --velocity-b-mps 0.2 0 0 --cfo-hz 2 --wiener-std 0.2
python ti_ble_ranging_project/run.py --config outputs/ble_mimo_examples/garage_combined_ti.json --output outputs/ble_mimo_ti_smoke
```

`--distance-m`、`--spacing-a-m`、`--spacing-b-m`、`--layout`、`--slot-us`、`--turn-us`、`--tone-gap-us`、`--frame-period-ms` 均可配置。每个场景的所有帧共享同一组散射体；跨帧变化来自运动、振荡器和噪声，不会每帧重抽信道。

| 输出 | 内容 |
|---|---|
| `*_mimo.npz` | `iq/iq_forward/iq_reverse[N,4,K]`、无噪声信道、mask、正反向时间戳、排列、逐 tone 天线对距离、阵列中心距离 |
| `*_mimo.json` | 阵元坐标/速度/硬件参数、完整散射点、屏障几何、生成协议 |
| `*_combined.npz` | 现有加载器可读的 `[N*4,K]` 已组合 IQ、event/path ID |
| `*_paired.npz` | 现有加载器可读的两个接收端、匹配 ID |
| `*_combined_ti.json` / `*_paired_ti.json` | 80点模式的现有 TI 加载配置 |

运动时逐 tone 距离不同；完整 NPZ 保留该真值。为兼容现有单值距离接口，扁平 NPZ 的标签使用该天线对逐 tone 距离的平均值。72点模式保留原频率网格，不隐式插值成80点。

## 本地实测检查

`analyze_ble_mimo_iq.py` 只读原始文件/缓存，使用原先已核对的已组合 IQ，不再次平方。台架从环境×工况×距离分层选72个文件，实车从已有 source audit 等间隔选32个文件，每文件最多64个完整帧，共104文件、6656帧。每帧必须恰好有0..3四路，重复和不完整帧拒绝；先求每文件中位数，再跨文件汇总。

| 实测工况 | 文件数 | 四路间频谱相似度 | 四路功率最大/最小差 dB | 强峰位置两两差 m |
|---|---:|---:|---:|---:|
| 台架三脚架 | 18 | 0.579 | 4.575 | 0.897 |
| 台架人体转身 | 18 | 0.476 | 4.555 | 1.098 |
| 台架手持 | 18 | 0.715 | 5.533 | 0.549 |
| 台架遮挡 | 18 | 0.319 | 2.981 | 3.001 |
| 实车 LOS | 16 | 0.284 | 3.679 | 2.964 |
| 实车 NLOS | 16 | 0.235 | 3.188 | 5.563 |

频谱相似度为同帧两路频率向量归一化复内积的模；表内先对每文件的帧/六种两两组合取中位数，再跨文件取中位数。该指标不是空间协方差，也没有把相关频点当作独立空间样本。强峰差不是测距误差，也不证明真实路径长度相差数米；它还受到多径、噪声、硬件响应影响。

这些结果支持四路使用不同且相关的响应，不能证明已识别出某个唯一传播模型。日志里的四路共享帧级时间戳，未提供逐 tone 切换采样时刻；目前没有经确认的天线坐标、raw path到物理天线对映射、完整方向图和收发前端校准。因而示例间距、切换时间和角度分布没有以这些统计为由冒称已标定。

复现分析：`python analyze_ble_mimo_iq.py`。结果位于 `outputs/ble_mimo_audit_20261120`，包括原始文件/缓存哈希、采样协议和逐文件/逐组合统计。代码包附分析结果，不包含用户原始 IQ。

## 验证

`python -m unittest discover -s tests -p "test_ble*.py" -v`

多天线新增20项检查，覆盖：精确几何相位、零间距退化到五种原模型、显式多段散射、空间连续性、二维各向同性 J0 极限、静态双向平方及交叉项、独立热噪声、正反向 LO 抵消与 CFO 残差、端点/散射体运动、群时延、四路不同遮挡、排列/时间戳、跨帧公共 LO、实测配帧去重、TI输入兼容。既有单天线15项检查保留。

实车有效模型拟合另见 `fit_ble_realcar.py`、`ble_channel_fit.py` 和 `outputs/ble_realcar_channel_fit_20261120/BLE_REALCAR_FIT.md`。该扩展增加8项检查，包括批量生成与本模块精确几何的一致性、特征不变性、CRPS、距离分组及相位扰动对幅度/CIR的不同作用。
