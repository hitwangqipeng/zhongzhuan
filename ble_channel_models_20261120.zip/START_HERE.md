# BLE 2x2 channel models

- NEW literature channels and Chinese documentation: BLE_LITERATURE_CHANNELS.md
- Generate the 8 added models: python generate_ble_channels.py --scenario literature --samples 100
- Literature plots/metadata: outputs/ble_literature_validation_20261123
- Multi-antenna API: BLE_MIMO_MODELS.md
- Real-car fitting report: outputs/ble_realcar_channel_fit_20261120/BLE_REALCAR_FIT.md
- Reusable fitted parameters: outputs/ble_realcar_channel_fit_20261120/recommended_effective_profiles.json
- Generate fitted IQ: python generate_fitted_ble_iq.py --profiles outputs/ble_realcar_channel_fit_20261120/recommended_effective_profiles.json --condition NLOS
- Run standalone physics tests: python -m unittest discover -s tests -p 'test_ble*.py' -v

Measured source IQ and the existing TI project are not included. Existing-project integration tests are conditional.
