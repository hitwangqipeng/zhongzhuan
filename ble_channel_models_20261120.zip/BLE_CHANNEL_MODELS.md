# BLE 测距信道模型

新增文献信道说明见 [BLE_LITERATURE_CHANNELS.md](BLE_LITERATURE_CHANNELS.md)：包括指数 PDP、2.4 GHz 实测 S–V、TGn B–F 的 SISO PDP 和几何地面反射两径。单天线和 2×2 时分接口均支持；`--scenario literature` 可一次生成新增8种模型。文档逐项区分文献参数、工程默认值与实车拟合。

仅实现信道生成、双向 IQ 组合和导出。参考 [Channel Modeling for Phase-Based Ranging](https://arxiv.org/html/2608.17497v1) 的模块化接口，不复现整篇论文、Mode 3 时序或全部硬件损伤。

## 文件

- `ble_channel_models.py`：模型与 IQ/CIR 接口。
- `generate_ble_channels.py`：批量生成 NPZ；80 点模式同时生成现有 TI 工程的输入配置。
- `tests/test_ble_channel_models.py`：物理一致性与现有加载器兼容性检查。

依赖：Python 3.10+、NumPy、SciPy。

## 调用

```python
import numpy as np
from ble_channel_models import (
    ChannelConfig, MeasurementConfig, make_channel, measure, to_cir, tone_grid,
)

cfg = ChannelConfig(
    scenario="human_blockage",  # car_blockage / garage / free_space / static_multipath
    distance_m=8.0,
    human_width_m=0.45,
    obstacle_fraction=0.5,     # 遮挡物沿 TX-RX 连线的位置比例
    lateral_offset_m=0.0,     # 遮挡物中心横向偏移
)
ch = make_channel(cfg, tone_grid("legacy80"), seed=42)
obs = measure(ch, MeasurementConfig(snr_db=30), seed=43)
distance_axis, cir = to_cir(ch.frequency_hz, obs.combined_iq, nfft=512)
# ch.h：单程；obs.iq_a / iq_b：两个接收端；combined_iq：双向组合。
# obs.valid_mask：有效频点；ch.taps：单程路径；ch.metadata：模型说明。
```

## 模型与可调参数

| scenario | 实现 | 主要参数 |
|---|---|---|
| `free_space` | 单程单径，单位幅度 | `distance_m` |
| `static_multipath` | 用户指定多径 | `static_taps=((超额路径米数, 电压幅度, 相位度数), ...)` |
| `human_blockage` | 有限吸收屏障左右两侧 Fresnel 刀刃绕射 + 弱穿透径 | 人体宽度、位置、横向偏移、穿透损耗 |
| `car_blockage` | 左右边缘和车顶三条绕射分量 + 弱穿透径 | 车宽、车顶相对视线高度、位置、穿透损耗 |
| `garage` | 可衰减/关闭直达径 + 显式反射径 + 指数衰减随机复高斯尾部 | 直达损耗/开关、反射路径、尾部条数/起点/跨度/衰减/总平均功率 |

地库关闭直达径：`ChannelConfig(scenario="garage", garage_direct_present=False)`。
`garage_tail_power_db` 是相对同距离单位无遮挡场强的**总平均功率 dB**；其余路径 amplitude 是**电压线性幅度**，穿透损耗按 `10**(-loss_db/20)` 换算。

所有默认数值是可调整的工程起点，未根据实车数据拟合。人体模型不是圆柱介质 UTD；车体不是 CAD 射线追踪。多个边缘按复场相干叠加，适用于生成带绕射相位的近似样本，不能当作遮挡边界附近的严格电磁解。地库模型不是 IEEE 802.15.4a CM1 的完整实现。

## 传播和噪声约定

普通路径使用 `H(f)=sum(g_p * exp(-j*2*pi*f*L_p/c))`，`L_p` 全部是单程米数。Fresnel 绕射路径额外包含频率相关复系数；该系数已经含有绕行相位，代码去除重复计算的部分，避免把额外路径长度算两次。

在同一静态互易信道上独立生成两个端点的噪声，然后 `combined_iq = iq_a * iq_b`。无噪声时是 `H**2`，包含路径之间的交叉项。不要对第二个端点取共轭，也不要先把距离翻倍后再平方。

无遮挡单程幅度设为 1，不自动做逐样本归一化，不额外加入距离引起的 Friis 损耗。默认 `snr_reference="unblocked"`：噪声相对于同距离无遮挡单位信号确定，遮挡后实际 SNR 自然下降。`snr_reference="received"` 则按当前信道的频带平均功率设置 SNR。SNR 是每端点值，组合后不是同一个 SNR。

`phase_noise_std_deg` 控制每端点独立相位噪声；`missing_probability` 控制两端共享的额外随机擦除，输出零值和显式 mask。未生成运动、多普勒或跨帧相关性；新 seed 表示新静态场景。距离标签始终是真实几何距离，即使直达径完全消失。

## 频点与 CIR

- `ble72`：论文所用的 79 点物理网格减去 7 个禁用位置；具体映射见 `tone_grid`。
- `legacy80`：现有 TI 工程使用的 2400 MHz 起、1 MHz 间隔 80 点密集网格，用于兼容已有预处理；不宣称是标准 72-tone 布局。
- 可直接传自定义递增频率给 `make_channel`；`to_cir` 要求落在 1 MHz 物理网格。
- CIR 先将缺失位置补零，再做 IFFT，不能直接对压缩后的 72 个数 IFFT。双向距离轴为 `c*tau/2`。

## 批量生成和 TI 接入

在本目录执行：

```powershell
python generate_ble_channels.py --scenario all --grid legacy80 --samples 100 --output outputs/channel_models
python ti_ble_ranging_project/run.py --config outputs/channel_models/human_blockage_ti.json --output outputs/channel_ti_human
```

每个场景输出：

- `<scenario>.npz`：`iq[N,K]` 双向 IQ、`single_h[N,K]` 无噪单程信道、频率、真值、mask、随机种子。
- `<scenario>_paired.npz`：`iq_a/iq_b[N,K]`、匹配事件/path ID、频率和真值。
- `<scenario>.json`：模型参数和生成协议。
- 80 点模式额外输出 `<scenario>_ti.json` 与 `<scenario>_paired_ti.json`，可直接通过现有加载器读取；72 点数据保留原始频点，不能直接交给要求密集 80 点的 TI 前端。

生成器默认只改变距离和随机多径/噪声，未自动扫描人体宽度、姿态或各遮挡强度；训练数据增强可在调用层扫描上述参数。已检查数据加载，并用 5 条人体遮挡样本跑通现有 TI 推理流水线；这只是兼容性检查，没有启动训练或进行网络精度评估。

测试中的 TI 加载器集成检查依赖当前项目的 `ti_ble_ranging_project`；单独解压代码包时会跳过这一项，其余检查可独立运行。

```powershell
python -m unittest discover -s tests -p test_ble_channel_models.py -v
```
