"""Literature-backed *one-way* BLE-band channel building blocks.

Only NumPy is required by this module. It is imported by ble_channel_models;
Tap is imported locally to avoid a module import cycle. Sources and departures
from their experiments are documented in BLE_LITERATURE_CHANNELS.md.
"""
from __future__ import annotations

from dataclasses import dataclass
import numpy as np

C = 299_792_458.0
EPSILON_0 = 8.8541878128e-12
LITERATURE_SCENARIOS = ("exponential_pdp", "sv_2p4ghz", "two_ray_ground",
                        "tgn_b", "tgn_c", "tgn_d", "tgn_e", "tgn_f")
SOURCES = {
    "exponential_pdp": "https://www.ieee802.org/11/Documents/DocumentArchives/1997_docs/71252.pdf",
    "sv_2p4ghz": "https://doi.org/10.24138/jcomss.v3i2.258",
    "tgn": "https://iitk.ac.in/mwn/papers/11-03-0940-01-000n-tgn-channel-models.pdf",
    "two_ray_ground": "https://www.st.com/resource/en/application_note/dm00718575-radio-communication-range-estimation-in-ism-band-stmicroelectronics.pdf",
}

# IEEE 802.11-03/940r1 Appendix C, printed pages 35--41. Each cluster
# is (zero-based FIRST TAP INDEX, dB POWER values). Empty cells are -inf.
# Keep clusters separate: overlapping powers add in LINEAR units, not dB.
TGN_TABLES = {
    "b": (tuple(range(0,81,10)), 15., 0., (
        (0, (0.,-5.4,-10.8,-16.2,-21.7)),
        (2, (-3.2,-6.3,-9.4,-12.5,-15.6,-18.7,-21.8)))),
    "c": ((0,10,20,30,40,50,60,70,80,90,110,140,170,200), 30., 0., (
        (0, (0.,-2.1,-4.3,-6.5,-8.6,-10.8,-13.,-15.2,-17.3,-19.5)),
        (6, (-5.,-7.2,-9.3,-11.5,-13.7,-15.8,-18.,-20.2)))),
    "d": ((0,10,20,30,40,50,60,70,80,90,110,140,170,200,240,290,340,390), 50., 3., (
        (0, (0.,-.9,-1.7,-2.6,-3.5,-4.3,-5.2,-6.1,-6.9,-7.8,-9.,-11.1,-13.7,-16.3,-19.3,-23.2)),
        (10, (-6.6,-9.5,-12.1,-14.7,-17.4,-21.9,-25.5)),
        (14, (-18.8,-23.2,-25.2,-26.7)))),
    "e": ((0,10,20,30,50,80,110,140,180,230,280,330,380,430,490,560,640,730), 100., 6., (
        (0, (-2.6,-3.,-3.5,-3.9,-4.5,-5.6,-6.9,-8.2,-9.8,-11.7,-13.9,-16.1,-18.3,-20.5,-22.9)),
        (4, (-1.8,-3.2,-4.5,-5.8,-7.1,-9.9,-10.3,-14.3,-14.7,-18.7,-19.9,-22.4)),
        (8, (-7.9,-9.6,-14.2,-13.8,-18.6,-18.1,-22.8)),
        (14, (-20.6,-20.5,-20.7,-24.6)))),
    "f": ((0,10,20,30,50,80,110,140,180,230,280,330,400,490,600,730,880,1050), 150., 6., (
        (0, (-3.3,-3.6,-3.9,-4.2,-4.6,-5.3,-6.2,-7.1,-8.2,-9.5,-11.,-12.5,-14.3,-16.7,-19.9)),
        (4, (-1.8,-2.8,-3.5,-4.4,-5.3,-7.4,-7.,-10.3,-10.4,-13.8,-15.7,-19.9)),
        (8, (-5.7,-6.7,-10.4,-9.6,-14.1,-12.7,-18.5)),
        (12, (-8.8,-13.3,-18.7)), (14, (-12.9,-14.2)), (16, (-16.3,-21.2)))),
}


def tgn_profile(model="b"):
    """NLOS expected PDP; return new arrays (delays, powers, cluster dB, DS, K).

    Unit expected diffuse power. K is the published LOS FIRST-TAP K, and
    does not describe the ratio of LOS to the entire diffuse delay profile.
    """
    key = str(model).lower().removeprefix("tgn_")
    if key not in TGN_TABLES:
        raise ValueError("TGn model must be b/c/d/e/f")
    delays, ds, k_db, rows = TGN_TABLES[key]
    db = np.full((len(rows),len(delays)), -np.inf)
    for i,(start,values) in enumerate(rows):
        db[i,start:start+len(values)] = values
    power = np.sum(10**(db/10),axis=0)
    power /= power.sum()
    return np.asarray(delays,float), power, db, ds, k_db


def _finite_positive(x, name, zero=False):
    if not np.isfinite(x) or (x < 0 if zero else x <= 0):
        raise ValueError(f"{name} must be finite and {'nonnegative' if zero else 'positive'}")


@dataclass(frozen=True)
class GroundReflection:
    """Smooth planar half-space, electric-field reflection coefficient.

    grazing_sine = sin(angle ABOVE the plane), not the normal incidence angle.
    Vertical means E in the incidence plane (TM), expressed in fixed world
    polarization: its sign is the one needed to coherently add direct and
    reflected fields (both tend to -1 at grazing for a dielectric ground).
    """
    relative_permittivity: float = 2.5
    conductivity_s_per_m: float = 0.0
    polarization: str = "vertical"

    def validate(self):
        if not np.isfinite(self.relative_permittivity) or self.relative_permittivity < 1:
            raise ValueError("ground relative_permittivity must be finite and >= 1")
        _finite_positive(self.conductivity_s_per_m, "ground conductivity", zero=True)
        if self.polarization not in ("vertical", "horizontal"):
            raise ValueError("ground polarization must be vertical or horizontal")

    def coefficient(self, frequency_hz, grazing_sine):
        self.validate()
        f = np.asarray(frequency_hz, float)
        s = np.asarray(grazing_sine, float)
        if not np.isfinite(f).all() or np.any(f <= 0):
            raise ValueError("ground frequency must be positive and finite")
        if not np.isfinite(s).all() or np.any((s < 0) | (s > 1)):
            raise ValueError("grazing_sine must lie in [0,1]")
        epsilon = self.relative_permittivity - 1j*self.conductivity_s_per_m/(2*np.pi*f*EPSILON_0)
        root = np.sqrt(epsilon - 1 + s*s + 0j)
        first = epsilon*s if self.polarization == "vertical" else s
        # Matched half-space: no reflection, including the grazing 0/0 limit.
        return np.divide(first-root, first+root,
                         out=np.zeros(np.broadcast_shapes(f.shape, s.shape), complex),
                         where=np.abs(first+root) > 0)


def exponential_profile(decay_ns=50., step_ns=5., cutoff_db=40.):
    """Uniform-delay TDL, exponentially decaying expected POWER, sum(P)=1.

    decay_ns is the continuous PDP time constant. Finite, sampled RMS delay
    spread differs slightly; never relabel it as an exactly achieved RMS DS.
    """
    for x, key in ((decay_ns,"decay_ns"),(step_ns,"step_ns"),(cutoff_db,"cutoff_db")):
        _finite_positive(x, key)
    last = int(np.floor(decay_ns*cutoff_db*np.log(10)/10/step_ns))
    if last > 100_000:
        raise ValueError("exponential PDP would exceed 100001 taps")
    delays = np.arange(last+1)*step_ns
    power = np.exp(-delays/decay_ns)
    return delays, power/power.sum()


def _cn(rng, power):
    return (rng.normal(size=np.shape(power))+1j*rng.normal(size=np.shape(power)))*np.sqrt(power/2)


def _poisson_arrivals(rng, mean_interval, end):
    times = [0.]
    while True:
        t = times[-1]+rng.exponential(mean_interval)
        if t > end:
            return np.asarray(times)
        times.append(t)
        if len(times) > 100_000:
            raise ValueError("SV realization exceeds 100000 arrivals")


def sv_profile(rng, *, cluster_decay_ns=35.6, ray_decay_ns=36.5,
               cluster_interval_ns=130., ray_interval_ns=7., max_delay_ns=400.):
    """Double-Poisson S-V arrivals, truncated in a fixed delay observation window.

    Table 2 regression decay constants + Table 3 adjusted arrival intervals,
    Blazevic et al. (2007). The finite observation-window sampler and power
    scale convention are explicit implementation choices, not new fit results.
    First cluster/ray at zero denotes earliest arrival, not deterministic LOS.
    """
    for x, key in ((cluster_decay_ns,"cluster_decay_ns"),(ray_decay_ns,"ray_decay_ns"),
                   (cluster_interval_ns,"cluster_interval_ns"),(ray_interval_ns,"ray_interval_ns"),
                   (max_delay_ns,"max_delay_ns")):
        _finite_positive(x, key)
    expected = (1+max_delay_ns/cluster_interval_ns)*(1+max_delay_ns/ray_interval_ns)
    if expected > 100_000:
        raise ValueError("SV window/arrival rates would generate too many rays")
    clusters = _poisson_arrivals(rng, cluster_interval_ns, max_delay_ns)
    delays, weights, ids = [], [], []
    for i, t in enumerate(clusters):
        within = _poisson_arrivals(rng, ray_interval_ns, max_delay_ns-t)
        delays.extend(t+within)
        weights.extend(np.exp(-t/cluster_decay_ns-within/ray_decay_ns))
        ids.extend([i]*len(within))
    order = np.argsort(delays, kind="stable")
    power = np.asarray(weights)[order]
    power /= power.sum()  # Expected power conditional on arrival geometry, no sample AGC.
    return np.asarray(delays)[order], power, np.asarray(ids, int)[order], clusters


def profile_moments(delays_ns, power):
    t, p = np.asarray(delays_ns, float), np.asarray(power, float)
    p = p/p.sum()
    mean = float(p@t)
    return dict(mean_delay_ns=mean, rms_delay_spread_ns=float(np.sqrt(p@((t-mean)**2))))


def add_channel_arguments(parser):
    """Shared CLI controls, defaults match ChannelConfig and are serialized."""
    fields = {
        "excess_onset_ns": 0., "exp_decay_ns": 50., "exp_step_ns": 5., "exp_cutoff_db": 40.,
        "sv_cluster_decay_ns": 35.6, "sv_ray_decay_ns": 36.5,
        "sv_cluster_interval_ns": 130., "sv_ray_interval_ns": 7., "sv_max_delay_ns": 400.,
        "tx_height_m": 1., "rx_height_m": 1., "ground_relative_permittivity": 2.5,
        "ground_conductivity_s_per_m": 0.,
    }
    for key,value in fields.items():
        parser.add_argument("--"+key.replace("_","-"), type=float, default=value)
    parser.add_argument("--tgn-los", action="store_true", help="add published first-tap LOS component (TGn only)")
    parser.add_argument("--ground-polarization", choices=("vertical","horizontal"), default="vertical")


def configured_channel(args, scenario, distance_m=8.):
    from ble_channel_models import ChannelConfig
    keys = ("excess_onset_ns", "exp_decay_ns", "exp_step_ns", "exp_cutoff_db",
            "sv_cluster_decay_ns", "sv_ray_decay_ns", "sv_cluster_interval_ns",
            "sv_ray_interval_ns", "sv_max_delay_ns", "tgn_los", "tx_height_m", "rx_height_m",
            "ground_relative_permittivity", "ground_conductivity_s_per_m", "ground_polarization")
    return ChannelConfig(scenario=scenario, distance_m=distance_m,
                         **{key:getattr(args,key) for key in keys})


def literature_taps(cfg, rng):
    """Return taps and JSON-serializable provenance for the existing scalar API."""
    from ble_channel_models import Tap
    name, d = cfg.scenario, cfg.distance_m
    meta = dict(source_url=SOURCES["tgn" if name.startswith("tgn_") else name],
                fitted_to_user_data=False, temporal_correlation=False)
    if name == "two_ray_ground":
        ht, hr = cfg.tx_height_m, cfg.rx_height_m
        _finite_positive(ht,"tx_height_m")
        _finite_positive(hr,"rx_height_m")
        if d <= abs(ht-hr):
            raise ValueError("distance_m must exceed absolute antenna height difference")
        reflection = GroundReflection(cfg.ground_relative_permittivity,
                                      cfg.ground_conductivity_s_per_m, cfg.ground_polarization)
        reflection.validate()
        length = float(np.sqrt(d*d+4*ht*hr))
        taps = [Tap(d, 1., "direct"),
                Tap(length, d/length, "ground_reflection", ground=reflection,
                    ground_grazing_sine=(ht+hr)/length)]
        meta.update(evidence="ST AN5528 section 2.4: 2454 MHz BLE RSSI, not CS IQ calibration",
                    horizontal_distance_m=float(np.sqrt(d*d-(ht-hr)**2)),
                    tx_height_m=ht, rx_height_m=hr, direct_length_m=d,
                    reflected_length_m=length, frequency_dependent_fresnel=True)
        return taps, meta
    _finite_positive(cfg.excess_onset_ns,"excess_onset_ns",zero=True)
    onset = cfg.excess_onset_ns
    if name == "exponential_pdp":
        delays, power = exponential_profile(cfg.exp_decay_ns, cfg.exp_step_ns, cfg.exp_cutoff_db)
        gains = _cn(rng, power)
        labels = ["exponential_diffuse"]*len(delays)
        meta.update(evidence="IEEE 802.11-97/125: simplified exponentially decaying average PDP",
                    engineering_parameters=dict(decay_ns=cfg.exp_decay_ns, step_ns=cfg.exp_step_ns,
                                                cutoff_db=cfg.exp_cutoff_db))
    elif name == "sv_2p4ghz":
        delays, power, ids, clusters = sv_profile(rng, cluster_decay_ns=cfg.sv_cluster_decay_ns,
            ray_decay_ns=cfg.sv_ray_decay_ns, cluster_interval_ns=cfg.sv_cluster_interval_ns,
            ray_interval_ns=cfg.sv_ray_interval_ns, max_delay_ns=cfg.sv_max_delay_ns)
        gains = _cn(rng, power)
        labels = [f"sv_cluster_{i}" for i in ids]
        meta.update(evidence="Blazevic et al. 2007, 2.4 GHz / 400 MHz VNA, tables 2/3",
                    published_four_parameters_unchanged=bool(
                        np.array_equal([cfg.sv_cluster_decay_ns,cfg.sv_ray_decay_ns,
                                        cfg.sv_cluster_interval_ns,cfg.sv_ray_interval_ns],
                                       [35.6,36.5,130.,7.])),
                    cluster_ids=ids.tolist(), cluster_arrival_ns=clusters.tolist(),
                    arrival_sampler="double Poisson within fixed observation window",
                    parameters=dict(cluster_decay_ns=cfg.sv_cluster_decay_ns, ray_decay_ns=cfg.sv_ray_decay_ns,
                                    cluster_interval_ns=cfg.sv_cluster_interval_ns,
                                    ray_interval_ns=cfg.sv_ray_interval_ns, max_delay_ns=cfg.sv_max_delay_ns))
    else:
        delays, power, cluster_powers, nominal_ds, k_db = tgn_profile(name[-1])
        if not isinstance(cfg.tgn_los, (bool, np.bool_)):
            raise ValueError("tgn_los must be bool")
        diffuse = power.copy()
        specular = 0.
        if cfg.tgn_los:
            # Report section 4: ADD LOS to tap 0; do not merely redistribute
            # the original first tap power with the usual fixed-P Rician rule.
            specular = power[0]*10**(k_db/10)
        total = float(power.sum()+specular)
        gains = _cn(rng, diffuse/total)
        gains[0] += np.sqrt(specular/total)
        power = diffuse/total
        power[0] += specular/total
        labels = [f"tgn_{name[-1]}_tap_{i}" for i in range(len(delays))]
        meta.update(evidence="IEEE 802.11-03/940r1, Appendix C and section 4 (SISO PDP subset)",
                    source_revision="940r1 January 2004", nominal_nlos_rms_delay_spread_ns=nominal_ds,
                    los=bool(cfg.tgn_los), first_tap_k_db=k_db if cfg.tgn_los else None,
                    specular_expected_power=specular/total, diffuse_expected_power=(diffuse/total).tolist(),
                    cluster_power_db=[[float(x) if np.isfinite(x) else None for x in row]
                                      for row in cluster_powers], full_tgn_spatial_model=False,
                    full_tgn_doppler_model=False)
    meta.update(expected_power_normalization="conditional ensemble sum=1, no realization AGC",
                excess_delay_ns=(delays+onset).tolist(), expected_tap_power=power.tolist(),
                excess_onset_ns=onset, **profile_moments(delays, power))
    taps = [Tap(d+(delay+onset)*1e-9*C, complex(gain), label)
            for delay,gain,label in zip(delays,gains,labels)]
    return taps, meta
